NetWorkStatus = class("NetWorkStatus")
local targetPlatform = cc.Application:getInstance():getTargetPlatform()
--网络状态的管理类
NetWorkStatus.NetType = {
	WIFI   = 0, -- wifi网络
	MOBILE = 1, -- 移动网络
	UNKOWN = 2,  --未知网络
	NONE   = 3, --无网络
}
function NetWorkStatus:ctor()
	self.isNetWorkAvailable = self:isConnect()
	self.netWorkType = NetWorkStatus.NetType.UNKOWN --未知网络
  local function NetWordStatusChangeCallBack(status)
  	if(status ~= nil and type(status) == "string") then
  		self.netWorkType = tonumber(status)
  		if(self.netWorkType == NetWorkStatus.NetType.WIFI or self.netWorkType == NetWorkStatus.NetType.MOBILE) then
  			self.isNetWorkAvailable = true
  		else
  			self.isNetWorkAvailable = false
  		end
  		print("isNetWorkAvailable*****************************",self.isNetWorkAvailable)
  	end
  end
  if (cc.PLATFORM_OS_ANDROID == targetPlatform) then
    
    local args = {NetWordStatusChangeCallBack}
    local sigs = "(I)V"
    local className = "com/lexun/game/cocos2dx/GameServerManager"
    local ok,ret  = luaj.callStaticMethod(className,"setNetWorkChangeCallBack",args,sigs)
  end
end
function NetWorkStatus.shared()
	if nil == _G["NetWorkStatus.obj"] then
		_G["NetWorkStatus.obj"] = NetWorkStatus.new()
	end
	return _G["NetWorkStatus.obj"]
end

function NetWorkStatus:isNetWorkConnect()
	if (cc.PLATFORM_OS_ANDROID == targetPlatform) then
		return self.isNetWorkAvailable or self:isConnect()
	end
end

function NetWorkStatus:isConnect()
	if (cc.PLATFORM_OS_ANDROID == targetPlatform) then
      local args = {}
      local sigs = "()Z"
      
      local className = "com/lexun/game/cocos2dx/Lua_SDK"
      local ok,ret  = luaj.callStaticMethod(className,"getNetWork",args,sigs)
      if not ok then
          print("luaj error:", ok)
      else
          print("The ret is:", ret)
      end
      return ret
  end
end