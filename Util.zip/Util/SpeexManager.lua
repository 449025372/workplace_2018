SpeexManager = class()
SpeexManager.audioData = {}
local targetPlatform = cc.Application:getInstance():getTargetPlatform()
--录音完成回调
function SpeexManager.setRecordFinishCback(callback)
    if(cc.PLATFORM_OS_IPHONE == targetPlatform) or (cc.PLATFORM_OS_IPAD == targetPlatform) then
          local args = {callback = callback}
          local className = "OggSpeexViewController"
          local ok  = callNative(className,"setRecordCallback",args)
          if not ok then
              print("setRecordCallback luac error:", ok)
          else
              return true
          end
      end
      --android
      if (cc.PLATFORM_OS_ANDROID == targetPlatform) then
         local args = {callback}
         local sigs = "(I)Z"
         local className = "com/lexun/game/cocos2dx/SpeexManager"
         local func = "setRecordfinishCback"
         local ok, ret = callNative(className, func, args, sigs)
         if not ok then
           print("luaj error:",ret)
         else
            return ret
         end
      end
      return false
end
--播放完成回调
function SpeexManager.setPlayFinishCback(callback)
    if(cc.PLATFORM_OS_IPHONE == targetPlatform) or (cc.PLATFORM_OS_IPAD == targetPlatform) then
          local args = {callback = callback}
          local className = "OggSpeexViewController"
          local ok  = callNative(className,"setPlayCallback",args)
          if not ok then
              print("setPlayCallback luac error:", ok)
          else
              return true
          end
      end
      --android
      if (cc.PLATFORM_OS_ANDROID == targetPlatform) then
         local args = {callback}
         local sigs = "(I)Z"
         local className = "com/lexun/game/cocos2dx/SpeexManager"
         local func = "setRecordPlayFinishCallback"
         local ok,ret = callNative(className, func, args, sigs)
         print("record status:",ok)
         print("record ret:",ret)
         if not ok then
           print("luaj error:",ret)
         else
            return ret
         end
      end
      return false
end
--开始录音
function SpeexManager.startRecord(name)
  local filePath = string.format("%s%s.spx",cc.FileUtils:getInstance():getWritablePath(),name)
	local bRecord = SpeexManager.getRecordStatus()
	print("record status:",bRecord)
	print("record ret:",bRecord)
	if bRecord  then
		print("Is been recording!")
		return true
	else
       if(cc.PLATFORM_OS_IPHONE == targetPlatform) or (cc.PLATFORM_OS_IPAD == targetPlatform) then
	        local args = {filePath = filePath}
	        local className = "OggSpeexViewController"
	        local ok  = callNative(className,"recordOnOff",args)
	        if not ok then
	            print("recordOnOff luac error:", ok)
	        else
	            return true
	        end
    	end
    	--android
    	if (cc.PLATFORM_OS_ANDROID == targetPlatform) then
         local args = {filePath}
         local sigs = "(Ljava/lang/String;)Z"
         local className = "com/lexun/game/cocos2dx/SpeexManager"
         local func = "startRecord"
         local ok,ret = callNative(className, func, args, sigs)
	       print("record status:",ok)
	       print("record ret:",ret)
	       if not ok then
	         print("luaj error:",ret)
	       else
	        	return ret
	       end
    	end

    end
    print("record failed!")
    return false
end
--停止录音
function SpeexManager.stopRecord()
  local bRecord = SpeexManager.getRecordStatus()

	if not bRecord  then
		print("already stoped record!")
		return true
	else
       if(cc.PLATFORM_OS_IPHONE == targetPlatform) or (cc.PLATFORM_OS_IPAD == targetPlatform) then
	        local args = {filePath = ""}
	        local className = "OggSpeexViewController"
	        local ok  = callNative(className,"recordOnOff",args)
	        if not ok then
	            print("recordOnOff luac error:", ok)
	        else
	            return true
	        end
    	end

    	--android true:停止成功 false 为录音 或者停止失败
    	if (cc.PLATFORM_OS_ANDROID == targetPlatform) then
         local args = {}
         local sigs = "()Z"
         local className = "com/lexun/game/cocos2dx/SpeexManager"
         local func = "stopRecord"
         local ok,ret = callNative(className, func, args, sigs)
	       print("stopRecord status:",ok)
	       print("stopRecord ret:",ret)
	       if not ok then
	         print("luaj error:",ret)
	       else
	        	return ret
	       end
    	end
    end
    print("stop record failed!")
    return false
end
--开始播放
function SpeexManager.startPlay(name)
  local filePath = string.format("%s%s.spx",cc.FileUtils:getInstance():getWritablePath(),name)
	local bPlay = SpeexManager.getPlayStatus()
	if bPlay  then
		print("Is been playing!")
		return true
	else
       if(cc.PLATFORM_OS_IPHONE == targetPlatform) or (cc.PLATFORM_OS_IPAD == targetPlatform) then
	        local args = {filePath= filePath}
	        local className = "OggSpeexViewController"
	        local ok  = callNative(className,"playOnOffLua",args)
	        if not ok then
	            print("playOnOff luac error:", ok)
	        else
	            return true
	        end
    	end
    	--android  true:成功播放 false:失败
    	if (cc.PLATFORM_OS_ANDROID == targetPlatform) then
	       print("---------filePath",filePath)
         local args = {filePath}
         local sigs = "(Ljava/lang/String;)Z"
         local className = "com/lexun/game/cocos2dx/SpeexManager"
         local func = "startPlayRecord"
         local ok,ret = callNative(className, func, args, sigs)
	       if not ok then
	         print("luaj error:",ret)
	       else
	        	return ret
	       end
    	end
    end
    print("play failed!")
    return false
end
--停止播放
function SpeexManager.stopPlay()
    local bPlay = SpeexManager.getPlayStatus()
	if not bPlay  then
		print("already stoped play!")
		return true
	else
       if(cc.PLATFORM_OS_IPHONE == targetPlatform) or (cc.PLATFORM_OS_IPAD == targetPlatform) then
	        local args = {filePath= ""}
	        local className = "OggSpeexViewController"
	        local ok  = callNative(className,"playOnOffLua",args)
	        if not ok then
	            print("playOnOff luac error:", ok)
	        else
	            return true
	        end
    	end
    	--android  true:成功停止 false:未播放或其他
    	if (cc.PLATFORM_OS_ANDROID == targetPlatform) then
         local args = {}
         local sigs = "()Z"
         local className = "com/lexun/game/cocos2dx/SpeexManager"
         local func = "stopPlayRecord"
         local ok,ret = callNative(className, func, args, sigs)
	       if not ok then
	         print("luaj error:",ret)
	       else
	        	return ret
	       end
    	end
    end
    print("stop play failed!")
    return false
end
-- 录音状态
function SpeexManager.getRecordStatus()

    if(cc.PLATFORM_OS_IPHONE == targetPlatform) or (cc.PLATFORM_OS_IPAD == targetPlatform) then
        local args = nil
        local className = "OggSpeexViewController"
        local ok,ret  = callNative(className,"getRecordStatus",args)
        if not ok then
            print("getRecordStatus luac error:", ok)
        else
            return ret
        end
    end

    --android  true:正在录音 false:未录音
	if (cc.PLATFORM_OS_ANDROID == targetPlatform) then
       local args = {}
       local sigs = "()Z"
       local className = "com/lexun/game/cocos2dx/SpeexManager"
       local func = "getRecordStatus"
       local ok, ret = callNative(className, func, args, sigs)
       if not ok then
         print("luaj error:",ret)
       else
        	return ret
       end
	end
	return false

end
-- 播放状态
function SpeexManager.getPlayStatus()
   if(cc.PLATFORM_OS_IPHONE == targetPlatform) or (cc.PLATFORM_OS_IPAD == targetPlatform) then
        local args = nil
        local className = "OggSpeexViewController"
        local ok,ret  = callNative(className,"getPlayStatus",args)
        if not ok then
            print("getPlayStatus luac error:", ok)
        else
            return ret
        end
    end

    --android  true:正在播放 false:未播放
	if (cc.PLATFORM_OS_ANDROID == targetPlatform) then
       local args = {}
       local sigs = "()Z"
       local className = "com/lexun/game/cocos2dx/SpeexManager"
       local func = "getPlayStatus"
       local ok, ret = callNative(className, func, args, sigs)
       if not ok then
         print("luaj error:",ret)
       else
        	return ret
       end
	end
	return false
end

function SpeexManager.getProcess()
        if(cc.PLATFORM_OS_IPHONE == targetPlatform) or (cc.PLATFORM_OS_IPAD == targetPlatform) then
        local args = nil
        local className = "OggSpeexViewController"
        local ok,ret  = callNative(className,"getProcess",args)
        if not ok then
            print("getProcess luac error:", ok)
        else
            return ret
        end
    end
end
-- 获取数据
function SpeexManager.getFileData(name)
    local filePath = string.format("%s%s.spx",cc.FileUtils:getInstance():getWritablePath(),name)
    local file = io.open(filePath, "rb");
    assert(file);
    local data = file:read("*all"); -- 读取所有内容
    file:close();

    function changeNum(num)
        if num < 10 then
            return string.format("000%d", num)
        elseif num < 100 then
            return string.format("00%d", num)
        elseif num < 1000 then
            return string.format("0%d", num)
        elseif num < 10000 then
            return string.format("%d", num)
        end
    end

    local maxBytes = 1024 * 7
    local str = SpeexManager.changeBytes(data)
    local codeID = string.format("%s%s", name, os.time())
    if #codeID %2 == 0 then -- 容错 双位数
      codeID = codeID.."0"
    end
    local headCode = string.format("lexunaudio#0000#0000#%s||", codeID)
    local maxLenth = math.floor((#str + #headCode) / maxBytes)
    if (#str + #headCode) % maxBytes ~= 0 then
      maxLenth = maxLenth + 1
    end
    local oneLenth = maxBytes - #headCode
    if maxLenth == 1 then
      oneLenth = #str
    end
    local startI = 1
    local endI = oneLenth
    local dataArr = {}
    for i=1,maxLenth do
          headCode = "lexunaudio#"..changeNum(maxLenth).."#"..changeNum(i).."#"..codeID.."||"
          if endI > #str then
              endI = #str
          end
          local newStr = string.sub(str, startI, endI)
          startI = endI + 1
          endI = endI + oneLenth
          table.insert(dataArr, headCode..newStr)
      end
    return dataArr
end
-- 字符串转换成Ascll 0x16进制 
function SpeexManager.changeBytes(str)
    local data = ""
    for i=1,#str do
      local bytes = string.byte(string.sub(str, i, i))
      if bytes < 16 then
          bytes = string.format("0%0x",bytes) -- 少一位补0
      else
          bytes = string.format("%0x",bytes)
      end 
      data = data..bytes
    end
    return data
end
-- 解码保存
function SpeexManager.encodeData(str, name)
    local Engine = require("src/app/Manager/Engine.lua")
    local arr = Engine:split(str, "||")
    local headArr = Engine:split(arr[1], "#")
    local newStr = arr[2]
    local charData = ""
    local count = 1
    for i=1,#newStr / 2 do
       local subData = "0x"..string.sub(newStr, count, count + 1) -- 2位为 一个16进制
       charData = charData..string.char(tonumber(subData))
       count = count + 2
    end
    local maxCount = tonumber(headArr[2])
    local index = tonumber(headArr[3])
    local codeID = headArr[4]

    if not SpeexManager.audioData[codeID] then
      SpeexManager.audioData[codeID] = {}
    end
    SpeexManager.audioData[codeID][index] = charData

    if #SpeexManager.audioData[codeID] == maxCount then
      local allData = ""
      for i=1,#SpeexManager.audioData[codeID] do
        allData = allData..SpeexManager.audioData[codeID][i]
      end
      local filePath = string.format("%s%s.spx",cc.FileUtils:getInstance():getWritablePath(),name)
      local file = io.open(filePath, "w");
      assert(file);
      file:write(allData);
      file:close();

      SpeexManager.audioData[codeID] = {}
    end
end

--判断是否语音数据
function SpeexManager.checkIsAudioData(content)
    local headCode = "lexunaudio#"
    local index = string.find(content, headCode)
    if index and index == 1 then
        return true
    end
    return false
end

