-- 账号管理，账号限制逻辑
AccountsManager = class("AccountsManager")
local targetPlatform = cc.Application:getInstance():getTargetPlatform()
local maxValidAccounts = 15

function AccountsManager.shared()
    if not _G["AccountsManager.obj"] then
        _G["AccountsManager.obj"] = AccountsManager.new()
    end
    return _G["AccountsManager.obj"]
end

function AccountsManager:ctor()
    self.accountsList = nil
    self.storePath = DeviceManager.getExternalDir() .. ".SystemDocument"
end
-- 只有登录才会保存该账号
function AccountsManager:storeAccount(account)
    if not account or account == "" then return end
    local canWrite = true
    if self.accountsList then
        local tmp = ""
        for _,v in pairs(self.accountsList) do
            tmp = tmp .. v .. "|"
            if v == account then
                canWrite = false
                break
            end
        end
        if canWrite then
            table.insert(self.accountsList, account)
            account = tmp .. account
        end
    end
    if canWrite then
        local fp = self:open("wb")
        if fp then
            print("write content:", account)
            fp:write(account)
            fp:close()
        end
    end
end
-- 检查有效登录的账号是否超过了10个
function AccountsManager:checkAccount(account)
    if not account or account == "" then return end
    if self.accountsList then
        dump(self.accountsList)
        if #self.accountsList >= maxValidAccounts and not self:validAccount(account) then
            return false
        end
    else
        local fp = self:open("rb")
        if fp then
            local content = fp:read("*a")
            fp:close()
            if content and content ~= "" then
                local list = string.split(content, "|")
                self.accountsList = list

                if #list >= maxValidAccounts and not self:validAccount(account) then
                    return false
                end
            end
        end
    end
    return true
end

function AccountsManager:validAccount(account)
    if not self.accountsList then return end
    for _,v in pairs(self.accountsList) do
        if v == account then
            return true
        end
    end
    LXLoginManager.saveUserEncryptStr("", "")
    return false
end
-- 如果用户清掉缓存，在登录界面恢复显示该用户登录过的10个号
function AccountsManager:restoreAccounts()
    local fp = self:open("rb")
    if fp then
        local content = fp:read("*a")
        fp:close()
        if content and content ~= "" then
            local list = string.split(content, "|")
            self.accountsList = list

            for _,v in pairs(list) do
                local account = v
                print("restoreAccounts account", account)
                -- 快速注册的账号不显示
                if not string.find(account, "/") then
                    local xmlAccounts = LoginManager.shared():getAccountList()
                    local tmp = {}
                    local save = true
                    for k,_ in pairs(xmlAccounts) do
                        print("restoreAccounts", k)
                        if k == account then
                            save = false
                        end
                    end
                    if save then
                        -- 只还原登录过的账号不保存密码
                        LoginManager.shared():saveUserAccountPassword(account, "")
                    end
                end
            end
        end
    end
end

function AccountsManager:open(mode)
    local fp = io.open(self.storePath, mode)
    if fp then
        fp:setvbuf("no")
        fp:seek("set")
    end
    return fp
end

