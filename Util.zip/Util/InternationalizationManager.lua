-- 国际化
InternationalizationManager = class()

-- 获取设备语言
function InternationalizationManager.getCurrentLanguage()
	local languageStr = nil
	local currentLanguageType = cc.Application:getInstance():getCurrentLanguage()
	if currentLanguageType == cc.LANGUAGE_CHINESE then
        languageStr = "Chinese"
    elseif currentLanguageType == cc.LANGUAGE_ENGLISH then
    	languageStr = "English"
	elseif currentLanguageType == cc.LANGUAGE_JAPANESE then
		languageStr = "Japanese"
    elseif currentLanguageType == cc.LANGUAGE_FRENCH then
    	languageStr = "French"
    elseif currentLanguageType == cc.LANGUAGE_GERMAN then
    	languageStr = "German"
    elseif currentLanguageType == cc.LANGUAGE_ITALIAN then
    	languageStr = "Italian"
    elseif currentLanguageType == cc.LANGUAGE_RUSSIAN then
    	languageStr = "Russian"
    elseif currentLanguageType == cc.LANGUAGE_SPANISH then
    	languageStr = "Spanish"
    elseif currentLanguageType == cc.LANGUAGE_KOREAN then
    	languageStr = "Korean"
    elseif currentLanguageType == cc.LANGUAGE_HUNGARIAN then
    	languageStr = "Hungarian"
    elseif currentLanguageType == cc.LANGUAGE_PORTUGUESE then
    	languageStr = "Portuguese"
    elseif currentLanguageType == cc.LANGUAGE_ARABIC then
    	languageStr = "Arabic"
    end
    return languageStr
end

function InternationalizationManager.localString(key)
    local requireStr = "src.Language.Chinese" -- .. InternationalizationManager.getCurrentLanguage()
    require(requireStr)
    return _G[key] or ""
end

function I18NString(key)
    return InternationalizationManager.localString(key)
end