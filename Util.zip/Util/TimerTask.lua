--[[
-- 定时器类
-- Author: Jacky
-- Date: 2015-1-8 17:15
]]
TimerTask = class("TimerTask")
-- 单例
function TimerTask.shared()
	if nil == _G["TimerTask.obj"] then
		_G["TimerTask.obj"] = TimerTask.new()
	end
	return _G["TimerTask.obj"]
end
function TimerTask:ctor()
	self.timerList = {}
end
-- 注册定时器并存入定时器列表
function TimerTask:addScheduler(timerInfo)
	if not timerInfo then return false end
	if not timerInfo.name or not timerInfo.time then print("no timer name or time") return false end
	if not timerInfo.call then print("no timer call") return false end
	local tmpTimer = self:registScheduler(timerInfo.tickInterval or 1, timerInfo.call)
	self.timerList[timerInfo.name] = {}
	self.timerList[timerInfo.name].timer = tmpTimer
	self.timerList[timerInfo.name].tick = timerInfo.time
	self.timerList[timerInfo.name].name = timerInfo.name
end
-- 获取该定时器当前tick计数器
function TimerTask:getTimerTicksByName(name)
	if self.timerList[name] then return self.timerList[name].tick end
	return nil
end
-- 注销定时器并更新定时器列表
function TimerTask:deleteScheduler(name)
	if not name then return false end
	if type(name) == "table" then
		for _,n in ipairs(name) do
			if self.timerList[name] then
				self:unregistScheduler(self.timerList[name].timer)
				self.timerList[name] = nil
			end
		end
	else
		if self.timerList[name] then
			self:unregistScheduler(self.timerList[name].timer)
			self.timerList[name] = nil
		end
	end
end
-- 注销所有定时器
function TimerTask:unregistAllSchedulers(exceptName)
	for _,eachTimer in pairs(self.timerList) do
		-- print("except sys",exceptName)
		if eachTimer and exceptName ~= eachTimer.name then
			self:unregistScheduler(eachTimer.timer) 
			eachTimer.timer = nil
		end
	end
end
-- 注销指定定时器
function TimerTask:unregistScheduler(scheduler)
	if scheduler then
		local schedulerManager = cc.Director:getInstance():getScheduler()
		schedulerManager:unscheduleScriptEntry(scheduler)
	end
end
-- 注册时钟, time为时钟执行一周的时间, callback为时钟回调
function TimerTask:registScheduler(interval, call)
	local schedulerManager = cc.Director:getInstance():getScheduler()
	local scheduler = schedulerManager:scheduleScriptFunc(call, interval, false)
	return scheduler
end

return TimerTask
