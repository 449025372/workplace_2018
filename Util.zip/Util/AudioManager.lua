AudioManager = class()
AudioManager.audioData = {}
local targetPlatform = cc.Application:getInstance():getTargetPlatform()

--开始录音
function AudioManager.startRecord(name, call)
  local filePath = string.format("%s%s.aac",cc.FileUtils:getInstance():getWritablePath(), name or "speech")
  print("开始录音 record file:",filePath)
	if AudioManager.isRecording then
		print("Is been recording!")
		return true
	else
       local function recordCall(ret)
          print("record over call", ret)
          AudioManager.isRecording = false
          if call then call(ret) end
       end
       FileManager:removeFile(filePath)
       if(cc.PLATFORM_OS_IPHONE == targetPlatform) or (cc.PLATFORM_OS_IPAD == targetPlatform) then
	        local args = {path = filePath, callback = recordCall}
	        local className = "AudioManager"
	        local ok  = callNative(className,"recording",args)
	        if not ok then
	            print("recordOnOff luac error:", ok)
	        else
              AudioManager.isRecording = true
	            return true
	        end
    	end
    	--android
    	if (cc.PLATFORM_OS_ANDROID == targetPlatform) then
         local args = {filePath, recordCall}
         local sigs = "(Ljava/lang/String;I)I"
         local className = "com/lexun/game/cocos2dx/AudioHelper"
         local func = "startRecording"
         local ok,ret = callNative(className, func, args, sigs)
	       print("record status:",ok)
	       print("record ret:",ret)
	       if not ok then
	         print("luaj error:",ret)
	       else
            if ret ~= 0 then
              AudioManager.isRecording = false
              return false
            else
              AudioManager.isRecording = true
            end
	        	return ret
	       end
    	end

    end
    print("record failed!")
    return false
end
--停止录音
function AudioManager.stopRecord()
	if not AudioManager.isRecording then
		print("already stoped record!")
		return true
	else
       print("stop record")
       if(cc.PLATFORM_OS_IPHONE == targetPlatform) or (cc.PLATFORM_OS_IPAD == targetPlatform) then
	        local className = "AudioManager"
	        local ok  = callNative(className,"stopRecording")
	        if not ok then
	            print("recordOnOff luac error:", ok)
	        else
              AudioManager.isRecording = false
	            return true
	        end
    	end

    	--android true:停止成功 false 为录音 或者停止失败
    	if (cc.PLATFORM_OS_ANDROID == targetPlatform) then
         local args = {}
         local sigs = "()V"
         local className = "com/lexun/game/cocos2dx/AudioHelper"
         local func = "stopRecording"
         local ok,ret = callNative(className, func, args, sigs)
	       if not ok then
	         print("luaj error:",ret)
	       else
            AudioManager.isRecording = false
	        	return ok
	       end
         AudioManager.isRecording = false
	       return true
    	end
    end
    return false
end
--开始播放
function AudioManager.startPlay(name, call, vol)
  local filePath = string.format("%s%s.aac",cc.FileUtils:getInstance():getWritablePath(), name or "speech")
  print("开始播放:",filePath)
	if AudioManager.isPlaying then
		print("Is been playing!")
		return true
	else
      local function playCall(ret)
        print("执行回调", ret)
        AudioManager.isPlaying = false
        if call then call(ret) end
      end
      if(cc.PLATFORM_OS_IPHONE == targetPlatform) or (cc.PLATFORM_OS_IPAD == targetPlatform) then
	        local args = {path = filePath, callback = playCall, volume = vol or 1.0}
	        local className = "AudioManager"
	        local ok  = callNative(className,"audioPlay",args)
	        if not ok then
	            print("playOnOff luac error:", ok)
	        else
              AudioManager.isPlaying = true
	            return true
	        end
    	end
    	--android  true:成功播放 false:失败
    	if (cc.PLATFORM_OS_ANDROID == targetPlatform) then
	       print("---------filePath",filePath)
         local args = {filePath,playCall}
         local sigs = "(Ljava/lang/String;I)V"
         local className = "com/lexun/game/cocos2dx/AudioHelper"
         local func = "playAudio"
         local ok,ret = callNative(className, func, args, sigs)
	       if not ok then
	         print("luaj error:",ret)
	       else
            AudioManager.isPlaying = true
	        	return ok
	       end
    	end
    end
    print("play failed!")
    return false
end
--停止播放
function AudioManager.stopPlay()
	if not AudioManager.isPlaying then
		print("already stoped play!")
		return true
	else
       if(cc.PLATFORM_OS_IPHONE == targetPlatform) or (cc.PLATFORM_OS_IPAD == targetPlatform) then
	        local className = "AudioManager"
	        local ok  = callNative(className,"stopPlay")
	        if not ok then
	            print("playOnOff luac error:", ok)
	        else
              AudioManager.isPlaying = false
	            return true
	        end
    	end
    	--android  true:成功停止 false:未播放或其他
    	if (cc.PLATFORM_OS_ANDROID == targetPlatform) then
         local args = {}
         local sigs = "()V"
         local className = "com/lexun/game/cocos2dx/AudioHelper"
         local func = "stopAudio"
         local ok,ret = callNative(className, func, args, sigs)
	       if not ok then
	         print("luaj error:",ret)
	       else
            AudioManager.isPlaying = false
	        	return ret
	       end
    	end
    end
    print("stop play failed!")
    return false
end
-- 获取数据
function AudioManager.getFileData(name)
    local filePath = string.format("%s%s.aac", cc.FileUtils:getInstance():getWritablePath(), name or "speech")
    print("获取数据 record file:",filePath)
    local file = io.open(filePath, "r");
    if file == nil then return end
    -- local fileLen = file:seek("end")
    local bytes = 2048
    -- print("文件长度", fileLen)
    file:seek("set")

    local count = 0
    local datas = {}
    local timestamp = tostring(os.time())
    while true do
      local data = file:read(bytes)
      count = count + 1
      if data then
        -- print("分段读取", #data, count)
        data = string.format("audiodata||%s||%d||%s", timestamp, count, data)
        print("getFileData", data)
        table.insert(datas, data)
      else
        if #datas > 0 then  
          datas[#datas] = datas[#datas] .. "||audioend"
        end
        break
      end
    end

    file:close();
    return datas
end
-- 解码保存到container中
function AudioManager.decodeData(data, container)
  if not container or not data then return end
  local datas = string.split(data, "||")
  local timestamp,count,audioData = datas[2],datas[3],datas[4]
  container[timestamp] = container[timestamp] or {}
  table.insert(container[timestamp], audioData)
  if string.find(data, 'audioend') then return container[timestamp] end
  return false
end
-- data为已经过解码后的数据
function AudioManager.saveAudio(data, name)
  if not data then return end
  local filePath = string.format("%s%s.aac", cc.FileUtils:getInstance():getWritablePath(), name or "speech")
  FileManager:removeFile(filePath)
  print("解码保存 record file:",filePath)
  local file = io.open(filePath, "w+");
  for _,v in pairs(data) do
    file:write(v)
  end
  file:flush()
  file:close()
end

function AudioManager.reqPermission()
  if (cc.PLATFORM_OS_ANDROID == targetPlatform) then
    if not cc.UserDefault:getInstance():getBoolForKey("recordpermissiononce") then
      cc.UserDefault:getInstance():setBoolForKey("recordpermissiononce", true)
      AudioManager.getRecordStatus()
    end
  end
end

--停止播放
function AudioManager.getRecordStatus()
  if (cc.PLATFORM_OS_ANDROID == targetPlatform) then
    local args = {}
    local sigs = "()I"
    local className = "com/lexun/game/cocos2dx/AudioHelper"
    local func = "getRecordState"
    local ok,ret = callNative(className, func, args, sigs)
  end
end