-- 字符串分割，return 分割后table， 参数：str分割字符串，delimiter分割字符
function SpliteStr(str,delimiter)
	if nil == str then return {} end
	if nil == str then return {str} end
	local result = {}
    for match in (str..delimiter):gmatch("(.-)"..delimiter) do
        table.insert(result, match)
    end
    return result
end

-- 昵称确认
function nickNameCheck(name)
	if nil == name then return "" end
	local str = name:sub(1,1)
	if " " == str then
		name = name:sub(2)
		return nickNameCheck(name)
	end
	str = name:sub(-1)
	if " " == str then
		name = name:sub(1,-2)
		return nickNameCheck(name)
	end
	return name
end

--字符是否是中文
function isChineseCode(ch)
	local value = string.byte(ch)
	if nil == value then return true,ch end
	if (value >= 0) and (value <= 127) then
		return false,ch
	end
	return true,ch
end

local fontWArray = {}
local fontSize = 24
local labelMaxW = 399
local limitLen = 44
function getCharWidth(char)
	local value = tostring(char)
	if nil == fontWArray[value] then
		local width = cc.Label:create(value, "Arial", fontSize):getContentSize().width
		fontWArray[value] = width
	end
	return fontWArray[value]
end
--获取规则字符串数组
function getRuleStrArray(ruleStr)
	local ruleContent = SpliteStr(ruleStr, "<br/>")
	local ruleArray = {}
	for _,v in pairs(ruleContent) do
		local function insertStrToArray(str)
			local len = string.len(str)
			if len > limitLen then
				local index = 0
				local indexW = 0
				while 1 do
					local value = index + 1
					local ok,char = isChineseCode(string.sub(str, value, value))
					if true == ok then
						value = value + 2
						indexW = indexW + fontSize
					else
						indexW = indexW + getCharWidth(char)
					end
					if indexW <= labelMaxW then
						index = value
					else
						break
					end
				end
				local dtStr = string.sub(str, 1, index)
				table.insert(ruleArray, dtStr)
				local dtIndex = index + 1
				insertStrToArray(string.sub(str, dtIndex, len))
			else
				table.insert(ruleArray, str)
			end
		end
		insertStrToArray(v)
	end

	return ruleArray
end

CSVTable = {}

-- CSV解码，return table，参数：str（CSV字符串）
function CSVTable.decode(str)
	return SpliteStr(str,",")
end

-- CSV编码，return csv字符串，参数：array（csv table）
function CSVTable.encode(array)
	return table.concat(array,",")
end

UrlImageData = {}
function UrlImageData.urlData(url, callBack, _id, notShowWait,avater)
	local urlDir = "UrlImage/"
	DirManager.create(urlDir)

    local fileName = urlDir .. require("src.Util.URIManager").uri_encode(url)
    if avater then avater.isValid = true end
    if FileIOManager.fileIsExist(fileName) then
    	if nil ~= callBack then
    		if avater and not avater.isValid then return end
    		callBack(fileName)
    	end
    	return false
    else
    	local fileManager = FileIOManager.new()
	    fileManager:setFile(fileName)

	    local http = HttpManager.new()
	    local function onSuccess(data)
	    	local totalnum = cc.UserDefault:getInstance():getIntegerForKey(UserIconManager.uploadPhotoNums,0)
		    local id = cc.UserDefault:getInstance():getIntegerForKey(UserIconManager.uploadPhotoID..tostring(totalnum),-1)
		    local isUpLoad = cc.UserDefault:getInstance():getIntegerForKey(UserIconManager.userUpLoad)--上传照片标识
		    local userid = tostring(GameDataUser.shared().userID)
		    if id ~= _id and tonumber(isUpLoad)>0 then
		    	totalnum = totalnum + 1
		    	cc.UserDefault:getInstance():setIntegerForKey(UserIconManager.uploadPhotoNums,totalnum)
		    	cc.UserDefault:getInstance():setIntegerForKey(UserIconManager.uploadPhotoID..tostring(totalnum),_id)
		    	cc.UserDefault:getInstance():setIntegerForKey(UserIconManager.userCurID..tostring(totalnum),userid)
		    end
		    cc.UserDefault:getInstance():setIntegerForKey(UserIconManager.userUpLoad,0)
	    	fileManager:open("wb")
	        fileManager:write(data)
			fileManager:close()

	        if nil ~= callBack then
	        	if avater and not avater.isValid then return end
	    		callBack(fileName)
	    	end
	    end
	    local function onFailure()
	    end
	    http:luaXmlHttpGetRequest(url, onSuccess, onFailure, nil, true, notShowWait)
    end
    return true
end

SystemManager = {}

function SystemManager.getFileContents(filename)
	if FileIOManager.fileIsExist(filename, true) then
		local key = "placeholder"
		for line in io.lines(filename) do
			local index = string.find(line, key)
			if index and index >= 0 then
				return false
			end
		end
	else
		print("no such file!")
	end
	return true
end

function SystemManager.execute(executeStr)
	local file = io.popen(executeStr, "r")
	for line in file:lines() do
		print("-----------line",line)
	end
	file:close()
end

DirManager = {}
function DirManager.create(dirName)
	local writeDir = cc.FileUtils:getInstance():getWritablePath() .. dirName
	print("-------createDir",writeDir)
	FileManager:createDir(writeDir)
end

function DirManager.removeDir(dirName)
	local writeDir = cc.FileUtils:getInstance():getWritablePath() .. dirName
	print("-------removeDir",writeDir)
	FileManager:removeDir(writeDir)
end

-- 沙盒路径下文件的读写
FileIOManager = class()

FileIOManager.filePath = nil
FileIOManager.file = nil
FileIOManager.fileType = nil

-- 判断子游戏的文件是否存在
function FileIOManager.checkGameFileExist(path)
	if not path then return end
    local filePath = ""
    path = string.split(path, ".")
    for k,v in pairs(path) do
        if k == 1 then
            filePath = filePath .. v
        else
            filePath = filePath .. "/" .. v
        end
    end
    filePath = filePath .. ".lua"
    print("filePath: ", filePath)
    return cc.FileUtils:getInstance():isFileExist(filePath)
end

function FileIOManager.fileIsExist(fileName, noPrepath)
	local filePath = cc.FileUtils:getInstance():getWritablePath() .. fileName
	if noPrepath then filePath = fileName end
	local file,_ = io.open(filePath)
	if nil ~= file then
		file:close()
		return true
	end
	return false
end

-- 设置文件名
function FileIOManager:setFile(fileName)
	self.filePath = cc.FileUtils:getInstance():getWritablePath() .. fileName
	-- print("----filePath",self.filePath)
	local fileArray = SpliteStr(fileName,".")
	self.fileType = fileArray[2]
end

-- 打开文件，参数：mode打开方式
function FileIOManager:open(mode)
	if nil ~= self.file then
		self.file:close()
	end
	self.file = io.open(self.filePath, mode)
	if nil == self.file then
		print("open file error!")
	else
		self.file:setvbuf("no")
	end
end

-- 读取所有数据
function FileIOManager:read()
	return self.file:read("*a")
end

-- 写入数据
function FileIOManager:write(contents)
	self.file:write(contents)
end

-- 读取数据操作
function FileIOManager:readData()
	self:open("rb")
	local data = self:read()
	self:close()
	return data
end

-- 写入数据操作
function FileIOManager:writeData(contents)
	self:open("a+")
	local typeStr = type(contents)
	if "table" == typeStr then
		local dataStr = nil
		if "csv" == self.fileType then
			dataStr = CSVTable.encode(contents)
		else
			dataStr = JsonManager.encode(contents)
		end
		self:write(dataStr)
	else
		self:write(contents)
	end
	self:close()
end

-- 关闭文件
function FileIOManager:close()
	self.file:close()
	self.file = nil
end

function printLog(...)
	if true ~= LOG_SWITCH then return end
	local msg = ""
	for i=1,select("#", ...) do
		local value = select(i, ...)
		local tp = type(value)
		if "string" ~= tp and "number" ~= tp then
			if "boolean" == tp then
				if value then value = "true" else value = "false" end
			else
				value = tp
			end
		end
		
		if 1 == i then
			msg = value or " "
		else
			msg = msg .. "--" .. (value or "nil")
		end
	end
	print(msg)
	writeLog(msg.."\n")
end
-- 用于打印表内的成员变量
function printFormatLog(logs, tableName, specifiedLogFile)
	if LOG_SWITCH ~= true then return end
	local msg = "\n{\n"
	if tableName then msg = string.format("\n%s =%s", tableName, msg) end
	for _,log in ipairs(logs) do
		local logtype = type(log[2])
		if logtype == "string" then
			msg = string.format("%s	%s = %s\n", msg, log[1], log[2])
		elseif logtype == "table" then
			for k,v in ipairs(log[2]) do
				local t = type(v)
				if t ~= "function" then
					if t ~= "string" then v = tostring(v) end
					if k ~= "string" then k = tostring(k) end
					msg = string.format("%s	%s[%s] = %s\n", msg, log[1], k, v)
				end
			end
		else
			msg = string.format("%s	%s = %s\n", msg, log[1], tostring(log[2]))
		end
	end
	msg = string.format("%s}\n", msg)
	print(msg)
	writeLog(msg, specifiedLogFile)
end

function writeLog( msg , specifiedLogFile)
	if true ~= LOG_SWITCH then return end
	local file = FileIOManager.new()
	local filename = specifiedLogFile or "game.log"
	file:setFile(filename)
	file.filePath = DeviceManager.getExternalDir() .. filename
	local tab=os.date("*t")
	local str = string.format("[%d/%02d/%02d %02d:%02d:%02d]",tab.year, tab.month, tab.day, tab.hour, tab.min, tab.sec)
	file:writeData(str..msg)
end

function writeGuid( msg , specifiedLogFile)
	local file = FileIOManager.new()
	local filename = specifiedLogFile or "gameguid.log"
	file:setFile(filename)
	file.filePath = DeviceManager.getExternalDir() .. filename
	file:writeData(msg)
end

function moveLogToExternalDir()
	local fileName = "game.log"
	local oldPath = cc.FileUtils:getInstance():getWritablePath() .. fileName
	local newPath = DeviceManager.getExternalDir() .. fileName
	return FileManager:moveFile(oldPath, newPath)
end

function SetLogWriteLog()
	local file = FileIOManager.new()
	file:setFile("gameTest.log")
	file.filePath = DeviceManager.getExternalDir() .. "gameTest.log"
	file:open("a+")
	local function writeLogFun(fileName, logStr)
		file:write(logStr)
	end
	CLuaCall:GetInstance():setWriteLogHandle(writeLogFun)
end

function writeError(msg)
	if LOG_SWITCH then return end
	if GameDataUser.shared().userID then
		cc.UserDefault:getInstance():setIntegerForKey("errloguserid", GameDataUser.shared().userID or 0)
	end
	writeLog(msg, "luaerr.log")
end

function startUploadErrLog()
	if LOG_SWITCH then return end
	local filePath = DeviceManager.getExternalDir() .. "luaerr.log"
	if FileIOManager.fileIsExist(filePath, true) then
		local userid = cc.UserDefault:getInstance():getIntegerForKey("errloguserid") or 0
		local function success()
			FileManager:removeFile(filePath)
		end
		local isPhone = 0
		if DeviceManager.isPhone() then isPhone = 1 end
		local url = string.format("%s?userid=%d&channelid=%d&version=%s&imei=%s&phonemode=%s&phonesn=%s&isphone=%d",
			URLConfig.errorUpload, userid, QDChannel, APP_VERSION, DeviceManager.IMEI(), DeviceManager.mobileModel(), DeviceManager.getSerialNum(), isPhone)
		HttpManager:uploadRequest(url, filePath, success)
	end
end

