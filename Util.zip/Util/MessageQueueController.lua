--[[
	消息队列控制器
]]
MessageQueueController = class("MessageQueueController")
MessageQueueController.messageQueue = {}
MessageQueueController.delayFlag = false
MessageQueueController.parent = nil
-- 单例
function MessageQueueController.shared()
	if nil == _G["MessageQueueController.obj"] then
		_G["MessageQueueController.obj"] = MessageQueueController.new()
	end
	return _G["MessageQueueController.obj"]
end
-- 将消息压入消息队列
function MessageQueueController:pushMessage(data)
	table.insert(self.messageQueue, data)
	print("#self.messageQueue lenth", #self.messageQueue)
end
-- 将消息取出消息队列
function MessageQueueController:popMessage()
	if self.messageQueue and table.getn(self.messageQueue) > 0 then
		local data = self.messageQueue[1]
		table.remove(self.messageQueue, 1)
		print("pop messageQueue lenth", #self.messageQueue)
		return data
	end
	return nil
end
-- 将消息队列清空
function MessageQueueController:clearMessageQueue()
	if self.messageQueue then
		self.messageQueue = {}
		self.delayFlag = false
	end
end
-- 获取消息个数
function MessageQueueController:getMessageNum()
	return #self.messageQueue
end
-- 设置parent
function MessageQueueController:setParent(obj)
	self.parent = obj
end
-- 终止延迟动作
function MessageQueueController:stopDelayAct()
	if self.parent then
		self.delayFlag = false
		self.parent:stopAllActions()
	end
end
-- 执行消息对应的回调
function MessageQueueController:executeMessageCall()
	if self.delayFlag then return false end
	local message = self:popMessage()
	if message then
		if message.mDelay then
			self.delayFlag = true
			local function delayCall()
				self.delayFlag = false
			end
			if message.callFunc then message.callFunc(message.pbDataParsed) end
			if self.parent then
				self.curAct = performWithDelay(self.parent, delayCall, message.mDelay)
			end
		else
			printLog("message id", message.wMainCmdID, message.wSubCmdID)
			if message.callFunc then message.callFunc(message.pbDataParsed) end
		end
	end
	return true
end

return MessageQueueController
