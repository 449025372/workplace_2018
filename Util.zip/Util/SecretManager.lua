--[[
-- 单机内存数据加密解密管理类
-- Author: KKU28
-- Date: 2014-12-05 15:00:00
]]
SecretManager  = class("SecretManager")

function SecretManager.shared()
	if nil == SecretManager.obj then
		SecretManager.obj = SecretManager.new()
		SecretManager.obj:initSecretKey()
	end
	return SecretManager.obj
end
-- 随机生成一个密钥
function createSecretKey(  )
	math.randomseed(os.time())
	local mod = 62 							-- 1~9,A~Z,a~z,0 总共62个字符
	local keyLen = math.random(20,25) 		-- 密钥长度
	local key = ""
	-- string.char(97)
	for i=1,keyLen do
		local ranNum = math.random(1,mod) % mod --0,1~9,A~Z,a~z
		local letter = "0"
		if ranNum>=1 and ranNum <=9 then
			letter =  string.char(48+ranNum)
		elseif ranNum >=10 and ranNum <=10 + 26 - 1 then 
			letter =  string.char(65+ranNum-10)
		elseif ranNum >= 10+26 and ranNum <= 10+26+26-1 then 
			letter =  string.char(97+ranNum-10-26)
		end
		key = string.format("%s%s",key,letter)
	end
	print("createSecretKey:")
	print("key",key)
	return key
end
-- 每次运行得到一个密钥进行加密
function SecretManager:initSecretKey()
	if not self.secretKey then
		SecretManager.secretKey = createSecretKey(  )
		print("SecretManager.secretKey",SecretManager.secretKey)
	end
end

-- 加密一个数
function SecretManager:makeSecret( num )
	print("++++++type(num)",type(num))
	-- self.secretKey
	local numStr = tostring(num)
	local key = SecretManager.secretKey
	print("加密前，numStr:",numStr)
	-- local ans = SecretManager:encryStr( numStr,key )
	local ans = EncryptManager.bxorEncryptDecrypt(numStr, key)
	print("加密后，md5Apstr",ans)
	return ans
end

-- 解密成一个数
function SecretManager:unSecret( str )
	print("需要解密的字符串：",str)
	-- local ans = SecretManager:decryStr( str,SecretManager.secretKey )
	local key = SecretManager.secretKey
	local ans = EncryptManager.bxorEncryptDecrypt(str, key)
	local ansNum = tonumber(ans)
	print("ansNum:",ansNum)
	return ansNum
end

-- 加密
function SecretManager:encryStr( str,key )
	if not str or not key then return end
	local strLen = string.len(str)
	local keyLen = string.len(key)
	local minLen = strLen
	if keyLen < minLen then 
		minLen = keyLen
	end
	local ansLen = strLen
	local ans = ""
	for i=1,minLen do
		local sChar = string.sub(str,i,i)--str[i]
		local kChar = string.sub(key,i,i)--key[i]
		print("sChar",sChar)
		print("kChar",kChar)
		local sByte = string.byte(sChar)--string.char函数和string.byte
		local kByte = string.byte(kChar)
		print("sByte",sByte)
		print("kByte",kByte)
		local aByte = bit.bxor(sByte,kByte)
		print("aByte",aByte)
		-- aByte = aByte %256
		print("%aByte:",aByte)
		local aChar = string.char(aByte)
		ans = ans..aChar
		print("aByte,aChar",aByte,aChar)
		print("ans:--",ans)
	end
	print("1 ans:",ans)
	if strLen > keyLen then 
		for i = minLen+1,strLen do 
			ans = ans..string.sub(str,i,i)--str[i]
		end
	end
	print("2 ans:",ans)
	return ans
end

-- 解密
function SecretManager:decryStr( ans,key )
	if not ans or not key then return end
	local ansLen = string.len(ans)
	local keyLen = string.len(key)
	local minLen = ansLen
	if keyLen < minLen then 
		minLen = keyLen
	end
	local str = ""
	local strLen = ansLen
	for i=1,minLen do	
		local aChar = string.sub(ans,i,i)--str[i]
		local kChar = string.sub(key,i,i)--key[i]
		print("aChar",aChar)
		print("kChar",kChar)
		local aByte = string.byte(aChar)--string.char函数和string.byte
		local kByte = string.byte(kChar)
		print("aByte",aByte)
		print("kByte",kByte)
		local sByte = bit.bxor(aByte,kByte)
		print("sByte",sByte)
		-- sByte = sByte %256
		print("%sByte:",sByte)
		local sChar = string.char(sByte)
		str = str..sChar
		print("aByte,aChar",sByte,sChar)
		print("str:--",str)
	end
	if ansLen > keyLen then 
		for i = minLen+1,ansLen do 
			str = str..string.sub(ans,i,i)--str[i]
		end
	end
	print("解密后得到：str",str)
	return str
end