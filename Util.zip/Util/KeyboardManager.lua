KeyboardManager = class()

local targetPlatform = cc.Application:getInstance():getTargetPlatform()

KeyboardManager.Type = {
	UIKeyboardTypeDefault = 0,                -- Default type for the current input method.
    UIKeyboardTypeASCIICapable = 1,           -- Displays a keyboard which can enter ASCII characters, non-ASCII keyboards remain active
    UIKeyboardTypeNumbersAndPunctuation = 2,  -- Numbers and assorted punctuation.
    UIKeyboardTypeURL = 3,                    -- A type optimized for URL entry (shows . / .com prominently).
    UIKeyboardTypeNumberPad = 4,              -- A number pad (0-9). Suitable for PIN entry.
    UIKeyboardTypePhonePad = 5,               -- A phone pad (1-9, *, 0, #, with letters under the numbers).
    UIKeyboardTypeNamePhonePad = 6,           -- A type optimized for entering a person's name or phone number.
    UIKeyboardTypeEmailAddress = 7,           -- A type optimized for multiple email address entry (shows space @ . prominently).默认英文输入
    UIKeyboardTypeDecimalPad = 8,             -- A number pad with a decimal point.
    UIKeyboardTypeTwitter = 9,                -- A type optimized for twitter text entry (easy access to @ #)
    UIKeyboardTypeWebSearch = 10,             -- A default keyboard type with URL-oriented addition (shows space . prominently).
    UIKeyboardTypeAlphabet = 11,              -- UIKeyboardTypeASCIICapable, -- Deprecated
    UIKeyboardTypePassword = 12,              -- 默认英文输入发，但显示为密文
    --UIKeyboardTypeChinesePad = 13             -- 默认中文输入  
}

function KeyboardManager.setKeyboardType(type)
	if (cc.PLATFORM_OS_IPHONE == targetPlatform) or (cc.PLATFORM_OS_IPAD == targetPlatform) then
		local args = {type = type}
	    
	    local className = "CCEAGLView"
	    local ok  = luaoc.callStaticMethod(className,"setKeyboardType",args)
	    if not ok then
	        print("luac error:", ok)
	    end
	end
	 if (cc.PLATFORM_OS_ANDROID == targetPlatform) then
         
         local args = {type}
         local sigs = "(I)V"
         local className = "com/lexun/game/cocos2dx/Lua_SDK"
         local ok,_  = luaj.callStaticMethod(className,"setKeyboardType",args,sigs)
         if not ok then
	        print("luac error:", ok)
	    end
      end
end

function KeyboardManager.setKeyboardTypeToDefault()
	KeyboardManager.setKeyboardType(KeyboardManager.Type.UIKeyboardTypeDefault)
end

