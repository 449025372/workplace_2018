EncryptManager = class()

function EncryptManager.encryptDataSixteen(data)
	local result = ""
	for i=1,#data do
		local ch = string.format("%02x",string.byte(data,i,i))
        result = result .. ch
    end
    return result
end

function EncryptManager.encryBuffer(data)
   return  EncryDecryToLua:encryBuffer(data,#data)
end

function EncryptManager.decryptBuffer(data)
    return  EncryDecryToLua:decryptBuffer(data,0, #data)
end

function EncryptManager.MD5Encry(data)
    return  EncryDecryToLua:MD5Encry(#data,data,0)
end

--strIn 需要加密的字符串，strKey加密的秘钥 ，返回加密后的密文字符串 
function EncryptManager.Des_Encrypt(strIn,strKey)
    return  EncryDecryToLua:Des_EncryDecry(#strIn,strIn,#strKey,strKey)
end

--strIn 需要解密的字符串，strKey解密的秘钥 ，返回解密后的明文字符串
function EncryptManager.Des_Decrypt(strIn,strKey)
    return  EncryDecryToLua:Des_EncryDecry(#strIn,strIn,#strKey,strKey,false)
end

function EncryptManager.bxorEncryptDecrypt(inStr, key)
    if nil == inStr or nil == key then return "" end
    inStr = tostring(inStr)
    key = tostring(key)
    local keyArrray = {}
    local keyNum = #key
    for i=1,keyNum do
        table.insert(keyArrray, string.byte(key:sub(i,i)))
    end
    local outStr = ""
    for i=1,#inStr do
        local index = i%keyNum + 1
        outStr = outStr .. string.char(bit.bxor(string.byte(inStr:sub(i,i)), keyArrray[index]))
    end
    return outStr
end
