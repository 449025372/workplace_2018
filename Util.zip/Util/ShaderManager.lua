-- 着色器效果管理器，仅适用于sprite，在部分机型上存在兼容问题
ShaderManager = class("ShaderManager")

function ShaderManager.shared()
	if nil == _G["ShaderManager.obj"] then
		_G["ShaderManager.obj"] = ShaderManager.new()
	end
	return _G["ShaderManager.obj"]
end

function ShaderManager:get2DMaterial()
	local properties = cc.Properties:createNonRefCounted("shaders/2d_effects.material#list")
	local mat = cc.Material:createWithProperties(properties)
	return mat
end

-- 模糊精灵
function ShaderManager:setBlur(sprite)
	local mat = self:get2DMaterial()
	sprite:setGLProgramState(mat:getTechniqueByName("blur"):getPassByIndex(0):getGLProgramState())
end

-- 灰度精灵
function ShaderManager:setGray(sprite)
	local mat = self:get2DMaterial()
	sprite:setGLProgramState(mat:getTechniqueByName("gray"):getPassByIndex(0):getGLProgramState())
end

-- 外发光精灵
function ShaderManager:setOutline(sprite)
	local mat = self:get2DMaterial()
	sprite:setGLProgramState(mat:getTechniqueByName("outline"):getPassByIndex(0):getGLProgramState())
end

-- 生成当前场景的模糊精灵
--FIX 该方法目前生成的图像会白屏
function ShaderManager:createBlurScreenSprite(parent, resolution)
	resolution = resolution or {w = display.width, h = display.height}
	local texture = cc.RenderTexture:create(resolution.w, resolution.h, cc.TEXTURE2_D_PIXEL_FORMAT_RGB_A8888)
	local scene = parent or cc.Director:getInstance():getRunningScene()
	if not texture then return end

	-- texture:setAnchorPoint(cc.p(0, 0))
	texture:beginWithClear(0, 0, 0, 0)

	scene:visit()

	texture:endToLua()

	local sprite = cc.Sprite:createWithTexture(texture:getSprite():getTexture())
	sprite:setFlippedY(true)
	-- sprite:setColor(cc.GREEN)
	self:setBlur(sprite)

	return sprite
end

-- 截屏并模糊，用以代替RenderTexture方法
function ShaderManager:createBlurCaptured(parent, zorder)
	self:deleteBlurCaptured(parent)
	local scene = parent or cc.Director:getInstance():getRunningScene()
    local function afterCaptured(succeed, outputFile)
        if succeed then
            local sp = cc.Sprite:create(outputFile)
            sp:setPosition(display.center)
            sp:setScale(1.15, 1.15)
            self:setBlur(sp)
            scene:addChild(sp, zorder or 10, 800)
            self.outPutFile = outputFile
        else
            print("Capture screen failed.")
        end
    end	
	cc.utils:captureScreen(afterCaptured, "blur_capture.png")
end

-- 及时清理模糊截屏
function ShaderManager:deleteBlurCaptured(parent)
	local scene = parent or cc.Director:getInstance():getRunningScene()
	if scene:getChildByTag(800) then
		scene:removeChildByTag(800)
		if self.outPutFile then
			cc.Director:getInstance():getTextureCache():removeTextureForKey(self.outPutFile)
			self.outPutFile = nil
		end
	end
end





