-- ios appstore
StoreKitManager = class()

local targetPlatform = cc.Application:getInstance():getTargetPlatform()

-- return bool，是否可以购买
function StoreKitManager.canMakePayments()
    if (cc.PLATFORM_OS_IPHONE == targetPlatform) or (cc.PLATFORM_OS_IPAD == targetPlatform) then
        local args = nil
        
        local className = "StoreKitBinding"
        local ok,ret  = luaoc.callStaticMethod(className,"canMakePayments",args)
        if not ok then
            cc.Director:getInstance():resume()
        else
            print("The ret is:", ret)
        end
        return ret
    end
    return false
end

-- 购买物品，参数：_productId物品ID，_quantity数量
function StoreKitManager.purchaseProduct(productId, quantity)
    if (cc.PLATFORM_OS_IPHONE == targetPlatform) or (cc.PLATFORM_OS_IPAD == targetPlatform) then
        local function purchaseCallBack(state, data)
            print(state)
            print(data)
            DialogManager.alert(data)
        end

        
        local args = {scriptHandler = purchaseCallBack}
        local className = "StoreKitBinding"
        local ok,_  = luaoc.callStaticMethod(className,"setScriptHandler",args)
        if not ok then
            cc.Director:getInstance():resume()
        else
            print("The ret is: ok")
        end

        args = {productId = productId, quantity = quantity}
        local okT,retT  = luaoc.callStaticMethod(className,"purchaseProduct",args)
        if not okT then
            cc.Director:getInstance():resume()
        else
            print("The ret is:", retT)
        end
    end
end
