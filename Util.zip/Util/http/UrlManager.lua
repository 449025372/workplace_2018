-- http urls
UrlManager = class("UrlManager")

-- 根据当前游戏调用相应的url
UrlManager.urlsAspx = {
	[1] = {
		helpPage = "http://d7.lxyes.com/resource/htmlhelps/game_help.html",
	},
	[2] = {
		helpPage = "http://d7.lxyes.com/resource/htmlhelps/porker_wt.html",
		newHelpPage = "http://d7.lxyes.com/resource/htmlhelps/winthree_rule.html",
	},
	[3] = {
		helpPage = "http://d7.lxyes.com/resource/htmlhelps/porker_dz.html",
		newHelpPage = "http://d7.lxyes.com/resource/htmlhelps/game_help_dz.html",
	},
	[4] = {
		helpPage = "http://d7.lxyes.com/resource/htmlhelps/porker_bz.html",
	},
	[5] = {
		--helpPage = "http://d7.lxyes.com/resource/htmlhelps/help_fish.html",
	},
	[7] = {
		helpPage = "http://d7.lxyes.com/resource/htmlhelps/help_mahjong.html",
		newHelpPage = "http://d7.lxyes.com/resource/htmlhelps/help_mahjong_4.html",
	},
	[8] = {
		helpPage = "http://d7.lxyes.com/resource/htmlhelps/niuniu.html",
		newHelpPage = "http://d7.lxyes.com/resource/htmlhelps/niuniu_betgame_help.html",
	},
	[10] = {
		helpPage = "http://d7.lxyes.com/resource/htmlhelps/help_kss_old.html", -- 金三顺帮助页
		newHelpPage = "http://d7.lxyes.com/resource/htmlhelps/game_help_kss.html",
	},
	[12] = {
		helpPage = "http://d7.lxyes.com/resource/htmlhelps/help_mahjong_sm.html",
		-- newHelpPage = "http://d7.lxyes.com/resource/htmlhelps/help_mahjong_sm.html",
	},
}

-- 公用的url
UrlManager.urlsAspxCommon = {
	checkVersion = "http://ddzweb.lexun.com/Landlordhttp/gameversioncheck.aspx",	-- 版本请求
	goldToStone = "http://ddzweb.lexun.com/exchange/gtostone.aspx",					-- 金币兑换乐币
	stoneToGold = "http://ddzweb.lexun.com/exchange/stonetog.aspx",					-- 乐币兑换金币
	webStore = "http://ddzweb.lexun.com/gift/index.aspx",							-- web商城
	cardPay = "http://cz.lexun.com/landlord/mobilepay.aspx",						-- 充值卡充值
	bankPay = "http://cz.lexun.com/landlord/unionpay.aspx",							-- 银联充值
	genOrders = "http://ddzweb.lexun.com/exchange/genorders.aspx",					-- 获取订单号
	-- aliPay = "http://cz.lexun.com/landlord/alipaynew.aspx",							-- 支付宝充值
	aliPay = "http://cz.happysai.cn/clientpay/alibuy.aspx",							-- 支付宝充值
	iconPath = "http://ddzdown.lxyes.com/icon/",								-- 头像下载地址
	wxPay = "http://cz.lexun.com/landlord/wxpay.aspx",								-- 斗地主微信充值

	--share = "http://lxgame.lexun.com/Landlord/share.aspx",							-- 上传分享数据
	share = "http://lxgame.lexun.com/landlord/activity/down.php",				-- 分享链接
	uploadHeadIcon = "http://ddzweb.lexun.com/landlord/UploadIcon.aspx",			-- 上传头像
	questionAdd = "http://ddzweb.lexun.com/landlord/QuestionAdd.aspx",				-- 提交意见反馈
	login = "http://lxgame.lexun.com/Landlord/Login/login.aspx",					-- 账号登录
	quickLogin = "http://lxgame.lexun.com/Landlord/Login/autoregister.aspx",		-- 快速登录
	findpwd = "http://lxgame.lexun.com/Landlord/Login/findpwd.aspx",				-- 密码找回
	register = "http://lxgame.lexun.com/Landlord/Login/register.aspx",				-- 账号注册
	modifypwd = "http://lxgame.lexun.com/Landlord/Login/modifypwd.aspx",			-- 修改密码
	bindphone = "http://lxgame.lexun.com/Landlord/Login/bindphone.aspx",			-- 账号手机绑定
	nickEdit = "http://lxgame.lexun.com/Landlord/Login/editnick.aspx",				-- 昵称修改
	sexEdit = "http://lxgame.lexun.com/Landlord/Login/editsex.aspx",				-- 性别修改
	exchangeLimit = "http://ddzweb.lexun.com/exchange/maxExchange.aspx",			-- 乐币兑换额度

	coinDeclare = "http://ddzweb.lexun.com/resource/htmlhelps/coin.html",			-- 金币申明
	privacyDeclare = "http://ddzweb.lexun.com/resource/htmlhelps/privacy.html",		-- 隐私申明
	userDeclare = "http://ddzweb.lexun.com/resource/htmlhelps/user.html",			-- 用户申明

	pushUrl = "http://ddzweb.lexun.com/LandlordHttp/getpushmsglist.aspx",			-- 推送地址

	shareCoin = "http://ddzweb.happysai.cn/landlordhttp/sharerewardapp.aspx",       --分享送金币
}

function UrlManager.getGameUrl()
	return UrlManager.urlsAspx[CURRENT_GAME]
end
