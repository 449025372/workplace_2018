-- 登录、账号相关的http请求
LXLoginManager = class()
LXLoginManager.phoneNum = nil--手机号
LXLoginManager.verification = nil--验证码
LXLoginManager.lxID = nil--修改密码用户ID
LXLoginManager.userEncrypStr = "lxUserEncrypStr"
LXLoginManager.userEncryptKey = "lxUserEncryptKey"
LXLoginManager.localTimeKey = "LocalTimeKey"
LXLoginManager.reloginIndex = "ReloginIndex"
LXLoginManager.iosToken = "" -- 存放ios推送用的token

local desKey = "$Lx8DdZ#"
local md5ApStr = "WFF2IEWDCRC74WT9BEA2ETGUA502MUT"
local md5RStr = "DDF29B1DC8C74BD9BEA2E353A502C91B"

-- des加密，组装http参数
local function getDesStr(pbBase, pbData)
    local desStr = EncryptManager.Des_Encrypt(pbData, desKey)
    desStr = EncryptManager.encryptDataSixteen(desStr)
    local desBase = EncryptManager.Des_Encrypt(pbBase, desKey)
    desBase = EncryptManager.encryptDataSixteen(desBase)
    local md5Str = EncryptManager.MD5Encry(desStr .. desKey)
    return string.format("pbBase=%s&pbData=%s&ckCode=%s", desBase, desStr, md5Str)
end

local function randomString(num)
    local str="abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
    math.randomseed(os.time()) 
    local t = {}
    for i=0,num do
        local n=math.random(1,62)
        t[#t + 1] = string.char(str:byte(n))
    end

    return table.concat(t,"")
end
-- 组装http头数据
local function getHeadStr()
    local token = "3621444383666420455"
    local encryJson={}

    math.randomseed(os.time()) 
    local num = deepRandom(-9,90)
    encryJson.str = randomString(num)

    local paraStr = string.format("%s%d%s", token, num, encryJson.str)
    encryJson.temStr = EncryptManager.MD5Encry(paraStr)
    encryJson.temStr = EncryptManager.encryptDataSixteen(encryJson.temStr)
    encryJson.token = token
    encryJson.num = tostring(num)

    local headStr = string.format('{"rows":[%s]}', JsonManager.encode(encryJson))
    return {{field = "User-lexun", value = headStr}}
end

local function alertErrorInfo(data)
    local errorType = data.errortype
    if (not errorType or "0" ~= errorType) and data.msg and data.msg ~= "" then
        showScaleTip(data.msg or I18NString("GetInfo_InfoError"))
    end
end

local function httpGetData(url, successCall, failedCall, header,_,getType)
    -- {"msg":"请输入正确的验证码.","errortype":"106"} --errortype = 0正确
    local function httpSuccess(data)
        if nil ~= successCall then successCall(data) end      
        alertErrorInfo(data)
    end
    local function httpFailed(errorCode)
        if nil ~= failedCall then failedCall(errorCode) end
    end

    HttpManager.new():luaHttpPostRequest(url, httpSuccess, httpFailed, header,_,getType)
end

-- 访问兑换商城
function LXLoginManager.openWebStore()
    LayerManager:getInstace():openLayer(LayerManager.layersDef.ExchangeMainLayer)
    if 1 then return end
    function openStore()
        local encryptStr = GameDataUser.shared().userEncrypStr or ""
        local encryptKey = GameDataUser.shared().userEncryptKey or ""
        local encode = require("src.Util.URIManager")
        local rand = deepRandom(0, 10000)
        local para = string.format("userencrypstring=%s&userencryptkey=%s&rand=%d", encode.uri_encodeEx(encryptStr), encode.uri_encodeEx(encryptKey), rand)
        local url = string.format("%s?%s", UrlManager.urlsAspxCommon.webStore, para)
        -- url = "http://www.baidu.com"
        local header = getHeadStr()
        print("url", url)

        LXLoginManager.enterWebStore = true
        -- WebViewManager.showBrowser(url, "", "")
        WebViewManager.showBrowser(url, header[1].field, header[1].value)
        -- 暂时以浏览器运行商城
        -- ThirdManager.openUrl(url)
    end

    PersonCenterModel:getInstace():isBindingIphone(function(isbind)
        if isbind then
            openStore()
        else
            local function ok(sender)
                SceneManager:enterBindingLayer()
                sender:removeFromParent()
            end
            confirm("请先绑定手机才可使用商城，是否前往绑定？", ok)
        end
    end)
end

--账号密码登陆
function LXLoginManager.accountLoginLexun(account, password, successCall, failedCall,codeNum)
    HttpManager.requestType = LXACCOUNTLOGINING
	LXLoginManager.clearUserEncryptStr() -- 登录前要清理已存在的串号
    GameDataUser.shared():resetNewLXUserInfo() --登录回调中设置过的属性，在重新登录时需要清除掉
    local para = LXLoginManager.lxLoginPB(account, password,codeNum)
    local url = string.format("%s?%s", UrlManager.urlsAspxCommon.login, para)

    httpGetData(url, successCall, failedCall, getHeadStr(),_,"pbdata")
end
-- 账号密码登录时需要发送的pb消息封装
function LXLoginManager.lxLoginPB(account, password, codeNum)
    local obj = LoginPB_pb.PBLoginParams()

    math.randomseed(os.time())
    if account and type(account) ~= "string" then
        account = tostring(account)
    end
    obj.account = account or ""--or "40855201"
    if password then
        password = EncryptManager.MD5Encry(password)
    end
    obj.password = password or ""--or EncryptManager.MD5Encry("cc123456")
    obj.validcode = codeNum or ""

    return getDesStr(LXLoginManager.lxLoginPBBase(), obj:SerializeToString())
end
--绑定小号时验证
function LXLoginManager.bindSubUser(account,password,onSuccess)
    local function onSuccessCall(data)
        if data then
            local pbMsg = LoginPB_pb.PBValidate_Return()
            pbMsg:ParseFromString(data)
            if onSuccess then
                onSuccess(pbMsg)
            end
        end
    end
    local function onFail()
    end
    local para = LXLoginManager.lxLoginPB(account,password)
    local url = string.format("%s?%s","http://lxgame.lexun.com/landlord/login/validateuser.aspx",para)
    httpGetData(url, onSuccessCall, onFail, getHeadStr())
end

-- 快速注册lx账号
function LXLoginManager.quickRegisterLexun(code, successCall, failedCall)
    HttpManager.requestType = LXQUICKLOGINING
	LXLoginManager.clearUserEncryptStr() -- 登录前要清理已存在的串号
    GameDataUser.shared():resetNewLXUserInfo() --登录回调中设置过的属性，在重新登录时需要清除掉
    local para = LXLoginManager.lxQuickLoginPB(code)
    local url = string.format("%s?%s", UrlManager.urlsAspxCommon.quickLogin, para)

    httpGetData(url, successCall, failedCall, getHeadStr())
end
-- 快速登录时需要发送的pb消息封装
function LXLoginManager.lxQuickLoginPB(code)
    local obj = LoginPB_pb.PBAutoRegisterParams()
    math.randomseed(os.time())
    obj.validcode = code or ""
    obj.randkey = tostring(deepRandom(0, 10000))
    obj.sign = EncryptManager.MD5Encry(md5RStr .. obj.randkey)
    print("obj.validcode,obj.randkey,obj.sign",obj.validcode,obj.randkey,obj.sign)
    if string.len(obj.sign) > 32 then obj.sign = string.sub(obj.sign, 1, 32) end
    -- print(obj.sign)
    -- print(string.len(obj.sign))

    return getDesStr(LXLoginManager.lxLoginPBBase(), obj:SerializeToString())
end
-- 账号相关操作返回的pb消息解析
-- message PBRegisterLogin_Return{
--     optional string userencrypstring = 1;//加密后的串，用于发给登录服务器
--     optional string encryptkey = 2;//加密后的密钥;用于发给登录服务器
--     optional string nick = 3;//用户昵称
--     optional int64 stone = 4; //乐币
--     optional string phone = 5;//手机号码
--     optional int32 initpwd = 6;//1：标识是第一次修改密码
--     optional int32 isbind = 7;//是否绑定手机 1为未绑定，0为已绑定
--     optional int32 sex = 8;//性别0:女，1:男
--     optional PBMessage msginfo = 9;//返回消息
--     optional int32 viprank = 11;//VIP等级 0:表示不是VIP
--     optional string validcode =12;//返回给客户端的验证码
--     optional int32 iswhiteuser =13;//是否是白名单用户 0需要限制 1白名单用户不限制设备登录
-- }
function LXLoginManager.loginPBReceiver(data, isLogin)
    local receiver = LoginPB_pb.PBRegisterLogin_Return()
    receiver:ParseFromString(data)

    GameDataUser.shared():setNewLXUserInfo(receiver, isLogin)
    -- LXLoginManager.setChangePasswordID(receiver.lxuserid)
    
    print("userencrypstring", receiver.userencrypstring)
    print("userencrypstring len ", string.len(receiver.userencrypstring))
    print("encryptkey", receiver.encryptkey)
    print("encryptkey len ", string.len(receiver.encryptkey))
    print("isbind", receiver.isbind)
    print("phone", receiver.phone) -- 下发的手机号带星号  没有实际作用
    print("lxuserid", receiver.lxuserid)
    print("msginfo.noerror", receiver.msginfo.noerror)
    print("msginfo.errtype", receiver.msginfo.errtype)
    print("msginfo.outmsg", receiver.msginfo.outmsg)
    print("viprank", receiver.viprank)
    print("iswhiteuser", receiver.iswhiteuser)
    return receiver
end

local GETVERIFICATIONCODE = 1
local VALIDATEVERIFICATIONCODE = 2
local RESETPASSWORD = 3
-- 重置密码时，获取验证码, 也可通过传入用户ID来获取验证码
function LXLoginManager.getVerificationCode(phoneNum, userID, successCall, failedCall)
    local para = LXLoginManager.lxResetPasswordPB(phoneNum, password, verification, userID, GETVERIFICATIONCODE)
    local url = string.format("%s?%s", UrlManager.urlsAspxCommon.findpwd, para)

    httpGetData(url, successCall, failedCall, getHeadStr())
end
--  重置密码时，验证验证码
function LXLoginManager.validateVerificationCode(verification, successCall, failedCall)
    local para = LXLoginManager.lxResetPasswordPB(phoneNum, password, verification, userID, VALIDATEVERIFICATIONCODE)
    local url = string.format("%s?%s", UrlManager.urlsAspxCommon.findpwd, para)

    httpGetData(url, successCall, failedCall, getHeadStr())
end
function LXLoginManager.setChangePasswordID(userID)
    LXLoginManager.lxID = userID
end
--  找回密码，重置密码
function LXLoginManager.changePassword(userID, verification, password, successCall, failedCall)
    local para = LXLoginManager.lxResetPasswordPB(phoneNum, password, verification, userID, RESETPASSWORD)
    local url = string.format("%s?%s", UrlManager.urlsAspxCommon.findpwd, para)

    httpGetData(url, successCall, failedCall, getHeadStr())
end
-- 重置密码PB消息封装
-- 返回PBRegisterLogin_Return
-- message PBFindPasswordParams{
--     optional string mobilenum = 1;//手机号码
--     optional int32 userid  = 2;//用户id
--     optional int32 optype = 3;//1:收验证码 2:验证验证码  3:重置密码
--     optional string code = 4;//验证码
--     optional string password = 5;//重置的新密码   
-- }
function LXLoginManager.lxResetPasswordPB(phoneNum, password, verification, userID, requestType)
    local obj = LoginPB_pb.PBFindPasswordParams()

    obj.mobilenum = phoneNum or ""
    obj.userid = userID or 0
    obj.optype = requestType or 0
    obj.code = verification or ""
    obj.password = password or ""

    return getDesStr(LXLoginManager.lxLoginPBBase(), obj:SerializeToString())
end

-- 注册时，获取验证码
function LXLoginManager:getRegistVerificationCode(phoneNum, successCall, failedCall)

end

--账号登陆时验证手机获取验证码
function LXLoginManager:accountLoginGetCode(userid,phone,onSuccess,onFail)
    local obj = LoginPB_pb.PBSendCodeParams()
    obj.userid = userid or ""
    obj.phone = phone or ""
    local pbStr = getDesStr(LXLoginManager.lxLoginPBBase(), obj:SerializeToString())
    local URL = string.format("%s?%s","http://lxgame.lexun.com/landlord/login/sendcode.aspx",pbStr)
    HttpManager:luaHttpPostRequest(URL, onSuccess, onFail,_,true)
end

-- 根据手机号及验证码注册账号
function LXLoginManager:registerAccount(phoneNum, password, vcode, successCall, failedCall, confirmPwd, nickName)
    local para = LXLoginManager.lxRegisterAccountPB(phoneNum, password, confirmPwd, nickName)
    local url = string.format("%s?%s", UrlManager.urlsAspxCommon.register, para)

    httpGetData(url, successCall, failedCall, getHeadStr())
end
-- 注册账号PB消息封装
-- 返回：PBRegisterLogin_Return
-- message PBRegisterParams{
--     optional string phone = 1;//手机号码
--     optional string nick = 2;//昵称，性别，签名
--     optional string password = 3;//密码
--     optional string cofirmpwd = 4;//确认密码
-- }
function LXLoginManager.lxRegisterAccountPB(phoneNum, password, confirmPwd, nickName)
    local obj = LoginPB_pb.PBRegisterParams()

    obj.phone = phoneNum or ""
    obj.nick = nickName or ""
    obj.password = password or ""
    obj.cofirmpwd = confirmPwd or ""

    return getDesStr(LXLoginManager.lxLoginPBBase(), obj:SerializeToString())
end

-- 修改密码
function LXLoginManager.modifyPassword(oldPwd, newPwd, confirmPwd, successCall, failedCall)
    local para = LXLoginManager.lxModifyPasswordPB(oldPwd, newPwd, confirmPwd)
    local url = string.format("%s?%s", UrlManager.urlsAspxCommon.modifypwd, para)

    httpGetData(url, successCall, failedCall, getHeadStr())
end
-- 修改密码PB消息封装
-- 返回：PBModifyPassword_Return
-- message PBModifyPasswordParams{
--     optional string oldpwd = 1;//旧密码
--     optional string newpwd = 2;//新密码
--     optional string pwdconfirm = 3;//新密码
-- }
function LXLoginManager.lxModifyPasswordPB(oldPwd, newPwd, confirmPwd)
    local obj = LoginPB_pb.PBModifyPasswordParams()

    obj.oldpwd = oldPwd or ""
    obj.newpwd = newPwd or ""
    obj.pwdconfirm = confirmPwd or ""

    return getDesStr(LXLoginManager.lxLoginPBBase(), obj:SerializeToString())
end
-- 根据旧密码改新密码pb消息回调
function LXLoginManager.lxModifyPwdPBReceiver(data)
    local receiver = LoginPB_pb.PBModifyPassword_Return()
    receiver:ParseFromString(data)

    if not receiver.msginfo.noerror then
        if receiver.msginfo.outmsg and receiver.msginfo.outmsg ~= "" then
            showScaleTip(receiver.msginfo.outmsg)
        else
            showScaleTip("修改密码失败")
        end
    end
    print("userencrypstring", receiver.userencrypstring)
    print("userencrypstring", string.len(receiver.userencrypstring))
    print("encryptkey", receiver.encryptkey)
    print("encryptkey", string.len(receiver.encryptkey))
    print("msginfo", receiver.msginfo)
    print("msginfo.noerror", receiver.msginfo.noerror)
    print("msginfo.errtype", receiver.msginfo.errtype)
    print("msginfo.outmsg", receiver.msginfo.outmsg)
    return receiver
end

-- 绑定手机获取验证码
function LXLoginManager.lxBindPhoneGetCode(phoneNum, successCall, failedCall)
    local para = LXLoginManager.lxBindPhonePB(phoneNum, code, 1)
    local url = string.format("%s?%s", UrlManager.urlsAspxCommon.bindphone, para)

    httpGetData(url, successCall, failedCall, getHeadStr())
end
-- 绑定手机
function LXLoginManager.lxBindPhone(phoneNum, code, successCall, failedCall)
    local para = LXLoginManager.lxBindPhonePB(phoneNum, code, 2)
    local url = string.format("%s?%s", UrlManager.urlsAspxCommon.bindphone, para)

    httpGetData(url, successCall, failedCall, getHeadStr())
end
-- 手机绑定PB消息封装
-- message PBBindingParams{
--     optional string mobilenum = 1;//手机号码
--     optional string code = 2;//验证码
--     optional int32 optype = 3;//1:提交手机号接收验证码 2:验证验证码，提交数据
-- }
function LXLoginManager.lxBindPhonePB(phoneNum, code, requestType)
    local obj = LoginPB_pb.PBBindingParams()

    obj.mobilenum = phoneNum or ""
    obj.code = code or ""
    obj.optype = requestType or 0

    return getDesStr(LXLoginManager.lxLoginPBBase(), obj:SerializeToString())
end

-- 修改昵称
function LXLoginManager.lxChangeNickName(nickName, successCall, failedCall)
    local para = LXLoginManager.lxInfoChangePB(nickName, nil)
    local url = string.format("%s?%s", UrlManager.urlsAspxCommon.nickEdit, para)

    httpGetData(url, successCall, failedCall, getHeadStr())
end

-- 修改性别
-- function LXLoginManager.lxChangeGender(gender, successCall, failedCall)
    -- local para = LXLoginManager.lxInfoChangePB(nil, gender)
    -- local url = string.format("%s?%s", UrlManager.urlsAspxCommon.sexEdit, para)

    -- httpGetData(url, successCall, failedCall, getHeadStr())
-- end

-- 昵称修改及性别修改PB消息封装
-- //昵称修改 http://lxgame.lexun.com/landlord/editnick.aspx 
-- //昵称修改 http://lxgame.lexun.com/landlord/editsex.aspx
-- //返回：PBMessage
-- message PBEditUserBaseParams{
--     optional string nick = 1;//昵称
--     optional int32 sex = 2;//性别 0:女，1:男
--     optional string signature = 3;//签名
-- }
-- 修改昵称时可以不传性别，修改性别时不用传昵称
function LXLoginManager.lxInfoChangePB(nickName, sex)
    local obj = LoginPB_pb.PBEditUserBaseParams()

    obj.nick = nickName or ""
    obj.sex = sex or 0
    obj.signature = ""

    return getDesStr(LXLoginManager.lxLoginPBBase(), obj:SerializeToString())
end

-- 乐币兑换额度请求
function LXLoginManager.lxExchangeLimitReq(successCall, notShowWait)
    local user = GameDataUser.shared()
    if not user.userID then return end
    -- local para = getDesStr(LXLoginManager.lxLoginPBBase(), "")
    local encryptStr = GameDataUser.shared().userEncrypStr or ""
    local encryptKey = GameDataUser.shared().userEncryptKey or ""
    local encode = require("src.Util.URIManager")
    encryptStr = encode.uri_encodeEx(encryptStr)
    encryptKey = encode.uri_encodeEx(encryptKey)
    local url = string.format("%s?guserid=%d&userencrypstring=%s&userencryptkey=%s", UrlManager.urlsAspxCommon.exchangeLimit, user.userID, encryptStr, encryptKey)
    local function okCall(data)
        if user and data.golds_stone and data.stone_golds then
            print("exchange limit", data.golds_stone, data.stone_golds)
            user.lbMax = data.stone_golds - data.golds_stone
            if user.lbMax < 0 then user.lbMax = 0 end
        end
        if successCall then successCall() end
    end

    HttpManager.new():luaHttpPostRequest(url, okCall, failCall, getHeadStr(), notShowWait)
end

-- 账号操作相关的pb消息回调
-- message PBMessage {
--     optional string outmsg = 1; //输出信息
--     optional int32 errtype = 2; //错误类型
--     optional bool noerror = 3;
-- }
function LXLoginManager.lxPBMessageReceiver(data)
    local receiver = ServerBasePB_pb.PBMessage()
    receiver:ParseFromString(data)
    if not receiver.noerror then
        if receiver.outmsg and receiver.outmsg ~= "" then
            showScaleTip(receiver.outmsg)
        end
    end
    return receiver
end

-- 账号操作需要发送的pbBase参数
-- 基本信息
-- message PBBaseInfo{
--     optional int32 softid = 1;//软件id
--     optional string softvs = 2;//软件版本
--     optional int32 channel = 3;//渠道号
--     optional string imei = 4;//IMEI
--     optional string network = 5; //网络类型
--     optional string mac = 6;//MAC
--     optional string userencrypstring = 7;//加密后的串
--     optional string encryptkey = 8;//加密后的密钥
--     optional string ua = 9;//UA
--     optional string phonebrand = 10;//手机品牌
--     optional string phonemode = 11;//手机型号
--     optional bool isphone = 12;//是否是手机
--     optional string sn = 13;//序列号
--     optional string bluetooth = 14;//蓝牙地址
-- }
function LXLoginManager.lxLoginPBBase()
    local obj = ServerBasePB_pb.PBBaseInfo()
    -- print("imei", DeviceManager.IMEI())
    obj.imei = DeviceManager.IMEI()
    -- 快速注册成功后会返回加密后的串与密钥，需要更新这里的串和密钥以进行后续的账号操作。
    obj.userencrypstring = GameDataUser.shared().userEncrypStr or ""
    obj.encryptkey = GameDataUser.shared().userEncryptKey or ""
    obj.softid = GameDataUser.sid or 872
    obj.softvs = APP_VERSION or ""
    obj.channel = QDChannel or 0
    obj.network = DeviceManager.getNetWork() or ""
    obj.mac = DeviceManager.getMacAddress() or ""
    obj.ua = ""
    obj.phonebrand = DeviceManager.getMobileBrand() or ""
    obj.phonemode = DeviceManager.mobileModel() or ""
    -- DeviceManager.isPhoneReally()
    obj.isphone = SystemManager.getFileContents("/proc/cpuinfo")
    obj.sn = DeviceManager.getSerialNum() or ""
    obj.bluetooth = ""
    obj.specific = LXLoginManager.iosToken or ""

    print("network is", obj.network)
    return obj:SerializeToString()
end

-- 清理用户加密串，重新登录不要传入串，否则报错
function LXLoginManager.clearUserEncryptStr()
    GameDataUser.shared().userEncrypStr = ""
    GameDataUser.shared().userEncryptKey = ""
end

-- 判断用户串是否已存在，如果存在则跳过http登录，直接用保存的串登录游戏服务器
function LXLoginManager.isExistUserEncryptStr(noTime)
    -- local curTime,historyTime = os.time(), LXLoginManager.getLocalTime()
    -- local intervalTime = curTime - historyTime

    -- print("intervalTime", intervalTime)
    -- if intervalTime > 18000 and not noTime then -- 超过5个小时清理一次串,重新登录
    --     printLog("超过5个小时重新登录账号并记录串 ", intervalTime)
    --     return false
    -- end

    local userDefault = cc.UserDefault:getInstance()
    local encryptStr = userDefault:getStringForKey(LXLoginManager.userEncrypStr)
    local encryptKey = userDefault:getStringForKey(LXLoginManager.userEncryptKey)
    if encryptStr ~= "" and encryptKey ~= "" then
        -- if GameDataUser.shared():getGenderLocal() == GameDataUser.InvalidID then return false end
        -- if GameDataUser.shared():getVipLevelLocal() == GameDataUser.InvalidID then return false end
        GameDataUser.shared().userEncrypStr = encryptStr
        GameDataUser.shared().userEncryptKey = encryptKey
        GameDataUser.shared():getEncryptPhoneNumLocal()
        return true
    end
    return false
end

-- 保存串到本地
function LXLoginManager.saveUserEncryptStr(encryptStr, encryptKey)
    local userDefault = cc.UserDefault:getInstance()
    userDefault:setStringForKey(LXLoginManager.userEncrypStr, encryptStr)
    userDefault:setStringForKey(LXLoginManager.userEncryptKey, encryptKey)
    userDefault:flush()
    if ecryptStr ~= "" then
        LXLoginManager.saveLocalTime() -- 保存串的同时保存串的生效时间
    end
end

-- 保存串的存储时间
-- 客户端定期清理一次串，服务端的有效期是串生效起24个小时有效
function LXLoginManager.saveLocalTime()
    local userDefault = cc.UserDefault:getInstance()
    local time = os.time()
    userDefault:setDoubleForKey(LXLoginManager.localTimeKey, time)
    userDefault:flush()
end

-- 获取本地保存的时间
function LXLoginManager.getLocalTime()
    local userDefault = cc.UserDefault:getInstance()
    local time = userDefault:getDoubleForKey(LXLoginManager.localTimeKey)
    return time
end

-- 需要重新登录的标记
function LXLoginManager.saveLxReloginIndex(enable)
    local userDefault = cc.UserDefault:getInstance()
    userDefault:setBoolForKey(LXLoginManager.reloginIndex, enable)
    userDefault:flush()
end

function LXLoginManager.getLxReloginIndex()
    local userDefault = cc.UserDefault:getInstance()
    return userDefault:getBoolForKey(LXLoginManager.reloginIndex, false)
end

-- 用于ios推送，检测是否已获取到设备token
function LXLoginManager.checkIosPushToken()
    local targetPlatform = cc.Application:getInstance():getTargetPlatform()
    if cc.PLATFORM_OS_IPHONE ~= targetPlatform and cc.PLATFORM_OS_IPAD ~= targetPlatform then return end

    local function tokenGetCall(data)
        local localToken = cc.UserDefault:getInstance():getStringForKey("DeviceToken", "")
        LXLoginManager.iosToken = data.iosToken
        if localToken ~= data.iosToken then
            LXLoginManager.saveLxReloginIndex(true)
        end
        cc.UserDefault:getInstance():setStringForKey("DeviceToken", LXLoginManager.iosToken)
        cc.UserDefault:getInstance():flush()
        print("Jacky msg get token", LXLoginManager.iosToken)
    end
    
    LXLoginManager.iosToken = cc.UserDefault:getInstance():getStringForKey("DeviceToken", "")
    LXLoginManager.tokenHandler = NotifyCenter:sharedCenter():addNotify("IosDeviceToken", tokenGetCall)
end

function LXLoginManager.deinitIosTokenListener()
    if not LXLoginManager.tokenHandler then return end
    NotifyCenter:sharedCenter():removeNotify("IosDeviceToken", LXLoginManager.tokenHandler)
end

function LXLoginManager.uploadFeedback(phone, content, filePath, successCallBack, failCallBack)
    local encode = require("src.Util.URIManager")
    local encryptStr = encode.uri_encodeEx(GameDataUser.shared().userEncrypStr) or ""
    local encryptKey = encode.uri_encodeEx(GameDataUser.shared().userEncryptKey) or ""
    local url = string.format("%s?userencrypstring=%s&userencryptkey=%s",
        UrlManager.urlsAspxCommon.questionAdd, encryptStr, encryptKey)

    if filePath and FileManager:fileIsExist(filePath) then
        local userID = GameDataUser.shared().userID or 0
        url = string.format("%s&guserid=%d&phone=%s&content=%s",
            url, userID, phone or "", encode.uri_encode(content) or "")
        HttpManager:uploadRequest(url, filePath, successCallBack, failCallBack)
    else
        HttpManager.new():luaXmlHttpGetRequest(url, successCallBack, failCallBack)
    end
end

function LXLoginManager.uploadHeadIcon(filePath, successCallBack, failCallBack)
    if filePath and FileManager:fileIsExist(filePath) then
        local encode = require("src.Util.URIManager")
        local encryptStr = encode.uri_encodeEx(GameDataUser.shared().userEncrypStr) or ""
        local encryptKey = encode.uri_encodeEx(GameDataUser.shared().userEncryptKey) or ""
        local url = string.format("%s?userencrypstring=%s&userencryptkey=%s&guserid=%d", 
            UrlManager.urlsAspxCommon.uploadHeadIcon, encryptStr, encryptKey, GameDataUser.shared().userID)
        HttpManager:uploadRequest(url, filePath, successCallBack, failCallBack)
    end
end
