-- http网络请求
HttpManager = class()

HttpManager.canShowWaiting = true
HttpManager.status = NONE_MODE
HttpManager.requestType = NONE_MODE

function HttpManager.canShowWaitingFrame()
    HttpManager.canShowWaiting = true
end

function HttpManager.ignoreWaitingFrame()
    HttpManager.canShowWaiting = false
end

-- tips 加载提示（默认为正在连接）
function HttpManager.sendHttp(data, tips)
    print("-----------------HttpManager.sendHttp",HttpManager.canShowWaiting)
    if true == HttpManager.canShowWaiting and not data.singleNotShowWait then
        HttpManager.status = HTTPREQUESTING
    else
        HttpManager.status = NONE_MODE
    end

    local xhr = cc.XMLHttpRequest:new()
    if data.header then -- 如果带有自定义头信息，设置头域
        for _,v in ipairs(data.header) do
            if v.field and v.value then xhr:setRequestHeader(v.field, v.value) end
            print("field:", v.field, v.value)
        end
    end
    xhr.responseType = cc.XMLHTTPREQUEST_RESPONSE_STRING
    -- xhr.timeout = 10000

    -- http加密
    -- local tmpUrlStr = data.urlStr
    -- if (tmpUrlStr.find(tmpUrlStr, "?")) then
    --     tmpUrlStr = tmpUrlStr .. "&"
    -- else
    --     tmpUrlStr = tmpUrlStr .. "?"
    -- end
    -- if "POST" == data.type then
    --     local signStr = string.format("%s%s",tmpUrlStr,data.body)
    --     data.urlStr = string.format("%s%s",tmpUrlStr,HttpManager.GenSignStr(signStr))
    -- else
    --     data.urlStr = string.format("%s%s",tmpUrlStr,HttpManager.GenSignStr(data.urlStr))
    -- end
    print("---------------url", data.type, data.urlStr)
    
    xhr:open(data.type, data.urlStr)
    -- print("---------------readyState", xhr.readyState, xhr.status)
    local function onReadyStateChange()
        HttpManager.status = NONE_MODE

        if xhr.readyState == 4 and (xhr.status >= 200 and xhr.status < 207) then
            HttpManager.requestType = NONE_MODE
            local obj = xhr.response
            local function jsonFunc(srcData)
                print("srcData:",srcData)
                obj = JsonManager.decode(srcData)
                print("obj:",obj)
            end
            if data.specific ~= "pbdata" and pcall(jsonFunc, obj) then
                print(xhr.response)
            else
                print("not json data")
            end
            if data and data.successCallBack then
                data.successCallBack(obj)
            end
        else
            print("-------------http error", xhr.response)
            --错误日志
            -- local msg = string.format("%s errorCode:%s\n [URL:%s]\n",I18NString("RequireHttp_Error"),xhr.response or "nil",data.urlStr)
            -- writeLog(msg)

            if data and data.failCallBack then
                local errorStr = tostring(xhr.response)
                if "" == errorStr or nil == errorCode then errorStr = "httpError" end
                data.failCallBack(errorStr, data.urlStr)
            else
                if LOG_SWITCH then
                    alert(I18NString("http_networkError").."("..xhr.readyState..","..xhr.status..")")
                end
            end
        end
        xhr:unregisterScriptHandler()
    end
    xhr:registerScriptHandler(onReadyStateChange)
    xhr:send(data.body)
end

-- 构造函数
function HttpManager:ctor()
end

-- http Get函数 参数：网址、成功回调、失败回调
function HttpManager:luaXmlHttpGetRequest(urlStr, successCallBack, failCallBack, tips, ignoreJson, notShowWait)
    local data = {}
    data.type = "GET"
    data.urlStr = urlStr
    data.successCallBack = successCallBack
    data.failCallBack = failCallBack
    data.ignoreJson = ignoreJson
    data.singleNotShowWait = notShowWait
    HttpManager.sendHttp(data, tips)
end

-- http POST函数 参数：网址、post数据、成功回调、失败回调
function HttpManager:luaXMLHttpPostRequest(urlStr, body, successCallBack, failCallBack, tips, header, notShowWait)
    local data = {}
    data.type = "POST"
    data.urlStr = urlStr
    data.successCallBack = successCallBack
    data.failCallBack = failCallBack
    data.body = body
    data.header = header
    data.singleNotShowWait = notShowWait
    HttpManager.sendHttp(data, tips)
end

function HttpManager:luaHttpGetRequest(urlStr, successCallBack, failCallBack, header, tips)
    local data = {}
    data.type = "GET"
    data.urlStr = urlStr
    data.successCallBack = successCallBack
    data.failCallBack = failCallBack
    data.header = header
    HttpManager.sendHttp(data, tips)
end

function HttpManager:luaHttpPostRequest(urlStr, successCallBack, failCallBack, header, notShowWait ,type)
    local data = {}
    data.type = "POST"
    data.urlStr = urlStr
    data.successCallBack = successCallBack
    data.failCallBack = failCallBack
    data.header = header
    data.singleNotShowWait = notShowWait
    data.specific = type
    HttpManager.sendHttp(data)
end

function HttpManager:uploadRequest(urlStr, objFile, successCallBack, failCallBack)
    local data = {}
    data.type = "UPLOAD"
    data.urlStr = urlStr
    data.successCallBack = successCallBack
    data.failCallBack = failCallBack
    data.body = objFile
    HttpManager.sendHttp(data, "正在上传，请稍候...")
end

function HttpManager.GenSignStr(url)
    local i = string.find(url, "?")
    local param = ""
    local t = {}
    local addition = ""

    if (nil ~= i) then param = string.sub(url, i + 1, string.len(url)) end
    if (string.len(param) == 0) then
        param = string.format("rnd=%s", os.time())
        addition = param
    end

    local str
    local j = 0
    i = 0
    local k = 0
    local bk = 0
    while true do
        j = i
        i = string.find(param, "&", i + 1)
        if (nil == i) then
            i = string.len(param) + 1
            bk = 1
        end
        str = string.sub(param, j + 1, i - 1)

        local key
        local value
        k = string.find(str, "=")
        if (nil == k) then
            key = str
            value = ""
        else
            key = string.sub(str, 1, k - 1)
            value = string.sub(str, k + 1, string.len(str))
        end
        t[key] = value
        if (bk == 1) then
            break
        end
    end
    local table_key = {}
    for k, v in pairs(t) do
        table.insert(table_key,k)
    end

    table.sort(table_key)
    local plainstr = ""
    for _,key in pairs(table_key) do
        plainstr = string.format("%s%s=%s&", plainstr, key, t[key])
    end
    if (string.len(plainstr) > 0) then
        plainstr = string.sub(plainstr, 1, string.len(plainstr) - 1)
    end
    local md5 = EncryptManager.MD5Encry(plainstr .. "90AF88C8-6F16-4E6A-A5E6-5C8D010FC431")
    local _sign = string.format("_sign=%s", md5)
    if (string.len(addition) > 0) then
        _sign = string.format("%s&%s", addition, _sign)
    end
    return _sign
end

-- 请求支付方式
-- paytype 1: 支付宝 2: 微信
function HttpManager.payTypeReq(paytype, call)
    if not paytype then return end
    local platform = 0
    if cc.Application:getInstance():getTargetPlatform() == cc.PLATFORM_OS_IPHONE or
        cc.Application:getInstance():getTargetPlatform() == cc.PLATFORM_OS_IPAD then
        platform = 1
    end
    local url = string.format("http://ddzweb.happysai.cn/LandlordHttp/getpaytypeconfiglist.aspx?paytype=%d&channelid=%d&mobiletype=%d", paytype, QDChannel, platform)

    local function successCallBack(data)
        if call and data.configlist then call(data.configlist[1]) end
    end
    HttpManager:luaHttpGetRequest(url, successCallBack)
end

-- 联运渠道包 请求支付方式
function HttpManager.channelPayWayReq(productId, call)
    if not productId then return end
    local platform = 0
    if cc.Application:getInstance():getTargetPlatform() == cc.PLATFORM_OS_IPHONE or
        cc.Application:getInstance():getTargetPlatform() == cc.PLATFORM_OS_IPAD then
        platform = 1
    end
    local versionName, versioncode = DeviceManager.getPackageInfo()
    local url = string.format("http://ddzweb.happysai.cn/LandlordHttp/getpaytypeconfig.aspx?productId=%d&channelid=%d&mobiletype=%d&userid=%d&versionName=%s&versioncode=%s", productId, QDChannel, platform, GameDataUser.shared().userID or 0, versionName or 0, versioncode or 0)
    local function successCallBack(data)
        if data and tonumber(data.errorcode) == 1001 then
            showScaleTip(data.errormsg)
            return
        end
        if call then 
            call(data) 
        end
    end
    HttpManager:luaHttpGetRequest(url, successCallBack)
end

-- 数据上报
-- 1 捕鱼任务 2 捕鱼vip按钮 3 捕鱼商城按钮 4 捕鱼一元购 5 捕鱼任意门
function HttpManager.reportLog(para)
    HttpManager.canShowWaiting = false
    local isPhone = 0
    if GameDataUser.shared().isPhone then
        isPhone = 1
    end
    local pbData = HttpInterfacePB_pb.PBUserActionLogParams()
    pbData.userid = tonumber(GameDataUser.shared().userID or 0) 
    pbData.channelid = UIChannel
    pbData.typeid = para.typeid or 0
    pbData.ip = ""
    pbData.imei = DeviceManager.IMEI() or ""
    pbData.phonesn = DeviceManager.getSerialNum() or ""
    pbData.phonemode = DeviceManager.getMobileBrand() or ""
    pbData.isphone = isPhone
    pbData.strguid = GameDataUser.shared().clientguid or ""
    local pbStr = ZZBase64.encode(pbData:SerializeToString())
    local baseUrl = "http://ddzweb.happysai.cn/landlordhttp/user_action_log_add.aspx"
    local url = string.format("%s?pbdata=%s", baseUrl, pbStr)
    local function successCall()
    end
    HttpManager:luaHttpPostRequest(url, successCall)
end