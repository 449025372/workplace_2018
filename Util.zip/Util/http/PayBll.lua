PayBll = class()

---[[paytypeid 4:中国联通卡 1:移动神州行卡, 3:中国电信卡, 2:骏网一卡通]]
--[[pa7_cardNo 充值卡卡号]]
--[[pa8_cardPwd 充值卡密码]]
--[[p3_Amt 充值金额]]
--[[userid 充值用户]]
--[[新版充值卡接口 add datae 2015-01-30 ]] 
PayBll.payList = {"SZX", "JUNNET", "TELECOM", "UNICOM"}
function PayBll.payEx(paytypeid, pa7_cardNo, pa8_cardPwd, p3_Amt, userid, onsuccess,rtype)
    local mobilePayUrl = UrlManager.urlsAspxCommon.cardPay
    local onFail=function (error)
       DialogManager.alert(I18NString("noReachableNetwork"))
    end
    
    local successCall = function(data)
        if "1" == data.result then
            local rechargeType = 4 --默认金币
            if rtype == "Diamond" then rechargeType = 5 end
            local orderID = data.orderid
            local userData = GameDataUser.shared()
            local userEnStr = require("src.Util.URIManager").uri_encodeEx(userData.userEncrypStr)
            local userEnKey = require("src.Util.URIManager").uri_encodeEx(userData.userEncryptKey)
            local url = string.format("%s?userencrypstring=%s&userencryptkey=%s&gorderid=%s&guserid=%s&pa7_cardNo=%s&pa8_cardPwd=%s&paytypeid=%s&p3_Amt=%s&btype=%s", mobilePayUrl, userEnStr, userEnKey, orderID, userData.userID, pa7_cardNo, pa8_cardPwd, paytypeid, p3_Amt, rechargeType)
            local http = HttpManager.new()
            http:luaXmlHttpGetRequest(url, onsuccess, onFail)
        else
            onFail()
        end
    end
    local orderType = 2 --默认金币
    if rtype == "Diamond" then -- 1-8是充金币 9-16充钻石
        orderType = 3
    end
    AlipayManager.getMoneyOrder(PayBll.payList[paytypeid], p3_Amt, successCall, onFail, orderType)
end
