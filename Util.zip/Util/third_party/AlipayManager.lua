AlipayManager = class()
require("src.happysai.protos.HttpInterfacePB_pb")

local payUrl = UrlManager.urlsAspxCommon.aliPay
local targetPlatform = cc.Application:getInstance():getTargetPlatform()

function AlipayManager.isInstalled()
    if (cc.PLATFORM_OS_IPHONE == targetPlatform) or (cc.PLATFORM_OS_IPAD == targetPlatform) then
        local ok,ret = callNative("AlipayRSA", "isInstalled")
        return ret
    end
    return true
end

function AlipayManager.getMoneyOrder(type, price,onSuccess,onFail,rechargeType)
    local userData = GameDataUser.shared()
    local userEnStr = require("src.Util.URIManager").uri_encodeEx(userData.userEncrypStr)
    local userEnKey = require("src.Util.URIManager").uri_encodeEx(userData.userEncryptKey)
    local url = string.format("%s?xtype=%s&guserid=%d&amount=%s&userencrypstring=%s&userencryptkey=%s&viprank=%d&paytype=%d",UrlManager.urlsAspxCommon.genOrders,type,userData.userID,price,userEnStr,userEnKey,userData.vipLevel,rechargeType)
    local http=HttpManager.new()
    http:luaXmlHttpGetRequest(url,onSuccess,onFail)
end

--[[新版斗地主获取订单号地址 2015-06-12]] 
function AlipayManager.payEx(userid,price,goldName,index)
    -- math.random()
    -- math.random()
    -- math.random()
    --local ret = math.random(0, 1)
    --if ret == 0 and targetPlatform == cc.PLATFORM_OS_ANDROID then
    --改成所有充值全到同一个账号
    local flag = true
    if targetPlatform == cc.PLATFORM_OS_ANDROID or flag then
        AlipayManager.otherAccountPay(userid,price,goldName,index)
        return
    end
    local onSuccess=function(data)
        if not data or not data.result or data.result == 0 or data.result == "0" then
            showScaleTip(data.outmsg or "支付失败，请稍候尝试或联系客服人员")
            return
        end
        local payInfo = data.payInfo
        if (cc.PLATFORM_OS_ANDROID == targetPlatform) then
            local function callback(result)
                local data
                if result == "9000" then 
                    data = 1
                elseif result == "-1"  then
                    data = -1
                elseif result == "4000" or result =="6001" then 
                    return
                else
                    data = 0
                end
                NotifyCenter:sharedCenter():postNotify(GameDataUser.Recharge_Updata,data)
                print("alipay callback:",result)
            end
            local args = {payInfo, callback}
            local sigs = "(Ljava/lang/String;I)V"
            local className = "com/lexun/game/cocos2dx/Lua_SDK"
            local ok,ret  = luaj.callStaticMethod(className,"callAlipay",args,sigs)
            if not ok then
                print("luaj error:",ret)
                callNative("com/lexun/game/cocos2dx/alipay/AliPayActivity", "pay", args, sigs)
            else
                print("The ret is:",ret)
            end
        end

        if (cc.PLATFORM_OS_IPHONE == targetPlatform) or (cc.PLATFORM_OS_IPAD == targetPlatform) then
            local function callAlipayCallBack(state, data)
                local result = 0
                if "success" == state then
                    result = 1
                elseif "noAlipay" == data and state == "failed" then 
                    result = -1
                else
                    print("alipay error:",data)
                end
                NotifyCenter:sharedCenter():postNotify(GameDataUser.Recharge_Updata,result)
            end
            local args = {
                payInfo = payInfo,
                appid = AlipayManager.appid,
                publicKey = AlipayManager.publicKey,
                scriptHandler = callAlipayCallBack,
            }
            
            local className = "AlipayRSA"
            local ok,ret  = luaoc.callStaticMethod(className,"callAlipay",args)
            if not ok then
                cc.Director:getInstance():resume()
            else
                print("The ret is:", ret)
            end
        end
    end

    local onFail=function (error)
       DialogManager.alert(I18NString("noReachableNetwork"))
    end

    local successCall = function(data)
        if "1" == data.result then
            local rechargeType = 4 --默认金币
            if index > 8 and index <= 16 then 
                rechargeType = 5
            elseif index == 97 then
                rechargeType = 6
            elseif index == 106 or index == 107 or index == 132 then
                rechargeType = 8
            elseif index > 97 then
                rechargeType = 7
            end
            local orderID = data.orderid
            local userData = GameDataUser.shared()
            print("orderID:",orderID)
            print("rechargeType:",rechargeType)
            local userEnStr = require("src.Util.URIManager").uri_encodeEx(userData.userEncrypStr)
            local userEnKey = require("src.Util.URIManager").uri_encodeEx(userData.userEncryptKey)
            local url = string.format("%s?userencrypstring=%s&userencryptkey=%s&gorderid=%s&amount=%s&guserid=%d&subject=%s&btype=%d",payUrl,userEnStr,userEnKey,orderID,price,userData.userID,goldName,rechargeType)
            local http = HttpManager.new()
            http:luaXmlHttpGetRequest(url,onSuccess,onFail)
        else
            onFail()
        end
    end
    local orderType = 2 --默认金币
    if index > 8 and index <= 16 then -- 1-8是充金币 9-16充钻石
        orderType = 3
    elseif index == 97 then
        orderType = 4
    elseif index == 106 or index == 107 or index == 132 then
        orderType = 6
    elseif index > 97 then
        orderType = 5
    end
    AlipayManager.getMoneyOrder("ALIPAY",price,successCall,onFail,orderType)
end

--  50%概率支付给另一个账户 仅android平台
function AlipayManager.otherAccountPay(userid,price,goldName,index)
    local onSuccess = function(data)
        print("====data:",data)
        local DATA = HttpInterfacePB_pb.PBAliOrderInfo()
        DATA:ParseFromString(data)
        data = DATA
        print("data.result:",data.result)
        print("data.outmsg:",data.outmsg)
        print("data.amount:",data.amount)
        print("data.payinfo:",data.payinfo)
        print("data.userid:",data.userid)
        print("data.remark:",data.remark)

        if not data or not data.result or data.result == 0 or data.result == "0" then
            showScaleTip(data.outmsg or "支付失败，请稍候尝试或联系客服人员")
            return
        end
        local payInfo = data.payinfo
        if (cc.PLATFORM_OS_ANDROID == targetPlatform) then
            local function callback(result)
                local data
                if result == "9000" then 
                    data = 1
                elseif result == "-1"  then
                    data = -1
                elseif result == "4000" or result =="6001" then 
                    return
                else
                    data = 0
                end
                NotifyCenter:sharedCenter():postNotify(GameDataUser.Recharge_Updata, data)
                print("alipay callback:",result)
            end
            local args = {payInfo, callback}
            local sigs = "(Ljava/lang/String;I)V"
            local className = "com/lexun/game/cocos2dx/Lua_SDK"
            local ok,ret  = luaj.callStaticMethod(className,"callAlipay",args,sigs)
            if not ok then
                print("luaj error:",ret)
                callNative("com/lexun/game/cocos2dx/alipay/AliPayActivity", "pay", args, sigs)
            else
                print("The ret is:",ret)
            end
        end
        if (cc.PLATFORM_OS_IPHONE == targetPlatform) or (cc.PLATFORM_OS_IPAD == targetPlatform) then
            local function callAlipayCallBack(state, data)
                local result = 0
                if "success" == state then
                    result = 1
                elseif "noAlipay" == data and state == "failed" then 
                    result = -1
                else
                    print("alipay error:",data)
                end
                NotifyCenter:sharedCenter():postNotify(GameDataUser.Recharge_Updata,result)
            end
            local args = {
                payInfo = payInfo,
                appid = AlipayManager.appid,
                publicKey = AlipayManager.publicKey,
                scriptHandler = callAlipayCallBack,
            }
            
            local className = "AlipayRSA"
            local ok,ret  = luaoc.callStaticMethod(className,"callAlipay",args)
            if not ok then
                cc.Director:getInstance():resume()
            else
                print("The ret is:", ret)
            end
        end
    end

    local onFail = function (error)
       showScaleTip(I18NString("noReachableNetwork"))
    end
    local payUrl = "http://cz.happysai.cn/clientpay/alipay.aspx"
    local  pbData = HttpInterfacePB_pb.PBBuyProductParams()
    pbData.userid = GameDataUser.shared().userID
    pbData.productid = index --和服务器约定的商品id
    pbData.platform = 1
    pbData.channelid = UIChannel
    local pbStr = ZZBase64.encode(pbData:SerializeToString())
    local url = string.format("%s?pbdata=%s",payUrl, pbStr)
    HttpManager:luaHttpPostRequest(url, onSuccess, onFail)
end