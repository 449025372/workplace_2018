local lxWxApi = require("src.Util.third_party.WxApi")
LianlianApi = class("LianlianApi", lxWxApi)

local payUrl = "http://cz.happysai.cn/clientpay/yintongbuy.aspx"
local targetPlatform = cc.Application:getInstance():getTargetPlatform()

--[[新版斗地主获取订单号地址 2015-06-12]] 
function LianlianApi.weChatPay(price,index, url)
    if not WxApi.isPlatformSupported(notTip) then return end

    local onSuccess = function(data)
        print("===data:",data)
        local DATA = HttpInterfacePB_pb.PBWxOrderInfo()
        DATA:ParseFromString(data)
        data = DATA

        print("result:",data.result)
        print("outmsg:",data.outmsg)
        print("prepayid:",data.prepayid)
        print("noncestr:",data.noncestr)
        print("partnerid:",data.partnerid)
        print("timestamp:",data.timestamp)
        print("sign:",data.sign)
        print("remark:",data.remark)
        if data.result == 1 then
            local prepayid = data.prepayid
            local payBackUrl = ""
            local noncestr = data.noncestr
            local appid = WxApi.appid
            local parterid = data.partnerid
            local packageValue = WxApi.package
            local timestamp = data.timestamp
            local sign = data.sign
            if (cc.PLATFORM_OS_ANDROID == targetPlatform) then
                --0 :支付成功    1 :支付错误   2 :取消支付 
                local function callback(result)
                    local data 
                    if result == "0" then 
                        data = 0
                    elseif result == "-1"  then
                        data = -1
                    elseif result == "-2" then
                        data = -2
                    else
                        data = -1000
                    end
                    NotifyCenter:sharedCenter():postNotify(GameDataUser.WechatCharge_Updata,data)
                end
                
                local args = {appid, parterid, prepayid, packageValue, noncestr, timestamp, sign, payBackUrl, callback}
                local sigs = "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;"..
                "Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;I)V"
                local className = "com/lexun/game/cocos2dx/thirdpart/Wxapi"
                local ok,ret  = luaj.callStaticMethod(className,"callWeChatPay",args,sigs)
                if not ok then
                    print("luaj error:",ret)
                else
                    print("The ret is:",ret)
                end
            elseif (cc.PLATFORM_OS_IPHONE == targetPlatform) or (cc.PLATFORM_OS_IPAD == targetPlatform) then
                local function wxCallBack(retcode)
                    NotifyCenter:sharedCenter():postNotify(GameDataUser.WechatCharge_Updata, retcode)
                end
                
                local args = {partnerid=parterid, prepayid=prepayid, package=packageValue, 
                            noncestr=noncestr, timestamp=timestamp, sign=sign, callback=wxCallBack}
                
                local className = "WXApiManager"
                local ok,ret  = luaoc.callStaticMethod(className,"wxPay",args)
                if not ok then
                    cc.Director:getInstance():resume()
                else
                    print("The ret is:", ret)
                end
            end
        else
            if data.outmsg and data.outmsg ~= "" then
                showScaleTip(data.outmsg)
            else
                showScaleTip("支付失败，请稍后重试")
            end
        end
    end

    local onFail = function (error)
       showScaleTip(I18NString("noReachableNetwork"))
    end

    -- local url = string.format("%s?userid=%d&amount=%d",payUrl, GameDataUser.shared().userID, price)
    -- HttpManager.new():luaXmlHttpGetRequest(url,onSuccess,onFail)
    local  pbData = HttpInterfacePB_pb.PBBuyProductParams()
    pbData.userid = GameDataUser.shared().userID
    pbData.productid = index --和服务器约定的商品id
    pbData.platform = UIChannel
    pbData.channelid = UIChannel
    local pbStr = ZZBase64.encode(pbData:SerializeToString())
    if url and url ~= "" then
        payUrl = url
    end
    local url = string.format("%s?pbdata=%s",payUrl, pbStr)
    HttpManager:luaHttpPostRequest(url, onSuccess, onFail)
end

return LianlianApi