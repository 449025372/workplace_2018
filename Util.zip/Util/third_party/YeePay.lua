local YeePay = class("YeePay")

local targetPlatform = cc.Application:getInstance():getTargetPlatform()
-- 创建交易的支付链接
-- payType: 1支付宝
function YeePay:h5Pay(productId, userId, payType, url)
    local payUrl = "http://cz.happysai.cn/clientpay/yeebuy_h5.aspx"
    if url and url ~= "" then
        payUrl = url
    end
    local pbData = HttpInterfacePB_pb.PBBuyProductParams()
    pbData.userid = userId or 0
    pbData.productid = productId or 0 --和服务器约定的商品id
    pbData.platform = payType or 0
    pbData.channelid = UIChannel
    local pbStr = ZZBase64.encode(pbData:SerializeToString())
    local url = string.format("%s?pbdata=%s", payUrl, pbStr)
    if  (cc.PLATFORM_OS_IPHONE == targetPlatform) or (cc.PLATFORM_OS_IPAD == targetPlatform) then
    	ThirdManager.openUrl(url)
    else
    	WebViewManager.showBrowser(url, "alipay", "alipay")
    end
end

return YeePay