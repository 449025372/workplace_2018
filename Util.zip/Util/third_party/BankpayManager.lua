--[[银联支付]]
BankpayManager = class()

local payUrl = UrlManager.urlsAspxCommon.bankPay

local targetPlatform = cc.Application:getInstance():getTargetPlatform()
--spId  ——保留使用，这里输入null
--sysProvider ——保留使用，这里输入null
--orderInfo   ——订单信息为交易流水号，即TN。 
--mode   —— 银联后台环境标识，“00”将在银联正式环境发起交易,“01”将在银联测试环境发起交易
--支付结果回调

function BankpayManager.startPay(spId,sysProvider,orderInfo,mode,callback)
    if (cc.PLATFORM_OS_ANDROID == targetPlatform) then
        
        local args = {spId, sysProvider, orderInfo, mode,callback}
        local sigs = "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;I)V"
        local className = "com/lexun/game/cocos2dx/GameServerManager"
        local ok,ret  = luaj.callStaticMethod(className,"startBankPay",args,sigs)
        if not ok then
            className = "com/thirdpart/UnionPayApi"
            ok,ret  = luaj.callStaticMethod(className,"pay",args,sigs)
            return ret
        end
        return ret
    end
    if (cc.PLATFORM_OS_IPHONE == targetPlatform) or (cc.PLATFORM_OS_IPAD == targetPlatform) then
        local args = {tn = orderInfo, mode = mode, callback = callback}
        
        local className = "UPPayController"
        local ok,ret  = luaoc.callStaticMethod(className,"pay",args)
        if not ok then
          print("luac error:", ok)
        else
          print("The ret is:", ret)
        end
    end
end
--[[获取网银交易流水号]]
function BankpayManager.getTradeNo(money,onSuccess,onFailure,index)
    local function successCall(data)
        if "1" == data.result then
            local rechargeType = 4 --默认金币
            if index > 8 then rechargeType = 5 end
            local orderID = data.orderid
            local userData = GameDataUser.shared()
            local userEnStr = require("src.Util.URIManager").uri_encodeEx(userData.userEncrypStr)
            local userEnKey = require("src.Util.URIManager").uri_encodeEx(userData.userEncryptKey)
            local url = string.format("%s?userencrypstring=%s&userencryptkey=%s&gorderid=%s&amount=%s&guserid=%d&btype=%d",payUrl,userEnStr,userEnKey,orderID,money,userData.userID,rechargeType)
            local http = HttpManager.new()
            http:luaXmlHttpGetRequest(url,onSuccess,onFailure)
        else
            onFailure()
        end
    end
    local orderType = 2 --默认金币
    if index > 8 then -- 1-8是充金币 9-16充钻石
        orderType = 3
    end
    AlipayManager.getMoneyOrder("UNIONPAY", money, successCall,onFailure,orderType)
end
return BankpayManager