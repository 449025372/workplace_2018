local BaofooApi = class("BaofooApi")
local targetPlatform = cc.Application:getInstance():getTargetPlatform()
-- 创建交易的支付链接
function BaofooApi:pay()
    if cc.PLATFORM_OS_ANDROID == targetPlatform then
        local args = {WxApi.appid, token, call}
        local sigs = "(Ljava/lang/String;Ljava/lang/String;I)V"
        local className = "baofoo/BaofooApi"
        local func = "pay"
        callNative(className, func, args, sigs)
    end
end

return BaofooApi

