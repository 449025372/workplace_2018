WxApi = class("WxApi")

local payUrl = UrlManager.urlsAspxCommon.wxPay
local targetPlatform = cc.Application:getInstance():getTargetPlatform()

function WxApi.init()
    if cc.PLATFORM_OS_ANDROID == targetPlatform then
        --TODO callNative()
    elseif cc.PLATFORM_OS_IPHONE == targetPlatform or cc.PLATFORM_OS_IPAD == targetPlatform then
        local var = { appId = WxApi.appid }
        callNative("WXApiManager", "setWxAppId", var)
        -- callNative("WXApiManager", "wxRegister")
    end
end

--[[新版斗地主获取订单号地址 2015-06-12]] 
function WxApi.weChatPay(price,index)
    if not WxApi.isPlatformSupported(notTip) then return end

    local onSuccess=function(data)
        if data and data.result == "1" then
            local prepayid = data.prepayid
            local payBackUrl = ""
            local noncestr = data.noncestr
            local appid = WxApi.appid
            local parterid = data.partnerid
            local packageValue = WxApi.package
            local timestamp = data.timestamp
            local sign = data.sign
            if (cc.PLATFORM_OS_ANDROID == targetPlatform) then
                --0 :支付成功    1 :支付错误   2 :取消支付 
                local function callback(result)
                    local data 
                    if result == "0" then 
                        data = 0
                    elseif result == "-1"  then
                        data = -1
                    elseif result == "-2" then 
                        data = -2
                    else
                        data = -1000
                    end
                    NotifyCenter:sharedCenter():postNotify(GameDataUser.WechatCharge_Updata,data)
                end
                local args = {appid, parterid, prepayid, packageValue, noncestr, timestamp, sign, payBackUrl, callback}
                local sigs = "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;"..
                "Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;I)V"
                local className = "com/lexun/game/cocos2dx/Lua_SDK"
                local ok,ret  = luaj.callStaticMethod(className,"callWeChatPay",args,sigs)
                if not ok then
                    print("luaj error:",ret)
                    className = "com/lexun/game/cocos2dx/thirdpart/Wxapi"
                    ok,ret  = luaj.callStaticMethod(className,"callWeChatPay",args,sigs)
                else
                    print("The ret is:",ret)
                end
            elseif (cc.PLATFORM_OS_IPHONE == targetPlatform) or (cc.PLATFORM_OS_IPAD == targetPlatform) then
                local function wxCallBack(retcode)
                    NotifyCenter:sharedCenter():postNotify(GameDataUser.WechatCharge_Updata, retcode)
                end

                local args = {partnerid=parterid, prepayid=prepayid, package=packageValue, 
                            noncestr=noncestr, timestamp=timestamp, sign=sign, callback=wxCallBack}
                
                local className = "WXApiManager"
                local ok,ret  = luaoc.callStaticMethod(className,"wxPay",args)
                if not ok then
                    cc.Director:getInstance():resume()
                else
                    print("The ret is:", ret)
                end
            end
        else
            showScaleTip("支付失败，请稍后重试")
        end
    end

    local onFail=function (error)
       showScaleTip("网络错误，请稍后重试")
    end

    local successCall = function(data)
        if data and "1" == data.result then
            if payUrl then
                local rechargeType = 4 --默认金币
                if index > 8 and index <= 16 then 
                    rechargeType = 5
                elseif index == 97 then
                    rechargeType = 6
                elseif index == 106 or index == 107 or index == 132 then
                    rechargeType = 8
                elseif index > 97 then
                    rechargeType = 7
                end
                local orderID = data.orderid
                local userData = GameDataUser.shared()
                local userEnStr = require("src.Util.URIManager").uri_encodeEx(userData.userEncrypStr)
                local userEnKey = require("src.Util.URIManager").uri_encodeEx(userData.userEncryptKey)
                local url = string.format("%s?userencrypstring=%s&userencryptkey=%s&gorderid=%s&amount=%s&guserid=%d&btype=%d",payUrl,userEnStr,userEnKey,orderID,price,userData.userID,rechargeType)
                local http = HttpManager.new()
                http:luaXmlHttpGetRequest(url,onSuccess,onFail)
            else
               showScaleTip("请求订单失败，请稍后重试") 
            end
        else
            onFail()
        end
    end
    local orderType = 2 --默认金币
    if index > 8 and index <= 16 then -- 1-8是充金币 9-16充钻石
        orderType = 3
    elseif index == 97 then
        orderType = 4
    elseif index == 106 or index == 107 or index == 132 then
        orderType = 6
    elseif index > 97 then
        orderType = 5
    end
    AlipayManager.getMoneyOrder("WXPAY",price,successCall,onFail,orderType)
end

---------------------------------微信分享---------------------------------
-- http://lxgame.lexun.com/landlord/share.aspx?guserid=&guid=&
-- http://lxgame.lexun.com/landlord/shareview.aspx?guserid=&guid=

-- local function callBack(ret)
--     print("Jacky test ret")
-- end
-- local para = {title = "test", content = "你懂的", imgPath = "", rank = 1, sharingWords = "dafddfdsf", type = WxApi.shareType.session, callBack= callBack}
-- WxApi.sharing(para)

WxApi.shareType = {timeline = 1, session = 2}
--title,content,imgPath,url, rank, shareContents
function WxApi.sharing(para)
    if not WxApi.isPlatformSupported(notTip) then return end

    local var = {
        title = para.title, 
        description = para.content,
        image = para.imgPath,
        url = para.url,
        type = para.type,
        callback = para.callBack,
    }
    if cc.PLATFORM_OS_ANDROID == targetPlatform then
        local args = {WxApi.appid, var.title, var.description, var.image, var.url, var.type, var.callback}
        local sigs = "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;II)V"
        local className = "com/lexun/game/cocos2dx/thirdpart/Wxapi"
        local func = "callWxshare"
        callNative(className, func, args, sigs)
    elseif cc.PLATFORM_OS_IPHONE == targetPlatform or cc.PLATFORM_OS_IPAD == targetPlatform then
        callNative("WXApiManager", "wxSharing", var)
    end
end
----------------------------------微信授权---------------------------------
-- ios返回ret、code, android只返回ret
-- local function callBack(ret, code)
--     print("jacky test", ret, code)
--     local function successCall(data)
--         print(data)
--         data = JsonManager.decode(data)
--         print("access_token", data.access_token)
--     end
--     WxApi.getUserInfo(code, successCall, failedCall)
-- end
-- local para = {scope = "snsapi_userinfo", callBack = callBack}
-- WxApi.authorize(para)
function WxApi.authorize(para)
    if not WxApi.isPlatformSupported(notTip) then return end

    local var = {
        scope = para.scope or "snsapi_userinfo",
        state = tostring(deepRandom(0, 999999)) .. tostring(os.time()),
        callback = para.callBack,
    }
    if cc.PLATFORM_OS_ANDROID == targetPlatform then
        local args = {WxApi.appid, var.scope, var.state, var.callback}
        local sigs = "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;I)V"
        local className = "com/lexun/game/cocos2dx/thirdpart/Wxapi"
        local func = "callWxlogin"
        callNative(className, func, args, sigs)
    elseif cc.PLATFORM_OS_IPHONE == targetPlatform or cc.PLATFORM_OS_IPAD == targetPlatform then
        callNative("WXApiManager", "wxAuthorize", var)
    end
end

function WxApi.getUserInfo(code, successCall, failedCall)
    local url = string.format("https://api.weixin.qq.com/sns/oauth2/access_token?appid=%s&secret=%s&code=%s&grant_type=authorization_code", 
                    WxApi.appid, WxApi.secret, code)

    local function httpSuccess(data)
        if successCall then successCall(data) end
    end
    local function httpFailed(errorCode)
        if failedCall then failedCall(errorCode) end
    end
    HttpManager:luaHttpGetRequest(url, httpSuccess, httpFailed)
end
-- 跳转相关联的微信公众号
function WxApi.openWxPublicNo()
    if not WxApi.isPlatformSupported() then return end

    if WxApi.public then
        local data = WxApi.public
        print("data.originid", data.originid)
        if cc.PLATFORM_OS_ANDROID == targetPlatform then
            local args = {WxApi.appid, data.originid, data.extmsg}
            local sigs = "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V"
            local className = "com/lexun/game/cocos2dx/thirdpart/Wxapi"
            local func = "callWxPublicNo"
            callNative(className, func, args, sigs)
        elseif cc.PLATFORM_OS_IPHONE == targetPlatform or cc.PLATFORM_OS_IPAD == targetPlatform then
            --TODO callNative("WXApiManager", "wxAuthorize", var)
        end
    end
end

function WxApi.isPlatformSupported(notTip)
    if not WxApi.isInstalled() then
        if not notTip then showScaleTip("请您安装微信客户端", nil, 2) end
        return false
    end

    if not WxApi.appid then
        if not notTip then showScaleTip("当前游戏暂不支持微信", nil, 2) end
        return false
    end

    return true
end

function WxApi.isInstalled()
    if cc.PLATFORM_OS_IPHONE == targetPlatform or cc.PLATFORM_OS_IPAD == targetPlatform then
        local ok,ret = callNative("WXApiManager", "wxInstalled")
        return ret
    elseif cc.PLATFORM_OS_ANDROID == targetPlatform then
        local args = {}
        local sigs = "()Z"
        local className = "com/lexun/game/cocos2dx/thirdpart/Wxapi"
        local func = "isWXClientAvailable"
        local ok,ret = callNative(className, func, args, sigs)
        return ret
    end
    return false
end

return WxApi


