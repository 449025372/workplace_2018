QQApi = class("QQApi")
-- 须在AndroidManifest中配置好appid对应的scheme，才能正确回调
local targetPlatform = cc.Application:getInstance():getTargetPlatform()

QQApi.sharingType = {
    QQSession = 1,
    QQZone = 2,
}

function QQApi.init()
    local var = {appId = QQApi.appid}
    if cc.PLATFORM_OS_ANDROID == targetPlatform then
        local className = "com/lexun/game/cocos2dx/thirdpart/QQapi"
        local funcName = "tcRegister"
        local args = {QQApi.appid}
        local sigs = "(Ljava/lang/String;)V"
        callNative(className, funcName, args, sigs)
    elseif cc.PLATFORM_OS_IPHONE == targetPlatform or cc.PLATFORM_OS_IPAD == targetPlatform then
        callNative("TxApiManager", "setTcAppId", var)
        -- callNative("TxApiManager", "tcRegister")
    end
end

-- android只有一个返回值，ios两个返回值
-- 若授权成功，android由ret返回openid，ios由msg返回
-- local function callBack(ret, msg)
--     print("Jacky test", ret, msg)
-- end
--TODO 登录还未通过审核
function QQApi.authorize(para)
    if not QQApi.isPlatformSupported() then return end

    local var = {
        callback = para.callBack,
    }
    if cc.PLATFORM_OS_ANDROID == targetPlatform then
        local args = {QQApi.appid, var.callback}
        local className = "com/lexun/game/cocos2dx/thirdpart/QQapi"
        local funcName = "callQQlogin"
        local sigs = "(Ljava/lang/String;I)V"
        callNative(className, funcName, args, sigs)
    elseif cc.PLATFORM_OS_IPHONE == targetPlatform or cc.PLATFORM_OS_IPAD == targetPlatform then
        callNative("TxApiManager", "tcAuthorize", var)
    end
end

-- local function callBack(ret, msg)
--     print("Jacky test", ret, msg)
-- end
-- local para = {
--     url = "lexun.com",
--     title = "test qq sharing",
--     descrition = "jacky test",
--     previewImg = "share.jpg",
--     type = QQApi.sharingType.QQZone,
--     callBack = callBack,
-- }
-- QQApi.sharing(para)
function QQApi.sharing(para)
    if not QQApi.isPlatformSupported() then return end

    local var = {
        url = para.url,
        title = para.title,
        description = para.content,
        previewImg = cc.FileUtils:getInstance():fullPathForFilename(para.imgPath),
        type = para.type or QQApi.sharingType.QQSession,
        callback = para.callBack,
    }
    if cc.PLATFORM_OS_ANDROID == targetPlatform then
        local args = {var.url, var.title, var.description, var.previewImg, var.type, var.callback}
        local className = "com/lexun/game/cocos2dx/thirdpart/QQapi"
        local funcName = "callQQshare"
        local sigs = "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;II)V"
        callNative(className, funcName, args, sigs)
    elseif cc.PLATFORM_OS_IPHONE == targetPlatform or cc.PLATFORM_OS_IPAD == targetPlatform then
        callNative("TxApiManager", "tcSharing", var)
    end
end

function QQApi.isPlatformSupported(notTip)
    if not QQApi.isInstalled() then
        if not notTip then showScaleTip("请您安装QQ客户端", nil, 2) end
        return false
    end
    return true
end

function QQApi.isInstalled()
    --TODO 更新大包时才打开该接口
    if cc.PLATFORM_OS_IPHONE == targetPlatform or cc.PLATFORM_OS_IPAD == targetPlatform then
        local ok,ret = callNative("TxApiManager", "tcInstalled")
        return ret
    elseif cc.PLATFORM_OS_ANDROID == targetPlatform then
        local args = {}
        local sigs = "()Z"
        local className = "com/lexun/game/cocos2dx/thirdpart/QQapi"
        local func = "isQQClientAvailable"
        local ok,ret = callNative(className, func, args, sigs)
        return ret
    end
    return false
end