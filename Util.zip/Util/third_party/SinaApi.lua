SinaApi = class("SinaApi")

local targetPlatform = cc.Application:getInstance():getTargetPlatform()

SinaApi.appId = "2311957127"
SinaApi.secret = "5e82330da1927f46e88a817c74aecfcc"
SinaApi.redirectUrl = "http://g.lexun.com" -->与开发者账号中设置的应用回调页保持一致

SinaApi.responseCode = {
    success               = 0,
    userCancel            = -1,         --用户取消发送
    sentFail              = -2,         --发送失败
    authDeny              = -3,         --授权失败
    userCancelInstall     = -4,         --用户取消安装微博客户端
    payFail               = -5,         --支付失败
    ShareInSDKFailed      = -8,         --分享失败 详情见response UserInfo
    Unsupport             = -99,        --不支持的请求
    Unknown               = -100,
}

function SinaApi.init()
	local var = { appId = SinaApi.appId, redirectUrl = SinaApi.redirectUrl }
	if cc.PLATFORM_OS_ANDROID == targetPlatform then
        --TODO callNative()
    elseif cc.PLATFORM_OS_IPHONE == targetPlatform or cc.PLATFORM_OS_IPAD == targetPlatform then
        callNative("SinaApiManager", "wbSetAppId", var)
        -- callNative("SinaApiManager", "wbRegister")
    end
end

function SinaApi.authorize(para)
    local var = {
        scope = para.scope or "all",
        callback = para.callBack,
    }

    if cc.PLATFORM_OS_ANDROID == targetPlatform then
        --TODO callNative()
    elseif cc.PLATFORM_OS_IPHONE == targetPlatform or cc.PLATFORM_OS_IPAD == targetPlatform then
        callNative("SinaApiManager", "wbAuthorize", var)
    end
end

-- local para = {
--     scope = "all",
--     title = "test sina sharing",
--     description = "haha",
--     url = "lexun.com",
--     imgPath = "Icon-144.png",
-- }
-- SinaApi.sharing(para)
function SinaApi.sharing(para)
    local var = {
        scope = para.scope or "all",
        title = para.title,
        description = para.description,
        url = para.url,
        imgPath = cc.FileUtils:getInstance():fullPathForFilename(para.imgPath),
        callback = para.callBack,
    }

    if cc.PLATFORM_OS_ANDROID == targetPlatform then
        --TODO callNative()
    elseif cc.PLATFORM_OS_IPHONE == targetPlatform or cc.PLATFORM_OS_IPAD == targetPlatform then
        callNative("SinaApiManager", "wbSharing", var)
    end
end



