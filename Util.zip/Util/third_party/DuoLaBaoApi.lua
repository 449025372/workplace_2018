local DuoLaBaoApi = class("DuoLaBaoApi")

local createPayUrl = "http://openapi.duolabao.cn/v1/customer/order/payurl/create"
local customerNum = "10001114702961098725095"
local shopNum = "10001214702963643117557"
local amount = "1"
local source = "API"
local accessKey = "261e8492eefd48a68d76d48790ead1b6909e3e5f"
local secretKey = "d1ab46716d774c3caf6aa6cd31af41ee1985c7a2"

-- 创建交易的支付链接
function DuoLaBaoApi:createPay()
    local function successCall(data)
        print("result", data.result)
        print("errorCode", data.errorCode)
        print("errorMsg", data.errorMsg)
        print("url", data.url)
    end
    local para = {
        customerNum = customerNum,
        shopNum = shopNum,
        -- machineNum = DeviceManager.IMEI(),
        requestNum = tostring(math.random(10000, 9999999) + os.time()),
        amount = amount,
        source = source,
    }
    print(para.requestNum)
    local encode = require("src.Util.URIManager")
    local jsondata = JsonManager.encode(para)
    print(jsondata)
    local url = string.format("%s", createPayUrl)
    local head = {""}

    HttpManager.new():luaXMLHttpPostRequest(createPayUrl, jsondata, successCall, nil, nil, head)
end

return DuoLaBaoApi

