-- 现在支付 h5支付接口
local XianzaiApi = class("XianzaiApi")
local targetPlatform = cc.Application:getInstance():getTargetPlatform()
-- 创建交易的支付链接
-- payType: 1支付宝 2微信
function XianzaiApi:pay(productId, userId, payType)
	local scale = display.width/1280
    local layWidth,layHeight= display.width*0.85,display.height*0.93*scale
    local rect = cc.rect(display.width*0.5-layWidth*0.5-17, display.height*0.5-layHeight*0.5-8,layWidth-34,layHeight-16)
	local payUrl = "http://cz.happysai.cn/clientpay_test/nowbuy.aspx"
    local pbData = HttpInterfacePB_pb.PBBuyProductParams()
    pbData.userid = userId or 0
    pbData.productid = productId or 0 --和服务器约定的商品id
    pbData.platform = payType or 0
    pbData.channelid = UIChannel
    local pbStr = ZZBase64.encode(pbData:SerializeToString())
    local url = string.format("%s?pbdata=%s", payUrl, pbStr)
	WebViewManager.showWebViewByFrame(url, rect)

	local layout = ccui.ImageView:create()
	layout:loadTexture("bg_normal_big_pubf.png",1)
	layout:setContentSize(layWidth,layHeight)
	layout:setAnchorPoint(0.5,0.5)
	layout:setPosition(display.width*0.5,display.height*0.5)
	layout:setScale9Enabled(true)
	local img = ccui.ImageView:create()
	img:loadTexture("bg_second_nor_pubf.png",1)
	img:setAnchorPoint(0.5,0.5)
	img:setContentSize(layWidth-30,layHeight-15)
	img:setScale9Enabled(true)
	img:setPosition(layWidth*0.5,layHeight*0.5)
	layout:addChild(img)
  	local button = ccui.Button:create()
    button:setTouchEnabled(true)
    button:loadTextures("btn_close_nor_pubf.png","btn_close_nor_pubf.png","btn_close_nor_pubf.png",1)
    button:setPosition(cc.p(display.width*0.85-5,display.height*0.93*scale-17))
    button:setScale(display.width/1280)
    layout:addChild(button)
    local function touchEvent(sender,eventType)
    	if eventType == ccui.TouchEventType.ended then
    		self:deinitPayHandler()
    	end
    end
    button:addTouchEventListener(touchEvent)

	self.layout = layout
	self.layout.flag = true
	cc.Director:getInstance():getRunningScene():addChild(layout, 10000)
end

function XianzaiApi:initPayHandler()
	local function outBackCall()
		WebViewManager.removeWebView()
		if self.deinitLayout then self:deinitLayout() end
	end
	self.AppEnterForeground = MessageManager.shared():addEventHandler(MessageManager.AppEnterForeground, outBackCall)

	self.keypadFun = function()
		outBackCall()
	end
	DeviceManager.initKeypadHandler(cc.Director:getInstance():getRunningScene(), self.keypadFun)	
end

function XianzaiApi:deinitPayHandler()
	if self.AppEnterForeground then
		MessageManager.shared():removeMsg(MessageManager.AppEnterForeground, self.AppEnterForeground)
	end
	if self.keypadFun then
		DeviceManager.removeKeyBackPress(cc.Director:getInstance():getRunningScene(), self.keypadFun)
	end
	WebViewManager.removeWebView()
	self:deinitLayout()
end

function XianzaiApi:deinitLayout()
	if self.layout and self.layout.flag then
		self.layout:removeFromParent()
		self.layout = nil
	end
end

return XianzaiApi

