DeviceManager = class()

local targetPlatform = cc.Application:getInstance():getTargetPlatform()

DeviceManager.networkNames={"cellular","WIFI"}

DeviceManager.iosDevice = {
  ["iPhone6,2"] = "iPhone5S",-- 联通
  ["iPhone5,3"] = "iPhone5C",
  ["iPhone5,2"] = "iPhone5",-- 移动，联通
  ["iPhone5,1"] = "iPhone5",-- 移动，电信，联通
  ["iPhone4,1"] = "iPhone4S",
  ["iPhone3,1"] = "iPhone4",-- 移动，联通
  ["iPhone3,2"] = "iPhone4",-- 联通
  ["iPhone3,3"] = "iPhone4",-- 电信
  ["iPhone2,1"] = "iPhone3GS",
  ["iPhone1,2"] = "iPhone3G",
  ["iPhone1,1"] = "iPhone",
  ["iPad1,1"] = "iPad1",
  ["iPad2,1"] = "iPad2",-- WIFI
  ["iPad2,2"] = "iPad2",-- GSM
  ["iPad2,3"] = "iPad2",-- CDMA
  ["iPad2,4"] = "iPad2",-- 32nm
  ["iPad2,5"] = "iPad mini",-- WIFI
  ["iPad2,6"] = "iPad mini",-- GSM
  ["iPad2,7"] = "iPad mini",-- CDMA
  ["iPad3,1"] = "iPad3",-- WIFI
  ["iPad3,2"] = "iPad3",-- CDMA
  ["iPad3,3"] = "iPad3",-- 4G
  ["iPad3,4"] = "iPad4",-- WIFI
  ["iPad3,5"] = "iPad4",-- 4G
  ["iPad3,6"] = "iPad4",-- CDMA
  ["iPod5,1"] = "iPod touch5",
  ["iPod4,1"] = "iPod touch4",
  ["iPod3,1"] = "iPod touch3",
  ["iPod2,1"] = "iPod touch2",
  ["iPod1,1"] = "iPod touch"
}

function DeviceManager.platform()
  if nil ~= DeviceManager.platformStr then return DeviceManager.platformStr end
  if (cc.PLATFORM_OS_ANDROID == targetPlatform) then
    DeviceManager.platformStr = "Android"..DeviceManager.osVersion()
  elseif  (cc.PLATFORM_OS_IPHONE == targetPlatform) or (cc.PLATFORM_OS_IPAD == targetPlatform) then
    DeviceManager.platformStr = "IOS"..DeviceManager.osVersion()
  else
    DeviceManager.platformStr = "PC"
  end
  return DeviceManager.platformStr
end

function DeviceManager.osVersion()
  if nil ~= DeviceManager.osVersionStr then return DeviceManager.osVersionStr end
  if (cc.PLATFORM_OS_ANDROID == targetPlatform) then
    
    local args = {}
    local sigs = "()Ljava/lang/String;"
    local className = "com/lexun/game/cocos2dx/Lua_SDK"
    local ok,ret  = luaj.callStaticMethod(className,"getOsVersion",args,sigs)
    if not ok then
      print("luaj error:",ret)
    else
      DeviceManager.osVersionStr = ret
      return ret
    end
  end

  if(cc.PLATFORM_OS_IPHONE == targetPlatform) or (cc.PLATFORM_OS_IPAD == targetPlatform) then
    local args = nil
    
    local className = "DeviceInfo"
    local ok,ret  = luaoc.callStaticMethod(className,"getSystemVersion",args)
    if not ok then
      print("luac error:", ok)
    else
      DeviceManager.osVersionStr = ret
      return ret
    end
  end
  DeviceManager.osVersionStr = ""
  return ""
end

-- 获取设备厂商
function DeviceManager.getMobileBrand()
  if (cc.PLATFORM_OS_ANDROID == targetPlatform) then
    
    local args = {}
    local sigs = "()Ljava/lang/String;"
    local className = "com/lexun/game/cocos2dx/Lua_SDK"
    local ok,ret  = luaj.callStaticMethod(className,"getMobileBrand",args,sigs)
    if not ok then
      print("luaj error:",ret)
    else
      return ret
    end
  end

  return "PC"
end

-- 获取MAC地址
function DeviceManager.getMacAddress()
  do return "" end
  if (cc.PLATFORM_OS_ANDROID == targetPlatform) then
    
    local args = {}
    local sigs = "()Ljava/lang/String;"
    local className = "com/lexun/game/cocos2dx/Lua_SDK"
    local ok,ret  = luaj.callStaticMethod(className,"getLocalMacAddress",args,sigs)
    if not ok then
      print("luaj error:",ret)
    else
      return ret
    end
  end

  return ""
end

-- 获取设备序列号
function DeviceManager.getSerialNum()
  if (cc.PLATFORM_OS_ANDROID == targetPlatform) then
    
    local args = {}
    local sigs = "()Ljava/lang/String;"
    local className = "com/lexun/game/cocos2dx/Lua_SDK"
    local ok,ret  = luaj.callStaticMethod(className,"getSerialNum",args,sigs)
    if not ok then
      print("luaj error:",ret)
    else
      return ret
    end
  end

  return ""
end

function DeviceManager.mobileModel()
  if nil ~= DeviceManager.mobileModelStr then return DeviceManager.mobileModelStr end
  if (cc.PLATFORM_OS_ANDROID == targetPlatform) then
    
    local args = {}
    local sigs = "()Ljava/lang/String;"
    local className = "com/lexun/game/cocos2dx/Lua_SDK"
    local ok,ret  = luaj.callStaticMethod(className,"getMobileModel",args,sigs)
    if not ok then
      print("luaj error:",ret)
    else
      DeviceManager.mobileModelStr = string.gsub(ret, " ", "")
      return DeviceManager.mobileModelStr
    end
  end

  if(cc.PLATFORM_OS_IPHONE == targetPlatform) or (cc.PLATFORM_OS_IPAD == targetPlatform) then
    local args = nil
    
    local className = "DeviceInfo"
    local ok,ret = luaoc.callStaticMethod(className,"getDeviceModel",args)
    if not ok then
      print("luac error:", ok)
    else
      local model = DeviceManager.iosDevice[ret]
      DeviceManager.mobileModelStr = string.gsub(model or ret or "", " ", "")
      return DeviceManager.mobileModelStr
    end
  end
  DeviceManager.mobileModelStr = "PC"
  return DeviceManager.mobileModelStr
end

local function imeiStrSub(str)
  return string.gsub(str, "[-' :]", "")
end

-- get imei
function DeviceManager.IMEI()
  if cc.UserDefault:getInstance():getStringForKey("DeviceImei") ~= "" then
      return cc.UserDefault:getInstance():getStringForKey("DeviceImei")
  end
  if nil ~= DeviceManager.IMEIStr then return DeviceManager.IMEIStr end
    if (cc.PLATFORM_OS_ANDROID == targetPlatform) then
      
      local args = {}
      local sigs = "()Ljava/lang/String;"
      local className = "com/lexun/game/cocos2dx/Lua_SDK"
      local ok,ret  = luaj.callStaticMethod(className,"getImei",args,sigs)
      if not ok then
        print("luaj error:",ret)
      else
        ret = imeiStrSub(ret)
        if nil == ret or "" == string.gsub(ret, " ", "") then
          print("get imei error")
          ret = DeviceManager.getSerialNum()
        end
        DeviceManager.IMEIStr = ret
        print("The ret is:",ret)
        cc.UserDefault:getInstance():setStringForKey("DeviceImei",DeviceManager.IMEIStr)
      end
      return ret
    end

    if (cc.PLATFORM_OS_IPHONE == targetPlatform) or (cc.PLATFORM_OS_IPAD == targetPlatform) then
            local args = nil
            
            local className = "DeviceInfo"
            local ok,ret  = luaoc.callStaticMethod(className,"IMEI",args)
            if not ok then
              print("luac error:", ok)
            else
              ret = imeiStrSub(ret)
              DeviceManager.IMEIStr = ret
              print("The ret is:", ret)
              cc.UserDefault:getInstance():setStringForKey("DeviceImei",DeviceManager.IMEIStr)
            end
            return ret
    end
  DeviceManager.IMEIStr = imeiStrSub("PCIMEI55555555" .. FileManager:getDeviceHostName())
  cc.UserDefault:getInstance():setStringForKey("DeviceImei",DeviceManager.IMEIStr)
  return DeviceManager.IMEIStr
end

-- get network is connect or not
function DeviceManager.isConnect()
  if (cc.PLATFORM_OS_ANDROID == targetPlatform) then
     --[[ local args = {}
      local sigs = "()Z"
      
      local className = "com/lexun/game/cocos2dx/Lua_SDK"
      local ok,ret  = luaj.callStaticMethod(className,"getNetWork",args,sigs)
      if not ok then
          print("luaj error:", ok)
      else
          print("The ret is:", ret)
      end
      return ret]]
      return NetWorkStatus.shared():isNetWorkConnect()
  end

 if (cc.PLATFORM_OS_IPHONE == targetPlatform) or (cc.PLATFORM_OS_IPAD == targetPlatform) then
    local args = nil
    
    local className = "DeviceInfo"
    local ok,ret  = luaoc.callStaticMethod(className,"isConnectedNetwork",args)
    if not ok then
        print("luac error:", ok)
    else
        print("The ret is:", ret)
    end
    return ret
  end

    return true
end

-- get current battery value
function DeviceManager.getBatteryValue()
    if (cc.PLATFORM_OS_ANDROID == targetPlatform) then
      local args = {}
      local sigs = "()I"
      
      local className = "com/lexun/game/cocos2dx/Lua_SDK"
      local ok,ret  = luaj.callStaticMethod(className,"getBatteryLevel",args,sigs)
      if not ok then
          print("luaj error:", ok)
      else
          print("The ret is:", ret)
      end
      return ret
    end

    if (cc.PLATFORM_OS_IPHONE == targetPlatform) or (cc.PLATFORM_OS_IPAD == targetPlatform) then
            local args = nil
            
            local className = "DeviceInfo"
            local ok,ret  = luaoc.callStaticMethod(className,"getBatteryLevel",args)
            if not ok then
                print("luac error:", ok)
            else
                print("The ret is:", ret)
            end
            return ret
    end

  return ""
end

-- get current battery level
function DeviceManager.getBatteryLevelFromValue(value)
  local level = 1 -- 默认为最小
  if value == "" then return level end
  if value >= 90 then
    level = 5
  elseif value >= 60 then
    level = 4
  elseif value >= 40 then
    level = 3
  elseif value >= 20 then
    level = 2
  else
    level = 1
  end
  return level
end

function DeviceManager.getCellularSignalLevelFromValue(value)
  local level = 1
  if value == "" then return level end
  if value >= -85 then
    level = 5
  elseif value >= -90 then
    level = 4
  elseif value >= -95 then
    level = 3
  elseif value >= -100 then
    level = 2
  elseif value >= -110 then
    level = 1
  end
  return level
end

function DeviceManager.registerBatteryReceiver()
    if (cc.PLATFORM_OS_ANDROID == targetPlatform) then
      local args = {}
      local sigs = "()V"
      
      local className = "com/lexun/game/cocos2dx/Lua_SDK"
      local ok = luaj.callStaticMethod(className,"registerBatteryReceiver",args,sigs)
      if not ok then
          print("luaj error:", ok)
      end
    end
end

function DeviceManager.unregisterBatteryReceiver()
    if (cc.PLATFORM_OS_ANDROID == targetPlatform) then
      local args = {}
      local sigs = "()V"
      
      local className = "com/lexun/game/cocos2dx/Lua_SDK"
      local ok  = luaj.callStaticMethod(className,"unregisterBatteryReceiver",args,sigs)
      if not ok then
          print("luaj error:", ok)
      end
   end
end

-- get current time
function DeviceManager.getTime()
  local time = os.date("%H:%M", os.time())
  local h,m
  if time then 
    index = string.find(time, ":")
    h = string.sub(time, 1, index - 1)
    m = string.sub(time, index + 1, string.len(time))
  end
  return time,h,m
end

-- 获取当前完整的时间包括年月日
function DeviceManager.getCompleteTime()
  local time = os.date("%Y/%m/%d %H:%M", os.time())

  return time
end

function DeviceManager.getNetWork()
    if (cc.PLATFORM_OS_ANDROID == targetPlatform) then
        local args = {}
        local sigs = "()I"
        
        local className = "com/lexun/game/cocos2dx/Lua_SDK"
        local ok,ret = luaj.callStaticMethod(className,"getNetType",args,sigs)
        ret = tostring(ret)
        return ret
    end

    if (cc.PLATFORM_OS_IPHONE == targetPlatform) or (cc.PLATFORM_OS_IPAD == targetPlatform) then
        local args = nil
        
        local className = "DeviceInfo"
        local ok,ret  = luaoc.callStaticMethod(className,"getNetworkLevel",args)
        return ret
    end

    return ""
end

-- get cellular signal strength after register
-- remember to unregister
function DeviceManager.getNetSignalStrength()
  -- get net type, 0 for cellular, 1 for wifi
  -- others no connected or unknew net.
  local function getNetType()
      if (cc.PLATFORM_OS_ANDROID == targetPlatform) then
      local args = {}
      local sigs = "()I"
          
          local className = "com/lexun/game/cocos2dx/Lua_SDK"
          local ok,ret = luaj.callStaticMethod(className,"getNetType",args,sigs)
          if not ok then
              print("luaj error:", ok)
      else
        print("The ret is:", ret)
      end

      return DeviceManager.networkNames[ret+1]
    end

      if (cc.PLATFORM_OS_IPHONE == targetPlatform) or (cc.PLATFORM_OS_IPAD == targetPlatform) then
        local args = nil
        
        local className = "DeviceInfo"
        local ok,ret  = luaoc.callStaticMethod(className,"getNetworkLevel",args)
        if not ok then
            print("luac error:", ok)
        else
            print("The ret is:", ret)
        end

        if "WIFI" == ret then
            return DeviceManager.networkNames[2]
        elseif "WWAN" == ret then
            return DeviceManager.networkNames[1]
        else
            return ""
        end
      end

    return ""
  end

  -- get cellphone signal
  local function getSignalStrength()
    if (cc.PLATFORM_OS_ANDROID == targetPlatform) then
      local args = {}
      local sigs = "()I"
          
          local className = "com/lexun/game/cocos2dx/Lua_SDK"
          local ok,ret = luaj.callStaticMethod(className,"getSignalStrength",args,sigs)
          if not ok then
              print("luaj error:", ok)
      else
        print("The ret is:", ret)
      end

      return ret
    end

    return ""
  end

  return getNetType(),getSignalStrength()
end

function DeviceManager.registerCellularSignalListener()
    if (cc.PLATFORM_OS_ANDROID == targetPlatform) then
    local args = {}
    local sigs = "()V"
        
        local className = "com/lexun/game/cocos2dx/Lua_SDK"
        local ok  = luaj.callStaticMethod(className,"registerMobileSignalListener",args,sigs)
        if not ok then
            print("luaj error:", ok)
    end
  end
end

function DeviceManager.unregisterCellularSignalListener()
    if (cc.PLATFORM_OS_ANDROID == targetPlatform) then
    local args = {}
    local sigs = "()V"
        
        local className = "com/lexun/game/cocos2dx/Lua_SDK"
        local ok  = luaj.callStaticMethod(className,"unregisterMobileSignalListener",args,sigs)
        if not ok then
            print("luaj error:", ok)
    end
  end
end

--打开相册
function DeviceManager.openGallary(callback)
    if (cc.PLATFORM_OS_ANDROID == targetPlatform) then
      DeviceManager.openGallaryEx(0,callback)
    end
    if (cc.PLATFORM_OS_IPHONE == targetPlatform) or (cc.PLATFORM_OS_IPAD == targetPlatform) then
      local args = {callback = callback}
      
      local className = "GallaryController"
      local ok,ret  = luaoc.callStaticMethod(className,"openGallary",args)
      if not ok then
        print("luac error:", ok)
      else
        print("The ret is:", ret)
      end
    end
end

--屏幕常亮
function DeviceManager.setKeepScreenOn(status)
  if (cc.PLATFORM_OS_ANDROID == targetPlatform) then
     
     local args = {status}
     local sigs = "(Z)V"
     local className = "com/lexun/game/cocos2dx/Lua_SDK"
     local ok,ret  = luaj.callStaticMethod(className,"setKeepScreenOn",args,sigs)
     if not ok then
       print("luaj error:",ret)
     end
  end
  if (cc.PLATFORM_OS_IPHONE == targetPlatform) or (cc.PLATFORM_OS_IPAD == targetPlatform) then
    local args = {status = status}
    
    local className = "DeviceInfo"
    local ok,ret  = luaoc.callStaticMethod(className,"setKeepScreenOn",args)
    if not ok then
      print("luac error:", ok)
    else
      print("The ret is:", ret)
    end
  end
end
--判断sdcard是否可用 true sdcard正常挂载 fasle sdcard 不可用
function DeviceManager.isSDCardUseAble()
  if nil ~= DeviceManager.isSDCardUseAbleState then return DeviceManager.isSDCardUseAbleState end
  if (cc.PLATFORM_OS_ANDROID == targetPlatform) then
      
      local args = {}
      local sigs = "()Z"
      local className = "com/lexun/game/cocos2dx/GameServerManager"
      local ok,ret  = luaj.callStaticMethod(className,"isSDCardUseAble",args,sigs)
      DeviceManager.isSDCardUseAbleState = ret
      return ret
  end
  DeviceManager.isSDCardUseAbleState = true
  return true
end
--获取设备存储卡位置 获取到的字符串形如/mnt/sdcard 结束符没有/
function DeviceManager.getExternalDir()
  if nil ~= DeviceManager.getExternalDirStr then return DeviceManager.getExternalDirStr end
  if (cc.PLATFORM_OS_ANDROID == targetPlatform) then
    
    local className = "com/lexun/game/cocos2dx/GameServerManager"
    local args = {}
    --sdcard正常挂载
    if DeviceManager.isSDCardUseAble() then
        local para ="()Ljava/lang/String;"
        ok,ret = luaj.callStaticMethod(className,"getExternalStorageDirectory",args,para)
        if ok then
          local directory = ret.."/"..".SystemDocument"
          local fp = io.open(directory, "a+")
          if fp then -- 检查是否可写
            fp:close()
            DeviceManager.getExternalDirStr = ret .. "/"
            return DeviceManager.getExternalDirStr
          end
        end
    end
    DeviceManager.getExternalDirStr = cc.FileUtils:getInstance():getWritablePath()
    return DeviceManager.getExternalDirStr
  else
    DeviceManager.getExternalDirStr = cc.FileUtils:getInstance():getWritablePath()
    return DeviceManager.getExternalDirStr
  end
end

--注册android物理返回按键按钮事件
--node 当前控制层
--kyeCallback 返回回调
local mKeyBackStack = require("src.Util.Stack").new()

function DeviceManager.clearKeypad()
  print("---------------------------DeviceManager.clearKeypad")
  mKeyBackStack = nil
  mKeyBackStack = require("src.Util.Stack").new()
end

DeviceManager.notEnableKeyCode = false
function DeviceManager.initKeypadHandler(node,keyCallback)
  if (nil ~= node) and (nil ~= keyCallback) then
    mKeyBackStack:push(keyCallback)
    -- print("---------------------initKeypadHandler",tostring(keyCallback))
    
    if nil == DeviceManager.keyBackListener  then
      local function onKeyReleased(keyCode, _)
        if keyCode == cc.KeyCode.KEY_BACKSPACE or keyCode == cc.KeyCode.KEY_BACK then
          if(mKeyBackStack:size()>0) and not DeviceManager.notEnableKeyCode then
            local backItem = mKeyBackStack:peek()
            backItem()
          end
        end
      end
      DeviceManager.keyBackListener = cc.EventListenerKeyboard:create()
      DeviceManager.keyBackListener:registerScriptHandler(onKeyReleased, cc.Handler.EVENT_KEYBOARD_RELEASED)
      node:getEventDispatcher():addEventListenerWithFixedPriority(DeviceManager.keyBackListener,1)
    end
  end
end
--移除回调返回按键回调 退出控制层必须移除掉返回回调
function DeviceManager.removeKeyBackPress(node,kyeCallback)
  if(mKeyBackStack:size()>0) then
    -- print("---------------------removeKeyBackPress",tostring(keyCallback))
    local backItem = mKeyBackStack:peek()
    if (backItem == kyeCallback) then
      mKeyBackStack:pop()
    else
      for k,v in pairs(mKeyBackStack) do
        if v == kyeCallback then
          table.remove(mKeyBackStack, k)
          break
        end
      end
    end
  end
end

--设置屏幕方向 1 横屏 2：竖屏
function DeviceManager.setOrientation(orientation, flag)
  local ret

  if (cc.PLATFORM_OS_ANDROID == targetPlatform) then
      local className = "com/lexun/game/cocos2dx/GameServerManager"
      local args = {orientation}
      local sigs = "(I)V"
      ret = callNative(className,"setOrientation",args,sigs)
  elseif (cc.PLATFORM_OS_IPHONE == targetPlatform) or (cc.PLATFORM_OS_IPAD == targetPlatform) then
      local args = {orientation = orientation}
      ret = callNative("DeviceInfo","setOrientation",args)
  end

  if ret or flag then
    local view = cc.Director:getInstance():getOpenGLView()
    local czFrame = view:getFrameSize()
    print("czFrame.height, czFrame.width", orientation, czFrame.height, czFrame.width)
    if orientation == 1 then
      if czFrame.height > czFrame.width then
        view:setFrameSize(czFrame.height, czFrame.width)
      else
        view:setFrameSize(czFrame.width, czFrame.height)
      end
      display.setAutoScale(CC_DESIGN_RESOLUTION)
    elseif orientation == 2 then
      if czFrame.width > czFrame.height then
        view:setFrameSize(czFrame.height, czFrame.width)
      else
        view:setFrameSize(czFrame.width, czFrame.height)
      end
      display.setAutoScale(CC_DESIGN_RESOLUTION_PORTRAIT)
    end
  end
  
  return ret
end
--重新启动游戏
function DeviceManager.restartApp()
  if (cc.PLATFORM_OS_ANDROID == targetPlatform) then
      
      local className = "com/lexun/game/cocos2dx/GameServerManager"
      local args = {}
      local sigs = "()V"
      luaj.callStaticMethod(className,"restartApp",args,sigs)
  end
end
--dial phone 进入拨号界面
function DeviceManager.callPhone(phoneNumer)
  if (cc.PLATFORM_OS_ANDROID == targetPlatform) then
      
      local className = "com/lexun/game/cocos2dx/GameServerManager"
      local args = {phoneNumer}
      local sigs = "(Ljava/lang/String;)V"
      luaj.callStaticMethod(className,"callPhone",args,sigs)
  end
  if (cc.PLATFORM_OS_IPHONE == targetPlatform) or (cc.PLATFORM_OS_IPAD == targetPlatform) then
    local args = {phoneNumer = phoneNumer}
    
    local className = "DeviceInfo"
    local ok,ret  = luaoc.callStaticMethod(className,"callPhone",args)
    if not ok then
      print("luac error:", ok)
    else
      print("The ret is:", ret)
    end
  end
end
--登陆成功后启动推送服务程序
function DeviceManager.startGamePushService()
  -- if (cc.PLATFORM_OS_ANDROID == targetPlatform) then
  --     local DaySpace = 5
  --     local NightSpace = 60 -- 单位分钟
  --     local className = "com/lexun/game/cocos2dx/GameServerManager"
  --     local UserData = GameDataUser.shared()
  --     local maxmsgid = 100
  --     --http://ddzweb.lexun.com/LandlordHttp/getpushmsglist.aspx?userid=218639&maxmsgid=100
  --     local urlStr = UrlManager.urlsAspxCommon.pushUrl
  --     urlStr = string.format("%s?userid=%s&maxmsgid=%d", urlStr, UserData.userID, maxmsgid)
  --     local args = {urlStr, DaySpace, NightSpace}
  --     local sigs = "(Ljava/lang/String;II)V"
  --     luaj.callStaticMethod(className,"startGamePushService",args,sigs)
  -- end
end
--下载支付宝快捷支付的下载页面
function DeviceManager.gotoDownLoadQuickPay()
  if (cc.PLATFORM_OS_ANDROID == targetPlatform) then
      
      local className = "com/lexun/game/cocos2dx/GameServerManager"
      local args = {}
      local sigs = "()V"
      luaj.callStaticMethod(className,"openDownloadQuickPay",args,sigs)
  end
end

function DeviceManager.currentPhoneNumber()
  --设置中的本机号码
  if (cc.PLATFORM_OS_IPHONE == targetPlatform) then
    
    local className = "DeviceInfo"
    local ok,ret  = luaoc.callStaticMethod(className,"currentPhoneNumber")
    if not ok then
      print("luac error:", ok)
    else
      print("The ret is:", ret)
    end
    return ret
  end
  if (cc.PLATFORM_OS_ANDROID == targetPlatform) then
      
      local className = "com/lexun/game/cocos2dx/GameServerManager"
      local args = {}
      local sigs = "()Ljava/lang/String;"
      local ok,ret = luaj.callStaticMethod(className,"currentPhoneNumber",args,sigs)
      if not ok then
        print("luac error:", ok)
      else
        print("The ret is:", ret)
      end
      return ret
  end
  return ""

end
--[[显示系统中日期选择对话框 callback中回调 所选择的的日期如 2015-01-24格式字符串]] 
function DeviceManager.showDatePickDialog(callback)
    if (cc.PLATFORM_OS_IPHONE == targetPlatform) then
      local args = {callback = callback}
      
      local className = "GallaryController"
      local ok,ret  = luaoc.callStaticMethod(className,"openDatePicker",args)
      if not ok then
        print("luac error:", ok)
      else
            print("The ret is:", ret)
      end
    end
    if (cc.PLATFORM_OS_ANDROID == targetPlatform) then
        
        local className = "com/lexun/game/cocos2dx/GameServerManager"
        local args = {callback}
        local sigs = "(I)V"
        luaj.callStaticMethod(className,"pickDateDialog",args,sigs)
    end

end

--[[打开摄像头获取图片  openFlag 1：拍照后进行裁剪 0：不裁剪  callback 返回处理过后的图片本地地址  width height 针对裁剪生成的图片的宽高]]
function DeviceManager.openCamera(openFlag,callback,width,height)
    if (cc.PLATFORM_OS_IPHONE == targetPlatform) or (cc.PLATFORM_OS_IPAD == targetPlatform) then
      local args = {openFlag = openFlag, callback = callback}
      
      local className = "GallaryController"
      local ok,ret  = luaoc.callStaticMethod(className,"openCamera",args)
      if not ok then
        print("luac error:", ok)
      else
        print("The ret is:", ret)
      end
    end
    if (cc.PLATFORM_OS_ANDROID == targetPlatform) then
        
        local className = "com/lexun/game/cocos2dx/GameServerManager"
        local args = {openFlag,callback,width,height}
        local sigs = "(IIII)V"
        luaj.callStaticMethod(className,"openCamera",args,sigs)
    end

end
--[[打开相册获取图片  openFlag 1：选择后进行裁剪 0：不裁剪  callback 返回处理过后的图片本地地址 width height 针对裁剪生成的图片的宽高]]
function DeviceManager.openGallaryEx(openFlag,callback,width,height)
    if (cc.PLATFORM_OS_IPHONE == targetPlatform) or (cc.PLATFORM_OS_IPAD == targetPlatform) then
      local args = {openFlag = openFlag, callback = callback}
      
      local className = "GallaryController"
      local ok,ret  = luaoc.callStaticMethod(className,"openGallary",args)
      if not ok then
        print("luac error:", ok)
      else
        print("The ret is:", ret)
      end
    end
    if (cc.PLATFORM_OS_ANDROID == targetPlatform) then
        
        local className = "com/lexun/game/cocos2dx/GameServerManager"
        local args = {openFlag,callback,width,height}
        local sigs = "(IIII)V"
        luaj.callStaticMethod(className,"openGallary",args,sigs)
    end

end
--  判断是否是手机，而不是模拟器，只有android有效
function DeviceManager.isPhoneReally()
  if nil ~= DeviceManager.isPhoneReallyState then return DeviceManager.isPhoneReallyState end
  if (cc.PLATFORM_OS_ANDROID == targetPlatform) then
    
    local args = {}
    local sigs = "()Z"
    local className = "com/lexun/game/cocos2dx/Lua_SDK"
    local ok,ret  = luaj.callStaticMethod(className,"IsPhoneReally",args,sigs)
    if not ok then
      return false
    end
    DeviceManager.isPhoneReallyState = ret
    return ret
  end
  return true
end

function DeviceManager.isIphoneJailbroken()
  if (cc.PLATFORM_OS_IPHONE == targetPlatform) or (cc.PLATFORM_OS_IPAD == targetPlatform) then
    local ok,ret = callNative("DeviceInfo", "isJailbroken")
    if ret == 1 or not ok then
      return true
    end
  end
  return false
end
-- 系统复制
function DeviceManager.copyText(copyStr)
  if (cc.PLATFORM_OS_ANDROID == targetPlatform) then
      local className = "com/lexun/game/cocos2dx/GameServerManager"
      local args = {copyStr}
      local sigs = "(Ljava/lang/String;)V"
      local ok,ret = luaj.callStaticMethod(className,"setText",args,sigs)
      if not ok then
        print("luac error:", ok)
        return false
      else
        print("The ret is:", ret)
        return true
      end
  end
  if (cc.PLATFORM_OS_IPHONE == targetPlatform) or (cc.PLATFORM_OS_IPAD == targetPlatform) then
    local args = {copyStr = copyStr}
    local className = "DeviceInfo"
    local ok,ret  = luaoc.callStaticMethod(className,"copyText",args)
    if not ok then
      print("luac error:", ok)
      return false
    else
      print("The ret is:", ret)
      return true
    end
  end
end

function DeviceManager.getPackageInfo()
  if DeviceManager.versionName and DeviceManager.versionName ~= "" and DeviceManager.versioncode and DeviceManager.versioncode ~= "" then
    return DeviceManager.versionName, DeviceManager.versioncode
  end
  if (cc.PLATFORM_OS_ANDROID == targetPlatform) then
      local args = {}
      local sigs = "()Ljava/lang/String;"
      local className = "com/lexun/game/cocos2dx/Lua_SDK"
      local ok,ret  = luaj.callStaticMethod(className,"getPackageInfo",args,sigs)
      if not ok then
        print("luaj error:",ret)
        return 0
      else
        print("luaj ok : ", ret)
        if ret ~= "" then
          local info = string.split(ret, "|")
          if info and #info == 2 then
              DeviceManager.versionName = tonumber(info[1])
              DeviceManager.versioncode = tonumber(info[2])
              return DeviceManager.versionName, DeviceManager.versioncode
          end
        end
      end
      return 0
  else
      return 0
  end
end