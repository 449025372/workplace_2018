WebViewManager = class("WebViewManager")

local targetPlatform = cc.Application:getInstance():getTargetPlatform()

function ConvertRectToViewFrame(rect)
  local director = cc.Director:getInstance()
  local winSize = director:getWinSize()
  local glView = director:getOpenGLView()
  local scaleX = glView:getScaleX()
  local scaleY = glView:getScaleY()
  local x = rect.x * scaleX
  local y = (winSize.height - rect.y - rect.height) * scaleY
  local width = rect.width *scaleX
  local height = rect.height * scaleY
  return x, y, width, height
end

function openURL(url,title)
    WebViewManager.showWebView(url,title)
end

-- show WEBVIEW
function WebViewManager.showWebView(url,title)
    if not DeviceManager.isConnect() then
        DialogManager.alert(I18NString("noReachableNetwork"))
        return
    end

    title = title or ""
    if (cc.PLATFORM_OS_ANDROID == targetPlatform) then
       
       local args = {url,title}
       local sigs = "(Ljava/lang/String;Ljava/lang/String;)V"
       local className = "com/lexun/game/cocos2dx/Lua_SDK"
       local ok,ret  = luaj.callStaticMethod(className,"StartWebView",args,sigs)
       if not ok then
         print("luaj error:",ret)
       else
        print("The ret is:",ret)
       end
    end

    if (cc.PLATFORM_OS_IPHONE == targetPlatform) or (cc.PLATFORM_OS_IPAD == targetPlatform) then
            local function callBack()
                MusicManager.shared():resumeBackgroundMusic()
            end
            local args = { url = url , title = title, callBack = callBack }
            
            local className = "OAuthViewController"
            local ok,ret  = luaoc.callStaticMethod(className,"loadUrl",args)
            if not ok then
                cc.Director:getInstance():resume()
            else
                MusicManager.shared():pauseBackgroundMusic()
                print("The ret is:", ret)
            end

     end
end

function WebViewManager.showWebViewHtml(html)
    if (cc.PLATFORM_OS_ANDROID == targetPlatform) then
        
       local args = {html}
       local sigs = "(Ljava/lang/String;)V"
       local className = "com/lexun/game/cocos2dx/Lua_SDK"
       local ok,ret  = luaj.callStaticMethod(className,"StartWebViewHtml",args,sigs)
       if not ok then
         print("luaj error:",ret)
       else
        print("The ret is:",ret)
       end
    end

    if (cc.PLATFORM_OS_IPHONE == targetPlatform) or (cc.PLATFORM_OS_IPAD == targetPlatform) then
            local args = { html = html }
            
            local className = "OAuthViewController"
            local ok,ret  = luaoc.callStaticMethod(className,"loadHtml",args)
            if not ok then
                cc.Director:getInstance():resume()
            else
                print("The ret is:", ret)
            end

    end
end

-- add一个webview，参数：url网络地址、rect（左下角点x，y、width宽、height高）
function WebViewManager.showWebViewByFrame(url, rect)
  WebViewManager.removeWebView()
  local x,y,width,height = ConvertRectToViewFrame(rect)
  if (cc.PLATFORM_OS_IPHONE == targetPlatform) or (cc.PLATFORM_OS_IPAD == targetPlatform) then
    local args = {url = url, x = x, y = y, width = width, height = height}
    
    local className = "WebViewController"
    local methodName = "addWebView"
    local ok,ret = luaoc.callStaticMethod(className, methodName, args)
    if not ok then
      cc.Director:getInstance():resume()
    else
      print("The ret is:",ret)
    end
  end

   if (cc.PLATFORM_OS_ANDROID == targetPlatform) then
       
       local args = {url, x, y, width, height,0}
       local sigs = "(Ljava/lang/String;IIIII)V"
       local className = "com/lexun/game/cocos2dx/Lua_SDK"
       local ok,ret  = luaj.callStaticMethod(className,"addWebView",args,sigs)
       if not ok then
         print("luaj error:",ret)
       else
        print("The ret is:",ret)
       end
    end
end
-- add一个webview，参数：含有html标签的字符串、rect（左下角点x，y、width宽、height高）
function WebViewManager.showWebViewHTMLContent(html, rect, flag, respath)
  local content = "<html><meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" /><body><p style=\"word-break:break-all; \">"..html.."</p></body></html>"
  local x,y,width,height = ConvertRectToViewFrame(rect)
  if (cc.PLATFORM_OS_IPHONE == targetPlatform) or (cc.PLATFORM_OS_IPAD == targetPlatform) then
    local args = {html = content, x = x, y = y, width = width, height = height}
    
    local className = "WebViewController"
    local methodName = "addWebViewByHTML"
    local ok,ret = luaoc.callStaticMethod(className, methodName, args)
    if not ok then
      cc.Director:getInstance():resume()
    else
      print("The ret is:",ret)
    end
  end
   if (cc.PLATFORM_OS_ANDROID == targetPlatform) then
       
       local args = {content, x, y, width, height, flag or 1}
       print("showWebViewByHTML:",content,x,y,width,height)
       local sigs = "(Ljava/lang/String;IIIII)V"
       local className = "com/lexun/game/cocos2dx/Lua_SDK"
       local ok,ret  = luaj.callStaticMethod(className,"addWebView",args,sigs)
        if not ok then
        cc.Director:getInstance():resume()
      else
        print("The ret is:",ret)
      end
    end
end

-- add一个webview，参数：html地址、rect（左下角点x，y、width宽、height高）
function WebViewManager.showWebViewByHTML(htmlPath, rect)
  local html = cc.FileUtils:getInstance():getStringFromFile(htmlPath)
  WebViewManager.showWebViewHTMLContent(html,rect)
end

-- 移除webview
function WebViewManager.removeWebView()
  if (cc.PLATFORM_OS_IPHONE == targetPlatform) or (cc.PLATFORM_OS_IPAD == targetPlatform) then
    local args = nil
    
    local className = "WebViewController"
    local methodName = "removeWebView"
    local ok,ret = luaoc.callStaticMethod(className, methodName, args)
    if not ok then
      cc.Director:getInstance():resume()
    else
      print("The ret is:",ret)
    end
  end
  if (cc.PLATFORM_OS_ANDROID == targetPlatform) then
       
       local args = {}
       local sigs = "()V"
       local className = "com/lexun/game/cocos2dx/Lua_SDK"
       local ok,ret  = luaj.callStaticMethod(className,"removeWebView",args,sigs)
       if not ok then
         print("luaj error:",ret)
       else
        print("The ret is:",ret)
       end
    end
end

-- 刷新webview
function WebViewManager.reloadWebView()
  if (cc.PLATFORM_OS_IPHONE == targetPlatform) or (cc.PLATFORM_OS_IPAD == targetPlatform) then
    local args = nil
    
    local className = "WebViewController"
    local methodName = "reload"
    local ok,ret = luaoc.callStaticMethod(className, methodName, args)
    if not ok then
      cc.Director:getInstance():resume()
    else
      print("The ret is:",ret)
    end
  end

   if (cc.PLATFORM_OS_ANDROID == targetPlatform) then
       
       local args = {}
       local sigs = "()V"
       local className = "com/lexun/game/cocos2dx/Lua_SDK"
       local ok,ret  = luaj.callStaticMethod(className,"reloadWebView",args,sigs)
       if not ok then
         print("luaj error:",ret)
       else
        print("The ret is:",ret)
       end
    end
end

-- 加载webview，参数：url网址
function WebViewManager.loadWebViewByUrl(url)
  if (cc.PLATFORM_OS_IPHONE == targetPlatform) or (cc.PLATFORM_OS_IPAD == targetPlatform) then
    local args = {url = url}
    
    local className = "WebViewController"
    local methodName = "loadUrl"
    local ok,ret = luaoc.callStaticMethod(className, methodName, args)
    if not ok then
      cc.Director:getInstance():resume()
    else
      print("The ret is:",ret)
    end
  end
  if (cc.PLATFORM_OS_ANDROID == targetPlatform) then
       
       local args = {1}
       local sigs = "(I)V"
       local className = "com/lexun/game/cocos2dx/Lua_SDK"
       local ok,ret  = luaj.callStaticMethod(className,"loadUrl",args,sigs)
       if not ok then
         print("luaj error:",ret)
       else
        print("The ret is:",ret)
       end
    end
end

-- 加载webview，参数：html地址
function WebViewManager.loadWebViewByHTML(htmlPath)
  local html = cc.FileUtils:getInstance():getStringFromFile(htmlPath)
  if (cc.PLATFORM_OS_IPHONE == targetPlatform) or (cc.PLATFORM_OS_IPAD == targetPlatform) then
    local args = {html = html}
    
    local className = "WebViewController"
    local methodName = "loadHTML"
    local ok,ret = luaoc.callStaticMethod(className, methodName, args)
    if not ok then
      cc.Director:getInstance():resume()
    else
      print("The ret is:",ret)
    end
  end

  if (cc.PLATFORM_OS_ANDROID == targetPlatform) then
   
   local args = {1}
   local sigs = "(I)V"
   local className = "com/lexun/game/cocos2dx/Lua_SDK"
   local ok,ret  = luaj.callStaticMethod(className,"loadUrl",args,sigs)
    if not ok then
      cc.Director:getInstance():resume()
    else
      print("The ret is:",ret)
    end
  end
end

function WebViewManager.showBrowser(url, headerKey, headerVal)
  headerKey = headerKey or ""
  headerVal = headerVal or ""
  
  if (cc.PLATFORM_OS_IPHONE == targetPlatform) or (cc.PLATFORM_OS_IPAD == targetPlatform) then
    local args = {url = url, field = headerKey, value = headerVal}
    
    local className = "BrowerController"
    local methodName = "showBrower"
    local ok,ret = luaoc.callStaticMethod(className, methodName, args)
    if not ok then
      print("showBrowser error",ret)
      cc.Director:getInstance():resume()
    else
      print("The ret is:",ret)
    end
  end

  if (cc.PLATFORM_OS_ANDROID == targetPlatform) then
     
     local args = {url, headerKey, headerVal}
     local sigs = "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V"
     local className = "com/lexun/game/cocos2dx/Lua_SDK"
     local ok,ret  = luaj.callStaticMethod(className,"ShowWebStore",args,sigs)
     if not ok then
        cc.Director:getInstance():resume()
     end
     print("showBrowser ret is:", ret)
  end
end
