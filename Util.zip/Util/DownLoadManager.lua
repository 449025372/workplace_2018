-- 下载
DownLoadManager = class()

-- 构造，参数：url网址
function DownLoadManager:ctor(url)
	local pathToSave = cc.FileUtils:getInstance():getWritablePath()
	self.assetsManager = cc.AssetsManager:new(url, "", pathToSave)
	self.assetsManager:retain()
end

-- 不用时记得调用释放
function DownLoadManager:releaseAssetsManager()
	self.assetsManager:release()
end

-- 开始下载
function DownLoadManager:checkUpdate()
	self.assetsManager:checkUpdate()
end

-- 解压
function DownLoadManager:uncompress()
	self.assetsManager:uncompress()
end

-- 设置成功回调 callMethod()
function DownLoadManager:setSuccessCall(callMethod)
    self.assetsManager:setDelegate(callMethod, cc.ASSETSMANAGER_PROTOCOL_SUCCESS)
end

-- 设置进度回调 callMethod(percent) percent下载的进度
function DownLoadManager:setProgressCall(callMethod)
	self.assetsManager:setDelegate(callMethod, cc.ASSETSMANAGER_PROTOCOL_PROGRESS)
end

-- 设置失败回调 callMethod(errorCode) errorCode错误信息
function DownLoadManager:setFailedCall(callMethod)
	self.assetsManager:setDelegate(callMethod, cc.ASSETSMANAGER_PROTOCOL_ERROR)
end

-- 设置下载url
function DownLoadManager:setPackageUrl(url)
	self.assetsManager:setPackageUrl(url)
end
