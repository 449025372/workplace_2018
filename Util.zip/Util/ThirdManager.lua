ThirdManager = class("ThirdManager")

local targetPlatform = cc.Application:getInstance():getTargetPlatform()
local schema ={["com.alipay.android.app"]="alipay://",["com.tencent.mm"]="sinaweibosso://"}

function ThirdManager.CallThirdApp(packageName)
    if (cc.PLATFORM_OS_ANDROID == targetPlatform) then
        
       local args = {packageName}
       local sigs = "(Ljava/lang/String;)V"
       local className = "com/lexun/game/cocos2dx/Lua_SDK"
       local ok,ret  = luaj.callStaticMethod(className,"OpenThirdApp",args,sigs)
       if not ok then
         print("luaj error:",ret)
       else
        print("The ret is:",ret)
       end
    end

    if (cc.PLATFORM_OS_IPHONE == targetPlatform) or (cc.PLATFORM_OS_IPAD == targetPlatform) then
            local args = {schema[packageName] or ""}
            
            local className = "DeviceInfo"

            local _,result  = luaoc.callStaticMethod(className,"canOpenApp",args)
            if result then
                local ok,ret  = luaoc.callStaticMethod(className,"openApp",args)
                if not ok then
                    print("luac error:", ok)
                else
                    print("The ret is:", ret)
                end
             else
                 print("openApp error.")
            end
    end
end

function ThirdManager.openUrl(urlStr)
  if (cc.PLATFORM_OS_IPHONE == targetPlatform) or (cc.PLATFORM_OS_IPAD == targetPlatform) then
    local args = {urlStr = urlStr}
    
    local className = "DeviceInfo"
    local ok,ret = luaoc.callStaticMethod(className,"openUrl",args)
    if not ok then
      print("luac error:", ok)
    else
      print("The ret is:", ret)
    end
  end
  if (cc.PLATFORM_OS_ANDROID == targetPlatform) then
    
    local args = {urlStr}
    local sigs = "(Ljava/lang/String;)V"
    local className = "com/lexun/game/cocos2dx/Lua_SDK"
    local ok,ret  = luaj.callStaticMethod(className,"OpenUrl",args,sigs)
    if not ok then
      print("luaj error:",ret)
    else
      print("The ret is:",ret)
    end
  end
end

function ThirdManager.canOpenApp(packageName)
  if (cc.PLATFORM_OS_ANDROID == targetPlatform) then

  end
  if (cc.PLATFORM_OS_IPHONE == targetPlatform) or (cc.PLATFORM_OS_IPAD == targetPlatform) then
            local args = {schema[packageName] or ""}
            
            local className = "DeviceInfo"

            local _,result  = luaoc.callStaticMethod(className,"canOpenApp",args)
            return result
  end
end

-- sina weibo login 参数：appKey、scretKey、callbackUrl回调url、callback回调方法
function ThirdManager.WeiBoLogin(key, scret, callbackUrl, callback)
    if not DeviceManager.isConnect() then
        DialogManager.alert(I18NString("noReachableNetwork"))
        return ""
    end
    
    if (cc.PLATFORM_OS_ANDROID == targetPlatform) then
        
       local args = {key, scret, callbackUrl, callback}
       local sigs = "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;I)V"
       local className = "com/lexun/game/cocos2dx/Lua_SDK"
       local ok,ret  = luaj.callStaticMethod(className,"WeiBoLogin",args,sigs)
       if not ok then
         print("luaj error:",ret)
       else
        print("The ret is:",ret)
       end
    end

    if (cc.PLATFORM_OS_IPHONE == targetPlatform) or (cc.PLATFORM_OS_IPAD == targetPlatform) then
      local args = {appKey = key, appSecret = scret, redirectUri = callbackUrl}
      
      local className = "SinaWeiboController"

      local ok,ret  = luaoc.callStaticMethod(className,"setSinaWeiboAppKey",args)
      if not ok then
          print("luac error:", ok)
      else
          print("The ret is:", ret)

          local function SinaWeiboCallBack(state, data)
            if "success" == state then
                callback(data)
            else
                callback()
            end
          end

          args = {scriptHandler = SinaWeiboCallBack}
          local ok,ret  = luaoc.callStaticMethod(className,"loginSinaWeibo",args)
          if not ok then
              print("luac error:", ok)
          else
              print("The ret is:", ret)
          end
      end
    end
end

-- qq weibo login 参数：appKey、scretKey、callbackUrl回调url、callback回调方法
function ThirdManager.QQWeiBoLogin(key, scret, callbackUrl, callback)
    if not DeviceManager.isConnect() then
        DialogManager.alert(I18NString("noReachableNetwork"))
        return ""
    end

    if (cc.PLATFORM_OS_ANDROID == targetPlatform) then
        
       local args = {key, scret, callbackUrl, callback}
       local sigs = "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;I)V"
       local className = "com/lexun/game/cocos2dx/Lua_SDK"
       local ok,ret  = luaj.callStaticMethod(className,"QQWeiBoLogin",args,sigs)
       if not ok then
         print("luaj error:",ret)
       else
        print("The ret is:",ret)
       end
    end

    if (cc.PLATFORM_OS_IPHONE == targetPlatform) or (cc.PLATFORM_OS_IPAD == targetPlatform) then
      local args = {appKey = key, appSecret = scret, redirectUri = callbackUrl}
      
      local className = "TCWeiboController"

      local ok,ret  = luaoc.callStaticMethod(className,"setTCWeiboAppKey",args)
      if not ok then
          print("luac error:", ok)
      else
          print("The ret is:", ret)

          local function TCWeiboCallBack(state, data)
            if "success" == state then
                callback(data)
            else
                callback()
            end
          end

          args = {scriptHandler = TCWeiboCallBack}
          local ok,ret  = luaoc.callStaticMethod(className,"loginTCWeibo",args)
          if not ok then
              print("luac error:", ok)
          else
              print("The ret is:", ret)
          end
      end
    end
end
