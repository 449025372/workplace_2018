-- json
JsonManager = class()

-- return table 把json字符串转化为表
function JsonManager.decode(str)
    if not str then return nil end
	return json.decode(str)
end

-- return jsonStr 把表转化为json字符串
function JsonManager.encode(table)
    if not table then return nil end
	return json.encode(table)
end

function JsonManager.isJSON(s)
    local startPos = 1
    startPos = scanWhitespace(s,startPos)
    if(startPos>string.len(s)) then
        return false
    end
    local curChar = string.sub(s,startPos,startPos)
    -- Object
    if not (curChar=='{' or curChar=='[') then
        return false
    end

    return true
end

function scanWhitespace(s,startPos)
  local whitespace=" \n\r\t"
  local stringLen = string.len(s)
  while ( string.find(whitespace, string.sub(s,startPos,startPos), 1, true)  and startPos <= stringLen) do
    startPos = startPos + 1
  end
  return startPos
end

function JsonManager.LinkItemNO( atag )
	local reg=[[itemno=%s*(%d+)]]
	_, _, value = string.find(atag,reg)
	return value or ""
end

function JsonManager.linkContent( atag )
	local regLink=[[([>'])(.-)%1]]
	_,_,_,ret=string.find(atag,regLink)
	local reg = [[(.*)</a]]
	_, _, value = string.find(ret,reg)
	return value or ""
end


--- @brief 调试时打印变量的值
--- @param data 要打印的字符串
--- @param [max_level] table要展开打印的计数，默认nil表示全部展开
--- @param [prefix] 用于在递归时传递缩进，该参数不供用户使用于
--- @ref http://dearymz.blog.163.com/blog/static/205657420089251655186/
function table_dump(data, max_level, prefix)
    if type(prefix) ~= "string" then
        prefix = ""
    end
    if type(data) ~= "table" then
        print(prefix .. tostring(data))
    else
        print(data)
        if max_level ~= 0 then
            local prefix_next = prefix .. "    "
            print(prefix .. "{")
            for k,v in pairs(data) do
                io.stdout:write(prefix_next .. k .. " = ")
                if type(v) ~= "table" or (type(max_level) == "number" and max_level <= 1) then
                    print(v)
                else
                    if max_level == nil then
                        var_dump(v, nil, prefix_next)
                    else
                        var_dump(v, max_level - 1, prefix_next)
                    end
                end
            end
            print(prefix .. "}")
        end
    end
end

function tableToString(data, max_level)
    var_dump(data, max_level or 5)
end

function toXMLstr(data)
    local str = "<xml>"
    for k,v in pairs(data) do
        str = str.."<"..k..">"..v.."</"..k..">"
    end
    str=str.."</xml>"
    return str
end