IAPListTable = class("IAPListTable")

IAPListTable.db_name = "lexunmsglib.db"
local tablename = "nv_IAPListTable"
local RECEIPT = "Receipt"         --回执信息
local DONE = "Done"
local PID = "Pid"                
local USERID = "Userid"
local ORDERID = "Orderid"  
--[[

[Donw] 3    初始化
[Done] 2    已经支付等待发送我方服务器验证
[Done] 1    购买成功
[Done] 0    重复购买

--]]

function IAPListTable:ctor()
    self:createTable()
end

-- 删除表
function IAPListTable:dropTable()
    local db = self:getOpenDB()
    local  sql  = "drop table " .. tablename
    db:execute(sql)
end
-- 删除行数据
function IAPListTable:deleteAllRows()
  local sql = string.format([[delete from %s where Userid = %s]],  tablename,GameDataUser.shared().userID)
  local db = self:getOpenDB()
  db:execute(sql)
end
-- 删除一行指定的数据
function IAPListTable:deleteOneRow(ORDERID)
    local db = self:getOpenDB()
    local sql = string.format([[delete from %s where Orderid = '%s']],  tablename,ORDERID)
    db:execute(sql)
end
-- 建表
function IAPListTable:createTable()
  local db = self:getOpenDB()
  local t = {

    [RECEIPT] = "VARCHAR",
    [DONE] = "INTEGER",
    [PID] = "VARCHAR",
    [USERID] = "Long",
    [ORDERID] = "VARCHAR"

  }
  db:createTable(tablename, t)
end
-- 插入一條結果記錄
function IAPListTable:insertRecordOne(result)
  if(nil == result) then
    return
  end
  local db = self:getOpenDB()
  self:insertRecordInfo(result,db)
end

--写一条记录
function IAPListTable:insertRecordInfo(result ,db)
    if(nil == result) then
        return
    end
    local hash = {}  
    hash[RECEIPT] = result.Receipt
    hash[ORDERID] = result.Orderid
    hash[DONE] = result.Done
    hash[PID] = result.Pid
    hash[USERID] = GameDataUser.shared().userID
    local rid = 0
    rid = db:insert(tablename, hash)
    return rid
end

function IAPListTable:updateRecordReceipt(RECEIPT,ORDERID)
    local db = self:getOpenDB()
    local sql = string.format("update nv_IAPListTable set Receipt = '%s' where Orderid = '%s' ",RECEIPT,ORDERID)
    db:execute(sql)
end

function IAPListTable:updateRecordDone(DONE,ORDERID)
    local db = self:getOpenDB()
    local sql = string.format("update nv_IAPListTable set Done = %s where Orderid = '%s' ",DONE,ORDERID)
    db:execute(sql)
end

-- 查询结果列表
function IAPListTable:getList()
    local list = {}
    local db = self:getOpenDB()
    local reader = nil
    local sql = string.format([[ select * from %s where Userid = %s]],  tablename,GameDataUser.shared().userID)
    reader = db:nrows(sql)
    return reader or {}
end

-- alter table [表名] add 字段名 varchar
-- 根据list插入记录
function IAPListTable:insertList(list)
    local db = self:getOpenDB()
    db:beginTransaction()
    for k, v in pairs(list) do  
        self:insert(v, db)
    end
    db:commitTransaction()
end

-- 获得公用数据库接口
function IAPListTable:getOpenDB()
    local db = DBHelper.shared():getDB()
    return db
end

return IAPListTable