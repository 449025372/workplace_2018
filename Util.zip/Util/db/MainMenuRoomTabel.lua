MainMenuRoomTabel = class()
MainMenuRoomTabel.db_name = "lexunmsglib.db"
local tablename = "t_room_info"
local dbTypes = {
  int = "INTEGER",
  string = "VARCHAR",
}
local keyWords = {
-- 第一个元素为字段名，第二个元素为字段类型
-- 0 INTEGER; 1 VARCHAR; 
    [1] = {"gameType", dbTypes.int},
    [2] = {"roomtype", dbTypes.int},
    [3] = {"adtop", dbTypes.string},
    [4] = {"admiddle", dbTypes.string},
    [5] = {"remark", dbTypes.string},
    [6] = {"online", dbTypes.int},
    [7] = {"fee", dbTypes.int},
    [8] = {"title", dbTypes.string},
    [9] = {"version", dbTypes.int},
    [10] = {"streak", dbTypes.string},
    [11] = {"match_rules", dbTypes.string},
    [12] = {"isPublic", dbTypes.int},
    [13] = {"isShow", dbTypes.int},
}

function MainMenuRoomTabel.shared()
  if nil == _G["MainMenuRoomTabel.obj"] then
    _G["MainMenuRoomTabel.obj"] = MainMenuRoomTabel.new()
  end
  return _G["MainMenuRoomTabel.obj"]
end

function MainMenuRoomTabel:ctor()
	-- self:createTable()
end
-- 创建房间信息本地数据库表，只在程序启动时创建一次
function MainMenuRoomTabel:createTable()
	local sqlite = DBHelper.shared():getDB()
  local sql = string.format("SELECT * FROM %s", tablename)
  local sqlRet = sqlite:execute(sql, function(udata,cols,values,names)
    for k,v in pairs(keyWords) do
      local insert = true
      for _,column in pairs(names) do
        if v[1] == column then
          insert = false
          break
        end
      end
      -- 如果要往已存在的表里新增字段，则从表中获取所有字段名并进行对比，不存在的则添加该字段
      if insert then
        print("insert ",v[1],v[2])
        local sqlStr = string.format("ALTER TABLE %s ADD COLUMN %s %s", tablename, v[1], v[2])
        local ret = sqlite:execute(sqlStr)
      end
    end
    print(udata, cols, values, names)
    end)

  if sqlRet then -- 如果表已存在则不再创建
    return false
  end

  local sql = string.format("CREATE TABLE if not exists %s(", tablename)
  for _,v in pairs(keyWords) do
      local keyVal = v[1]
      local vType = v[2]
      sql = string.format("%s%s %s,", sql, keyVal, vType)
  end
  sql = string.sub(sql, 1, #sql - 1) -- 截掉尾部的逗号
  sql = string.format("%s);", sql)
  sqlite:execute(sql)
  print(sql)
  sql = string.format("create unique index if not exists t_room_info_roomtype on %s(%s)",tablename, keyWords[2][1])
  sqlite:execute(sql)
  return sqlRet
end

function MainMenuRoomTabel:setOnlieCount(roomtype,onLineCount)
  print("-----------------",roomtype,onLineCount)
  if roomtype and onLineCount then 
    local sqlite = DBHelper.shared():getDB()
    local sql = string.format("update %s set online = %s where roomtype = %s",tablename,onLineCount,roomtype)
    sqlite:execute(sql)
  end
end

function MainMenuRoomTabel:setShowState(roomtype,showState)
  print("-----------------",roomtype,onLineCount)
  if roomtype and showState then
    local sqlite = DBHelper.shared():getDB()
    local sql = string.format("update %s set isShow = %d where roomtype = %s",tablename,showState,roomtype)
    sqlite:execute(sql)
  end
end

--写入房间信息
function MainMenuRoomTabel:saveRoomInfo(dataArray)
  local sqlite = DBHelper.shared():getDB()
  sqlite:beginTransaction()
  sqlite:deleteContents(tablename)
  for k,data in pairs(dataArray) do
    local hash = {}
    local values = { --这里的赋值顺序必须和keyWords一一对应
        data.gameType,
        data.roomtype,
        data.adtop,
        data.admiddle,
        data.remark,
        data.online,
        data.fee,
        data.title,
        data.version,
        JsonManager.encode(data.streakRewards),
        JsonManager.encode(data.matchRules),
        data.isPublic,
        data.isShow,
    }
    for k,v in pairs(keyWords) do
      hash[v[1]] = values[k]
    end

    sqlite:insert(tablename, hash)
  end
  sqlite:endTransaction()
end

-- 获取房间信息
function MainMenuRoomTabel:getRoomInfo()
  local db = DBHelper.shared():getDB()
  local sql = string.format("select * from %s", tablename)
  local reader = db:nrows(sql)
  return reader or {}
end
