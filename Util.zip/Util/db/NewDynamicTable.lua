--[[
-- 等级排行榜
-- Author: KKU28
-- Date: 2014-11-25 16:44:44
]]
NewDynamicTable = class("NewDynamicTable")

-- 等级排行榜
-- {"userid":6543538,"nick":"天地壹号","icon":"36","rank":1,"thevalue":100,"ach
-- ievename":"飞机王","achieveid":25,"iconframetype":0}

NewDynamicTable.db_name = "lexunmsglib.db"
local tablename = "t_newdynamicTable"
local RID = "rid"       -- 自增序号

local USERID = "userid"               -- 
local TIME = "Time"                   -- 
local REMARK = "Remark"   -- 

function NewDynamicTable:ctor()
    self:createTable()
end

-- 删除表
function NewDynamicTable:dropTable()
    local db = self:getOpenDB()
    local  sql  = "drop table " .. tablename
    db:execute(sql)
end
-- 删除行数据
function NewDynamicTable:deleteAllRows()
  local sql = string.format([[delete from %s where userid = %s]],  tablename,GameDataUser.shared().lxID)
  local db = self:getOpenDB()
  db:execute(sql)
end
-- 建表
function NewDynamicTable:createTable()
  local db = self:getOpenDB()
  local t = {
    [RID] = " INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL ",
    [USERID] = " Long",
    [TIME] = " VARCHAR",
    [REMARK] = " VARCHAR"
  }
  db:createTable(tablename, t)
end
-- 插入一條結果記錄
function NewDynamicTable:insertRecordOne(result)
  if(nil == result) then
    return
  end
  local db = self:getOpenDB()
  self:insertRecordInfo(result,db)
end

--写一条记录
function NewDynamicTable:insertRecordInfo(result ,db)
    if(nil == result) then
        return
    end
    local hash = {}  
    hash[USERID] = GameDataUser.shared().lxID
    hash[TIME] = result.Time
    hash[REMARK] = result.Remark
    local rid = 0
    rid = db:insert(tablename, hash)
    return rid
end

-- 查询结果列表
function NewDynamicTable:getList()
    local list = {}
    local db = self:getOpenDB()
    local reader = nil
    local sql = string.format([[ select * from %s where userid = %s]],  tablename,GameDataUser.shared().lxID)
    reader = db:nrows(sql)
    return reader or {}
end

-- 根据list插入记录
function NewDynamicTable:insertList( list ,notDelete)
    list = list or {}
    print("in insertRankList list,notDelete",#list,notDelete)
    if not list or #list < 1 then return end
    local db = self:getOpenDB()
    db:beginTransaction()
    self:deleteAllRows()
    local len = #list
    for i = 1,len do
        self:insertRecordOne(list[i])
    end
    db:commitTransaction()
end

-- 获得公用数据库接口
function NewDynamicTable:getOpenDB()
    local db = DBHelper.shared():getDB()
    return db
end

return NewDynamicTable
