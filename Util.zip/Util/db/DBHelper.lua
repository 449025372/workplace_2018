DBHelper = class("DBHelper")

DBHelper.db_name = "lexunmsglib.db"

AQLITE_VERSION = {
	{
		version = 1,             --vip数据库版本号
		list = {{n = "VipRank",t = "INTEGER"} }       --数据中需要添加的字段
	}     
}
--数据库是否需要插入新增加的列,默认false，当本地存储数据库版本小于AQLITE_VERSION中的任意版本时变成true
CONTENTVERSION = false  --MessageContent表
SESSIONVERSION = false  --MessageSession表     
for i,v in ipairs(AQLITE_VERSION) do
	if v.version > cc.UserDefault:getInstance():getIntegerForKey("CONTENTVERSION") then
		CONTENTVERSION = true
		break
	end
end
for i,v in ipairs(AQLITE_VERSION) do
	if v.version > cc.UserDefault:getInstance():getIntegerForKey("SESSIONVERSION") then
		SESSIONVERSION = true
		break
	end
end

function DBHelper:ctor()
	self.db = SqliteManager.new()
	self.db:openDB(DBHelper.db_name)
end

--得到DB
function DBHelper:getDB()
	if self.db ~= nil then  
		return self.db
	end
	self.db = SqliteManager.new()
	self.db:openDB(DBHelper.db_name)
	return self.db
end

--打开DB
function DBHelper.closeDB()
	self.db:closeDB()
end

--单例
function DBHelper.shared()
	if nil == _G["DBHelper.obj"] then
		_G["DBHelper.obj"] = DBHelper.new()
	end
	return _G["DBHelper.obj"]
end


--插入前把特殊字符替换
function DBHelper.replaceSymbol(S)
	if type(S) ~= "string" then return S end
	local function getS(S,s,p)
		local T = string.split(S,s) 
		local str = ""
		for i,v in ipairs(T) do
			str = str..v
			if i ~= #T then
				str = str..p
			end
		end
		if #T == 1 then return S end
		return str
	end
	S = getS(S,"'","999A")
	S = getS(S,"[","999B")
	S = getS(S,"]","999C")
	S = getS(S,"%","999D")
	S = getS(S,"&","999E")
	S = getS(S,"_","999F")
	S = getS(S,"(","999G")
	S = getS(S,")","999H")
	return S
end
--获取数据时把之前替换的特殊符号还原
function DBHelper.restoreSymbol(S)
	if type(S) ~= "string" then return S end
	S = string.gsub(S, "999A", "'")
	S = string.gsub(S, "999B", "[")
	S = string.gsub(S, "999C", "]")
	S = string.gsub(S, "999D", "%")
	S = string.gsub(S, "999E", "&")
	S = string.gsub(S, "999F", "_")
	S = string.gsub(S, "999G", "(")
	S = string.gsub(S, "999H", ")")
	return S
end
