--好友列表
PrivatePacketLimit = class("PrivatePacketLimit")
PrivatePacketLimit.db_name = "lexunmsglib.db"
local tablename = "privatePacketLimitTable"
local RID = "Rid"                 -- 自增序号
local USERID = "Userid"           -- 用户编号
local FRIUSERID = "FriUserid"     -- 好友编号
local BAGNUM = "BagNum"           -- 红包个数
local DATE = "Date"               --日期
function PrivatePacketLimit:ctor()
    self:createTable()
end
-- 删除表
function PrivatePacketLimit:dropTable()
    local db = self:getOpenDB()
    local  sql  = "drop table " .. tablename
    db:execute(sql)
end
-- 删除行数据
function PrivatePacketLimit:deleteAllRows()
    local db = self:getOpenDB()
    local  sql  = "delete from " .. tablename .. " where Userid ="..GameDataUser.shared().userID
    db:execute(sql)
end
-- 建表
function PrivatePacketLimit:createTable()
  local db = self:getOpenDB()
  local t = {
    [RID] = "INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL",
    [USERID] = " Long",
    [FRIUSERID] = " Long",
    [BAGNUM] = " INTEGER",
    [DATE] = " VARCHAR",
  }
  db:createTable(tablename, t)
end
-- 插入一條結果記錄
function PrivatePacketLimit:insertRecordOne(friendid)
    if friendid == nil then return end
    if self:getOneObjectNum(friendid) == 0 then
        self:insertRecordInfo(friendid)
    else
        self:updateRecord(friendid)
    end  
end
--创建一条新数据
function PrivatePacketLimit:insertRecordInfo(friendid)
    if self:getAllObjectNum() == 0 then --该玩家当天还没有给任何人发私人红包，删除他的所有私人红包记录
        self:deleteAllRows()
    end
    local db = self:getOpenDB()
    local hash = {}  
    hash[USERID] = GameDataUser.shared().userID
    hash[FRIUSERID] = friendid
    hash[BAGNUM] = 1
    hash[DATE] = os.date("%Y-%m-%d")
    local rid = 0
    rid = db:insert(tablename, hash)
    return rid
end
--刷新已存在的数据
function PrivatePacketLimit:updateRecord(friuserid)
    local num = self:getOneObjectNum(friuserid)
    local db = self:getOpenDB()
    local sql = string.format("update privatePacketLimitTable set BagNum = %s where FriUserid = %s and Userid = %s and Date = '%s'",num+1,friuserid,GameDataUser.shared().userID,os.date("%Y-%m-%d"))
    db:execute(sql)
end
--得到给一个玩家发红包的个数
function PrivatePacketLimit:getOneObjectNum(friuserid)
    local db = self:getOpenDB()
    local sql = "select * from privatePacketLimitTable where Userid = "..GameDataUser.shared().userID.." and FriUserid = "..friuserid.. " and Date = '"..os.date("%Y-%m-%d").."'"
    local data = db:nrows(sql)
    if #data==0 then return 0 end
    return data[1].BagNum or 0
end
--得到当天发红包的总个数
function PrivatePacketLimit:getAllObjectNum()
    local db = self:getOpenDB()
    local sql = "select * from privatePacketLimitTable where Userid = "..GameDataUser.shared().userID.." and Date = '"..os.date("%Y-%m-%d").."'"
    local data = db:nrows(sql)
    local num = 0 
    for i,v in ipairs(data) do
        num = num+v.BagNum
    end
    return num
end
-- 获得公用数据库接口
function PrivatePacketLimit:getOpenDB()
    local db = DBHelper.shared():getDB()
    return db
end
return PrivatePacketLimit