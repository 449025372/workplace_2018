--对应id的红包是否已经领取
--好友列表
RedbagState = class("RedbagState")

RedbagState.db_name = "lexunmsglib.db"
local tablename = "RedbagStateTable"
local RID = "Rid"                 -- 自增序号
local BAGGRID = "baggrid"         -- 红包id
local USERID = "userid"

function RedbagState:ctor()
    self:createTable()
end

-- 删除表
function RedbagState:dropTable()
    local db = self:getOpenDB()
    local  sql  = "drop table " .. tablename
    db:execute(sql)
end
-- 删除行数据
function RedbagState:deleteAllRows()
    local db = self:getOpenDB()
    local  sql  = "delete from " .. tablename
    db:execute(sql)
end
-- 建表
function RedbagState:createTable()
  local db = self:getOpenDB()
  local t = {
    [RID] = " INTEGER ",
    [BAGGRID] = " Long",
    [USERID] = " Long",
  }
  db:createTable(tablename, t)
end
-- 插入一條結果記錄
function RedbagState:insertRecordOne(result)
  if(nil == result) then
    return
  end
  local db = self:getOpenDB()
  self:insertRecordInfo(result,db)
end

--写一条记录
function RedbagState:insertRecordInfo(result ,db)
    if(nil == result) then
        return
    end
    local hash = {}  
    hash[RID] = result.Rid
    hash[BAGGRID] = result.baggrid --是否已经领取
    hash[USERID] = result.userid
    local rid = 0
    rid = db:insert(tablename, hash)
    return rid
end

--根据红包id得到是否领取过
function RedbagState:getStateWithId(id,userid)
	local db = self:getOpenDB()
	local sql = string.format([[ select * from %s where baggrid = %d and userid = %d ]],  tablename,id,userid)
    reader = db:nrows(sql)
    return reader
end

-- 查询结果列表
function RedbagState:getList()
    local list = {}
    local db = self:getOpenDB()
    local reader = nil
    local sql = string.format([[ select * from %s]],tablename)
    reader = db:nrows(sql)
    return reader or {}
end

-- 根据list插入记录
function RedbagState:insertList(list)
    if not list then return end
    if #list == 0 then self:deleteAllRows() return end
    print("in insertRankList list",#list)
    local db = self:getOpenDB()
    db:beginTransaction()
    self:deleteAllRows()
    local len = #list
    for i = 1,len do
        self:insertRecordOne(list[i])
    end
    db:commitTransaction()
end

-- 获得公用数据库接口
function RedbagState:getOpenDB()
    local db = DBHelper.shared():getDB()
    return db
end

return RedbagState
