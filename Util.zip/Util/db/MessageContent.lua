MessageContent = class()

MessageContent.db_name = "lexunmsglib.db"
MessageContent.tablename = "nl_content"

MessageContent.rid = "rid"
MessageContent.userid = "userid"--自己ID
MessageContent.objid = "objid"--聊天对象ID
MessageContent.objnick = "objnick"--聊天对象昵称

MessageContent.msgid = "msgid"--消息ID
MessageContent.senderid = "senderid"--发送者ID
MessageContent.receiverid = "receiverid"--接受者ID
MessageContent.content = "content"--消息内容
MessageContent.havemore = "havemore"--
MessageContent.content2 = "content2"--错误信息
MessageContent.writetime = "writetime"--写入时间
MessageContent.userface = "userface"--发送者头像
MessageContent.sendstate = "sendstate"--发送状态 1发送成功 0发送中 -1发送失败
MessageContent.gender = "gender"  --性别
MessageContent.lv = "lv"  --等级
MessageContent.lxid = "lxid"  --lxid

MessageContent.baggrid = "baggrid"
MessageContent.bagtype = "bagtype"
MessageContent.bagtotal = "bagtotal"
MessageContent.bagtotalnum = "bagtotalnum"
MessageContent.bagcontent = "bagcontent"

--抢红包提示信息
MessageContent.tipcontent = "tipcontent"
MessageContent.tipgrid = "tipgrid"
MessageContent.tipgold = "tipgold"
MessageContent.tipgrabnick = "tipgrabnick" --抢红包用户昵称
MessageContent.tipreciveid = "tiprecivenick" --抢红包用户id
MessageContent.tipiconid = "tipiconid"
MessageContent.tipnick = "tipnick" --发红包用户昵称
MessageContent.tipuserid = "tipuserid" --发红包用户id
MessageContent.tiptypeid = "tiptypeid"

MessageContent.VipRank = "VipRank" --vip等级 --版本0升级到1的添加字段 这个字段是发送者的vip
function MessageContent:ctor()
	self:createTable()
end

--创建表
function MessageContent:createTable()
	local sqlite = DBHelper.shared():getDB()
	
	  --创建会话表
	local tablename = "nl_content"
	local table = {
		rid = "INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL",
		userid = "INTEGER",
		objid = "INTEGER",
		objnick = "VARCHAR",
		msgid = "LONG",
		senderid = "INTEGER",
		receiverid = "INTEGER",
		content = "VARCHAR",
		havemore = "INTEGER",
		content2 = "VARCHAR",
		writetime = "LONG",
		userface = "VARCHAR",
		sendstate = "INTEGER",
		gender = "INTEGER",  --性别
		lv = "INTEGER",  --等级
		lxid = "INTEGER",

		baggrid = "INTEGER",
		bagtype = "INTEGER",
		bagtotal = "INTEGER",
		bagtotalnum = "INTEGER",
		bagcontent = "VARCHAR",

		tipcontent = "VARCHAR",
		tipgrid = "INTEGER",
		tipgold = "INTEGER",
		tipgrabnick = "VARCHAR", --抢红包用户昵称
		tipreciveid = "INTEGER", --抢红包用户id
		tipiconid = "INTEGER",
		tipnick = "VARCHAR",--发红包用户昵称
		tipuserid = "INTEGER", --发红包用户id
		tiptypeid = "INTEGER",
	}
	sqlite:createTable(tablename, table)
	sqlite:execute("create index if not exists ix_content_userid_objid on nl_content(userid, objid)")
	
end
--写一条数据
function MessageContent:insert(item, db)
	if CONTENTVERSION then --需要插入列
		local ver = cc.UserDefault:getInstance():getIntegerForKey("CONTENTVERSION")
		for i,v in ipairs(AQLITE_VERSION) do
			if v.version > ver then
				for j,w in ipairs(v.list) do
					local sql = "alter table nl_content add "..w.n.." "..w.t
					db:nrows(sql)
				end
			end
			if i == #AQLITE_VERSION then
				cc.UserDefault:getInstance():setIntegerForKey("CONTENTVERSION",v.version)
			end
		end
	end
	CONTENTVERSION = false

	if (nil == item) then
		return 0
	end

	local rid = 0
	if item.msgid > 0 then
		local rows = db:nrows("select * from nl_content where msgid = " .. item.msgid .. " and userid = " .. item.userid)
		if (#rows > 0) then
			return 0
		end
		if item.baggrid > 0 then
			rows = db:nrows("select * from nl_content where baggrid = " .. item.baggrid .. " and userid = " .. item.userid)
			if (#rows > 0) then
				return 0
			end
		end	
	end
	if item.msgid == 0 and item.objid < 10000 then
		item.msgid = item.writetime
	end

	--有可能出现特殊字符的字段
	item.objnick = DBHelper.replaceSymbol(item.objnick)
	item.content = DBHelper.replaceSymbol(item.content)
	item.bagcontent = DBHelper.replaceSymbol(item.bagcontent)
	item.tipcontent = DBHelper.replaceSymbol(item.tipcontent)
	item.tipgrabnick = DBHelper.replaceSymbol(item.tipgrabnick)
	item.tipnick = DBHelper.replaceSymbol(item.tipnick)
	local t = {
		userid = item.userid,
		objid = item.objid,
		objnick = item.objnick,
		msgid = item.msgid,
		senderid = item.senderid,
		receiverid = item.receiverid,
		content = item.content,
		havemore = item.havemore,
		content2 = item.content2,
		writetime = item.writetime,
		userface = item.userface,
		sendstate = item.sendstate,
		gender = item.gender,
		lv = item.lv,
		lxid = item.lxid,

		baggrid = item.baggrid,
		bagtype = item.bagtype,
		bagtotal = item.bagtotal,
		bagtotalnum = item.bagtotalnum,
		bagcontent = item.bagcontent,

		tipcontent = item.tipcontent,
		tipgrid = item.tipgrid,
		tipgold = item.tipgold,
		tipgrabnick = item.tipgrabnick,
		tipreciveid = item.tipreciveid,
		tipiconid = item.tipiconid,
		tipnick = item.tipnick,
		tipuserid = item.tipuserid,
		tiptypeid = item.tiptypeid,

		VipRank = item.VipRank
	}
	rid = db:insert(self.tablename, t)
	return rid
end

--写一条数据
function MessageContent:insertOne(item)
	local db = DBHelper.shared():getDB()
    self:insert(item, db)
	local rid = db:last_insert_rowid()
	return rid
end

--批量写
function MessageContent:insertList(list)
	local db = DBHelper.shared():getDB()
	db:beginTransaction()
	for k, v in pairs(list) do  
		self:insert(v, db)
	end
	db:commitTransaction()
end


--删除一条消息
function MessageContent:delMsgOne(msgid)
	local db = DBHelper.shared():getDB()
    db:execute("delete nl_content where msgid = " .. msgid)
end

--根据rid获取消息实例
function MessageContent:delMsgByRid(rid)
    if(rid == nil) then return end
    local db = DBHelper.shared():getDB()
    local sql = string.format("delete  from %s where rid = %s", self.tablename, rid)
    db:execute(sql)
end

--根据rid获取消息实例
function MessageContent:getMsg(rid)
	local db = DBHelper.shared():getDB()
    local sql = string.format("select * from %s where rid = %s", self.tablename, rid)
	local rows = db:nrows(sql)
	rows = self:restoreSymbol(rows)
    return rows or {}
end


--删除本次会话所有消息
function MessageContent:delMsg(userid, objid)
	local db = DBHelper.shared():getDB()
	local sql = "delete from " .. self.tablename .. " where userid = " .. userid .. " and objid = " .. objid
	db:execute(sql)
	return 1
end


--分页读取消息
--minrid 上次读取的消息列表中最小的rid 第一次传0
function MessageContent:getList(userid, objid, minrid, pagesize)
	if (minrid == 0) then
		minrid = 100000000
	end
	local db = DBHelper.shared():getDB()
   -- local sql = string.format("select * from (select * from %s where objid = %s and userid = %s order by msgid desc limit %s) order by rid", self.tablename, objid, userid, pagesize)
   local sql = string.format("select * from (select * from %s where objid = %s and userid = %s order by rid desc limit %s) order by rid", self.tablename, objid, userid, pagesize)
    print("sql=",sql)
    local rows = db:nrows(sql)


    local data = MessageSession.new():getDataById(userid,objid)
    if data[1] then
	    for i,v in ipairs(rows) do
	    	if v.senderid ~= v.userid then --修改该条数据说话玩家对应的属性值
	    		v.userface = data[1].userface
	    		v.objnick = data[1].sendername
	    		v.VipRank = data[1].VipRank
	    	end
	    end
	end
	rows = self:restoreSymbol(rows)
    return rows or {}
end

function MessageContent:restoreSymbol(data)
	if not data then return {} end 
	for i,v in ipairs(data) do
		v.objnick = DBHelper.restoreSymbol(v.objnick)
		v.content = DBHelper.restoreSymbol(v.content)
		v.bagcontent = DBHelper.restoreSymbol(v.bagcontent)
		v.tipcontent = DBHelper.restoreSymbol(v.tipcontent)
		v.tipgrabnick = DBHelper.restoreSymbol(v.tipgrabnick)
		v.tipnick = DBHelper.restoreSymbol(v.tipnick)
	end
	--dump(data)
	return data
end

function MessageContent:getListAgain(userid,objid,minrid,pagesize)
	local db = DBHelper.shared():getDB()
   	local sql = string.format("select * from %s where rid < %s and objid = %s and userid = %s order by rid desc limit %s", self.tablename, minrid, objid, userid, pagesize)
    print("sql=",sql)
    local rows = db:nrows(sql)
    local data = MessageSession.new():getDataById(userid,objid)
    if data[1] then
	    for i,v in ipairs(rows) do
	    	if v.senderid ~= v.userid then --修改该条数据说话玩家对应的属性值
	    		v.userface = data[1].userface
	    		v.objnick = data[1].sendername
	    		v.VipRank = data[1].VipRank
	    	end
	    end
	end
	rows = self:restoreSymbol(rows)
    return rows or {}
end

--local sql = string.format("select * from (select * from %s where rid < %s and objid = %s and userid = %s order by rid desc limit %s) order by rid", minrid, self.tablename, objid, userid, pagesize)

function MessageContent:getLastData(userid, objid, minrid, pagesize)
	--select * from t_test order by rid desc  limit 1
	if (minrid == 0) then
		minrid = 100000000
	end
	local db = DBHelper.shared():getDB()
    local sql = string.format("select * from %s where objid = %s and userid = %s order by rid desc limit 1 ", self.tablename, objid, userid, pagesize)
    local rows = db:nrows(sql)
    rows = self:restoreSymbol(rows)
    return rows or {}
end

--更新消息发送状态
--sendstate 1发送成功 0发送中 -1发送失败
function MessageContent:updateSendState(msgrid, msgid, sendstate)
	local db = DBHelper.shared():getDB()
    local sql = string.format("update %s set sendstate = %s, msgid = %s where rid = %s", self.tablename, sendstate, msgid, msgrid)
    db:execute(sql)
end

--发送失败
function MessageContent:msgSendFailed(msgrid, failedMsg)
	local db = DBHelper.shared():getDB()
    local sql = string.format("update %s set sendstate = '-1', content2 = '%s' where rid = %s", self.tablename, failedMsg, msgrid)
    db:execute(sql)
end

--根据msgID获取消息实例
function MessageContent:getMsgByMsgID(msgID)
	local db = DBHelper.shared():getDB()
    local sql = string.format("select * from %s where msgid = '%s'", self.tablename, msgID)
	local rows = db:nrows(sql)
	rows = self:restoreSymbol(rows)
	return rows or {}
end