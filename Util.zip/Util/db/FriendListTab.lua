--好友列表
FriendListTab = class("FriendListTab")

FriendListTab.db_name = "lexunmsglib.db"
local tablename = "nv_friendTable"
local RID = "Rid"                 -- 自增序号
local USERID = "Userid"           -- 用户编号
local FRIUSERID = "FriUserid"     -- 好友编号
local FRINICK = "FriNick"         -- 好友昵称
local MEMONICK = "MemoNick"       -- 好友备注昵称
local ICONID = "IconId"           -- 头像ID
local ICONURL = "IconUrl"         -- 头像地址
local TYPEID = "Typeid"           -- 好友分组
local LXUSERID = "LxUserID"       -- lxid
local VIPRANK = "VipRank"         -- vip等级

function FriendListTab:ctor()
    self:createTable()
end

-- 删除表
function FriendListTab:dropTable()
    local db = self:getOpenDB()
    local  sql  = "drop table " .. tablename
    db:execute(sql)
end
-- 删除行数据
function FriendListTab:deleteAllRows()
    local db = self:getOpenDB()
    local  sql  = "delete from " .. tablename .. " where Userid ="..GameDataUser.shared().userID
    db:execute(sql)
end
-- 删除一行指定的数据
function FriendListTab:deleteOneRow(id)
    local db = self:getOpenDB()
    local sql = "delete from nv_friendTable where FriUserid = "..id
    db:execute(sql)
end
-- 建表
function FriendListTab:createTable()
  local db = self:getOpenDB()
  local t = {
    [RID] = " INTEGER ",
    [USERID] = " Long",
    [FRIUSERID] = " Long",
    [FRINICK] = " VARCHAR",
    [MEMONICK] = " VARCHAR",
    [ICONID] = " INTEGER",
    [ICONURL] = " VARCHAR",
    [TYPEID] = "INTEGER",
    [LXUSERID] = "INTEGER",
    [VIPRANK] = "INTEGER"
  }
  db:createTable(tablename, t)
end
-- 插入一條結果記錄
function FriendListTab:insertRecordOne(result)
  if(nil == result) then
    return
  end
  local db = self:getOpenDB()
  self:insertRecordInfo(result,db)
end

--写一条记录
function FriendListTab:insertRecordInfo(result ,db)
    if(nil == result) then
        return
    end
    local hash = {}  
    hash[USERID] = GameDataUser.shared().userID
    hash[RID] = result.Rid
    hash[FRIUSERID] = result.FriUserid
    hash[FRINICK] = result.FriNick
    hash[MEMONICK] = result.MemoNick
    hash[ICONID] = result.IconId
    hash[ICONURL] = result.IconUrl
    hash[TYPEID] = result.Typeid
    hash[LXUSERID] = result.LxUserID
    hash[VIPRANK] = result.VipRank
    local rid = 0
    rid = db:insert(tablename, hash)
    return rid
end

function FriendListTab:updateRecord(friuserid,frinick,iconid)
    local db = self:getOpenDB()
    local sql = string.format("update nv_friendTable set IconId = %s, FriNick = '%s' where FriUserid = %s and Userid = %s",iconid, frinick, friuserid,GameDataUser.shared().userID)
    db:execute(sql)
end

-- 查询结果列表
function FriendListTab:getList()
    local list = {}
    local db = self:getOpenDB()
    local reader = nil
    local sql = string.format("select * from %s where Userid = %s",tablename,GameDataUser.shared().userID)
    reader = db:nrows(sql)
    return reader or {}
end

--查询一个玩家是否是自己的好友
function FriendListTab:isMyFriend(id)
    local db = self:getOpenDB()
    local sql = "select * from nv_friendTable where FriUserid = "..id.." and Userid = "..GameDataUser.shared().userID
    return db:nrows(sql)
end

-- 根据list插入记录
function FriendListTab:insertList(list)
    if not list then return end
    if #list == 0 then self:deleteAllRows() return end
    print("in insertRankList list",#list)
    local db = self:getOpenDB()
    db:beginTransaction()
    self:deleteAllRows()
    local len = #list
    for i = 1,len do
        self:insertRecordOne(list[i])
    end
    db:commitTransaction()
end

-- 获得公用数据库接口
function FriendListTab:getOpenDB()
    local db = DBHelper.shared():getDB()
    return db
end

return FriendListTab
