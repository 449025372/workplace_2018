--[[
描述：常见问答数据库表的操作类
作者：AnYuanLzh
公司：Lexun.com
日期：2015/01/22
]]
require("src.app.UIScene.Setting.QA_TableFile")

QATable = class()

QATable.tablename = "t_qalist"
QATable.i = "i"
QATable.q = "q"
QATable.a = "a"

function QATable:ctor()
    self:createTable()
end

--创建表
function QATable:createTable()
    local db = DBHelper.shared():getDB()
    local tablename = self.tablename
    local t = {
        [self.i] = "INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL ",
        [self.q] = "VARCHAR",
        [self.a] = "VARCHAR",
    }
    db:createTable(self.tablename, t)
    --DBHelper:closeDB()
end

--写一条记录
function QATable:insertOne(data, db)
    if(nil == data) then
        return
    end
    local hash = {}
    hash[self.i]=data.i
    hash[self.q]=data.q
    hash[self.a]=data.a
    rid = db:insert(self.tablename, hash)
    return rid
end

-- 批量写
-- 这个list是一个lua table
function QATable:insertList(list)
    local datas = list
    if datas ~= nil and #datas >= 0 then
        -- 打开数据库
        local db = DBHelper.shared():getDB()        
        db:beginTransaction()
        db:execute("delete from " .. self.tablename)
        for _, v in ipairs(datas) do 
            self:insertOne(v, db)
        end
        db:endTransaction()
        --db:closeDB()
    end
end

--删除表的全部数据
function QATable:deleteAllRows()
    local db = DBHelper.shared():getDB()
    local  sql  = "delete from " .. self.tablename
    db:execute(sql)
    -- db:closeDB()
end

-- 得到list列表
-- 获取所有的行
function QATable:getAllList()
    -- 打开数据库
    local db = DBHelper.shared():getDB()
    local sql ="select * from " .. self.tablename
    print("getList sql=",sql)
    local rows = db:nrows(sql)
    print("getList rows=",#rows)
    --db:closeDB()
    return rows or {}
end

-- 得到list列表
-- 模糊查询
function QATable:getList(searchword)
    if nil == searchword or searchword == "" then
        self:getAllList();
    end
        
    -- 打开数据库
    local db = DBHelper.shared():getDB()
    local sql ="select * from " .. self.tablename .. " where q like '%" .. searchword .. "%' or a like '%" .. searchword .. "%'"
    print("getList sql=",sql)
    local rows = db:nrows(sql)
    print("getList rows=",#rows)
    --db:closeDB()
    return rows or {}
end


-- 获取表实例
function QATable.shared()
    if nil == _G["QATable.obj"] then
        local t = QATable.new()
        t:insertList(Config_QA_Table);
        _G["QATable.obj"] = t
    end
    return _G["QATable.obj"]
end