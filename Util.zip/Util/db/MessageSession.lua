MessageSession = class()

MessageSession.db_name = "lexunmsglib.db"
MessageSession.tablename = "dl_session"
MessageSession.rid = "rid"
MessageSession.userid = "userid"
MessageSession.senderid = "senderid"
MessageSession.sendername = "sendername"
MessageSession.userface = "userface"
MessageSession.newmsgcount = "newmsgcount"
MessageSession.lasttime = "lasttime"
MessageSession.title = "title"
MessageSession.gender = "gender"  --性别
MessageSession.lv = "lv"  --等级
MessageSession.lxid = "lxid"
MessageSession.VipRank = "VipRank" --vip等级 --版本0升级到1的添加字段 这个字段是别人的vip

MessageSession.baggrid = "baggrid"            --红包编号
MessageSession.bagtype = "bagtype"			--红包type 0拼手气红包 1普通红包 2口令红包 3一对一红包		
MessageSession.bagreciveuserid = "bagreciveuserid"	--收红包用户id
MessageSession.bagtotal = "bagtotal"			--红包总金额
MessageSession.bagtotalnum = "bagtotalnum"			--红包个数
MessageSession.bagcontent = "bagcontent"			--内容 发口令红包时 此处填写口令



function MessageSession:ctor()
	self:createTable()
end

--创建表
function MessageSession:createTable()
	local sqlite = DBHelper.shared():getDB()
	--创建会话表
	local tablename = "dl_session"
	local table = {
		rid = "INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL",
		--------聊天信息
		userid = "INTEGER",
		senderid = "INTEGER",
		sendername = "VARCHAR",
		userface = "VARCHAR",
		newmsgcount = "INTEGER",
		lasttime = "LONG",
		title="VARCHAR",
		gender = "INTEGER",  --性别
		lv = "INTEGER",  --等级
		lxid = "INTEGER",

		--------红包信息
       baggrid = "INTEGER",   
       bagtype = "INTEGER",			
       --bagreciveuserid = "INTEGER",
       bagtotal = "INTEGER",
       bagtotalnum = "INTEGER",	
       bagcontent = "VARCHAR",	
	}
	sqlite:createTable(tablename, table)
end


function MessageSession:getDataById(userid,senderid)
	if userid == nil or senderid == nil then return {} end
	local db = DBHelper.shared():getDB()
	local sql = "select * from dl_session where userid = "..userid.." and senderid = "..senderid
	local rows = db:nrows(sql)
	rows = self:restoreSymbol(rows)
	return rows or {}
end

--得到我的会话列表
function MessageSession:getList(userid)
    if(userid == nil) then return {} end
	local db = DBHelper.shared():getDB()
    -- 打开数据库
    --local sql = string.format("select * from %s where userid = %s order by lasttime desc", self.tablename, userid)
	local sql = string.format("select a.*,substr(c.content, 1, 20) content from dl_session a inner join (select objid, userid, max(rid) rid from nl_content group by objid, userid) b on a.userid = b.userid and a.senderid = b.objid inner join nl_content c on b.rid = c.rid and a.senderid = c.objid and a.userid = c.userid where a.userid = %s order by a.lasttime desc", userid)
	--"select a.*,substr(c.content, 1, 20) content from t_session a inner join (select objid, userid, max(rid) rid from nl_content group by objid, userid) b on a.userid = b.userid and a.senderid = b.objid inner join nl_content c on b.rid = c.rid and a.senderid = c.objid and a.userid = c.userid where a.userid = " .. userid .. " order by a.lasttime desc"
	local rows = db:nrows(sql)
	rows = self:restoreSymbol(rows)
	return rows or {}
end

--得到我的会话列表
function MessageSession:getListBySenderid(userid,senderid)
    if(userid == nil) then return {} end
	local db = DBHelper.shared():getDB()
    -- 打开数据库
    --local sql = string.format("select * from %s where userid = %s order by lasttime desc", self.tablename, userid)
	local sql = string.format("select a.*,substr(c.content, 1, 20) content from dl_session a inner join (select objid, userid, max(rid) rid from nl_content group by objid, userid) b on a.userid = b.userid and a.senderid = b.objid inner join nl_content c on b.rid = c.rid and a.senderid = c.objid and a.userid = c.userid where a.userid = %s and a.senderid = %s order by a.lasttime desc", userid,senderid)
	--"select a.*,substr(c.content, 1, 20) content from t_session a inner join (select objid, userid, max(rid) rid from nl_content group by objid, userid) b on a.userid = b.userid and a.senderid = b.objid inner join nl_content c on b.rid = c.rid and a.senderid = c.objid and a.userid = c.userid where a.userid = " .. userid .. " order by a.lasttime desc"
	local rows = db:nrows(sql)
	rows = self:restoreSymbol(rows)
	return rows or {}
end


--获取userid 对应的未读消息数目
function MessageSession:getUnReadMsgNum()
	local count = 0
	local userId = GameDataUser.shared().userID
	if(userId == nil) then return count end
	local db = DBHelper.shared():getDB()
    --local sql = string.format("select * from %s where userid = %s order by lasttime desc", self.tablename, userid)
	local sql = "select sum(newmsgcount) as num  from dl_session where userid = "..userId
	local result = db:nrows(sql)
	if(result ~= nil and result[1] ~= nil and result[1].num ~= nil ) then
		count = result[1].num
	end
	return count
end


--写一条记录
function MessageSession:insert(friEnt, db , notadd)
	print("============SESSIONVERSION",SESSIONVERSION)
	if SESSIONVERSION then --需要插入列
		local ver = cc.UserDefault:getInstance():getIntegerForKey("SESSIONVERSION")
		for i,v in ipairs(AQLITE_VERSION) do
			if v.version > ver then
				for j,w in ipairs(v.list) do
					local sql = "alter table dl_session add "..w.n.." "..w.t
					db:nrows(sql)
				end
			end
			if i == #AQLITE_VERSION then
				cc.UserDefault:getInstance():setIntegerForKey("SESSIONVERSION",v.version)
			end
		end
	end
	SESSIONVERSION = false

	if (nil == friEnt) then
		return 0
	end
	
	local rid = 0
	local sql = string.format("select rid from %s where userid = %s and senderid = %s", self.tablename, friEnt.userid, friEnt.senderid);
	
	local rows = db:nrows(sql)
	

	--有可能出现特殊字符的字段
	--dump(friEnt)
	friEnt.sendername = DBHelper.replaceSymbol(friEnt.sendername)
	friEnt.title = DBHelper.replaceSymbol(friEnt.title)
	friEnt.bagcontent = DBHelper.replaceSymbol(friEnt.bagcontent)

	if (#rows > 0) then
		if tonumber(friEnt.newmsgcount) ~= 0 then
			if notadd then
				sql = string.format("update %s set newmsgcount = newmsgcount,title = '%s',lasttime = '%s'  where userid = %s and senderid = %s", self.tablename, friEnt.title, friEnt.lasttime, friEnt.userid, friEnt.senderid)
			else
				sql = string.format("update %s set newmsgcount = newmsgcount + 1,title = '%s',lasttime = '%s'  where userid = %s and senderid = %s", self.tablename, friEnt.title, friEnt.lasttime, friEnt.userid, friEnt.senderid)
			end
		else
			sql = string.format("update %s set title = '%s',lasttime = '%s'  where userid = %s and senderid = %s", self.tablename, friEnt.title, friEnt.lasttime, friEnt.userid, friEnt.senderid)
		end
		print("---------------------insert",sql)
		db:execute(sql)
        if (friEnt.userface ~= nil and friEnt.userface ~= "" and friEnt.sendername ~= nil and friEnt.sendername ~= "") then
        print("=======friEnt.sendername111",friEnt.sendername)
			sql = string.format("update %s set userface = '%s', sendername ='%s' where userid = %s and senderid = %s", 
				self.tablename, friEnt.userface, friEnt.sendername, friEnt.userid, friEnt.senderid)
            print("insert********************",sql)
			db:execute(sql)
		end
		if friEnt.lxid ~= nil and friEnt.lxid ~= "" then
			sql = string.format("update %s set lxid = '%s' where userid = %s and senderid = %s", self.tablename, friEnt.lxid, friEnt.userid, friEnt.senderid)
            print("insert********************",sql)
			db:execute(sql)
		end
		if friEnt.baggrid ~= nil and friEnt.baggrid ~="" then
			sql = string.format("update %s set baggrid = %d, bagtype =%d,bagtotal=%d,bagtotalnum = %d, bagcontent = '%s' ,senderid = %d where userid = %s and senderid = %s", 
				self.tablename,friEnt.baggrid,friEnt.bagtype,friEnt.bagtotal,
				friEnt.bagtotalnum,friEnt.bagcontent,friEnt.senderid,friEnt.userid, friEnt.senderid)
			print("insert *********************redbag",sql)
			db:execute(sql)
		end
	else
		local t = {
		USERID = friEnt.userid,
		SENDERID = friEnt.senderid,
		SENDERNAME = friEnt.sendername,
		USERFACE = friEnt.userface,
		NEWMSGCOUNT = friEnt.newmsgcount,
		LASTTIME = friEnt.lasttime,
		TITLE = friEnt.title,
		GENDER = friEnt.gender,  --性别
		LV = friEnt.lv,  --等级
		LXID = friEnt.lxid,

		BAGGRID = friEnt.baggrid,
		BAGTYPE = friEnt.bagtype,
		--BAGRECIVEUSERID = friEnt.bagreciveuserid,
		BAGTOTAL = friEnt.bagtotal,
		BAGTOTALNUM = friEnt.bagtotalnum,
		BAGCONTENT = friEnt.bagcontent,
		VipRank = friEnt.VipRank,
		}
		rid = db:insert(self.tablename, t)
	end
	return rid
end


--写一条记录
function MessageSession:insertOne(item,notAdd)
--	dump(item)
	local db = DBHelper.shared():getDB()
    self:insert(item, db , notAdd)
end


--批量写
function MessageSession:insertList(friList)
	local db = DBHelper.shared():getDB()
	db:beginTransaction()
	for k, v in pairs(friList) do  
		self:insert(v, db)
	end
	db:commitTransaction()
end

function MessageSession:restoreSymbol(data)
	if not data then return {} end 
	for i,v in ipairs(data) do
		v.sendername = DBHelper.restoreSymbol(v.sendername)
		v.title = DBHelper.restoreSymbol(v.title)
		v.bagcontent = DBHelper.restoreSymbol(v.bagcontent)
	end
	return data
end
--删除会话
function MessageSession:delete(userid, senderid)
	local db = DBHelper.shared():getDB()
    local sql = string.format("delete from %s where userid = %s and senderid = %s", self.tablename, userid, senderid)
	db:execute(sql)
end


--清理未读消息
function MessageSession:msgRead(userid, senderid)
	local db = DBHelper.shared():getDB()
    local sql = string.format("update %s set newmsgcount = 0 where userid = %s and senderid = %s", self.tablename, userid, senderid)
	db:execute(sql)
end


--修改头像昵称
function MessageSession:updateUserfaceNick(userid, senderid, userface, nick, title)
	local db = DBHelper.shared():getDB()
	nick = DBHelper.replaceSymbol(nick)
    local sql = string.format("update %s set userface = '%s', sendername = '%s', title = '%s' where userid = %s and senderid = %s", 
		self.tablename, userface, string.gsub(nick, "'", ""), title, userid, senderid)
	print("updateUserfaceNick:",sql)
    -- db:openDB(self.db_name)
	db:execute(sql)
end

-- 获取senderid的信息
function MessageSession:getSendUserIDInfo(senderid)
	local db = DBHelper.shared():getDB()
	local sql = string.format("select * from %s where senderid = %s", self.tablename, senderid)
	local rows = db:nrows(sql)
	rows = self:restoreSymbol(rows)
	return rows or {}
end