--多平台接入的管理类 
PlatformManager = class()
local targetPlatform = cc.Application:getInstance():getTargetPlatform()

function callNative(className, methodName, args, sigs)
	local ok,ret
	if cc.PLATFORM_OS_ANDROID == targetPlatform then
	    ok,ret  = luaj.callStaticMethod(className,methodName,args,sigs)
	    if not ok then
	        print("luaj error:",ret)
	    else
	        print("luaj success:",ret)
	    end
	elseif cc.PLATFORM_OS_IPHONE == targetPlatform or cc.PLATFORM_OS_IPAD == targetPlatform then
	    ok,ret  = luaoc.callStaticMethod(className,methodName,args)
	    if not ok then
	      	print("luac error:", ret)
	    else
	      	print("luac success:", ret)
	    end
    end

    return ok,ret
end

function PlatformManager.init()
	require(ChannelCfgs.netCfg)
	require(ChannelCfgs.urlManager)
	require(ChannelCfgs.loginManager)
	require(ChannelCfgs.lxLoginManager)
	require(ChannelCfgs.personCenterModel)
	require(ChannelCfgs.PersonCenterView)
	require(ChannelCfgs.resLoaderManager)
	if ChannelCfgs.iapApi then
		require(ChannelCfgs.iapApi)
		IAPApi.init()
	end

	if ChannelCfgs.UCApi then
		require(ChannelCfgs.UCApi)
	end

	if ChannelCfgs.MiUiApi then
		require(ChannelCfgs.MiUiApi)
	end

	if ChannelCfgs.alipayManager then
		require(ChannelCfgs.alipayManager)
		AlipayManager.appid = ChannelCfgs.alipay.appid
		AlipayManager.publicKey = ChannelCfgs.alipay.publicKey
	end

	if ChannelCfgs.wxApi then
		require(ChannelCfgs.wxApi)
		WxApi.appid = ChannelCfgs.wechat.appid
		WxApi.secret = ChannelCfgs.wechat.secret
		WxApi.package = ChannelCfgs.wechat.package
		WxApi.public = ChannelCfgs.wechat.public
		WxApi.init()
	end

	if ChannelCfgs.bankpayManager then
		require(ChannelCfgs.bankpayManager)
	end

	if ChannelCfgs.qq then
		require("src.Util.third_party.QQApi")
		QQApi.appid = ChannelCfgs.qq.appid
		QQApi.secret = ChannelCfgs.qq.secret
		QQApi.init()
	end

	if ChannelCfgs.myAppApi then
		require(ChannelCfgs.myAppApi)
	end
end

function PlatformManager.getLoginSceneName()
	return ChannelCfgs.loginScene
end

function PlatformManager.getRechargeName()
	return ChannelCfgs.rechargeLayer or "src.app.UIScene.Recharge.RechargeView"
end
