RESOURCES = {}

RESOURCES.plist = {"tcs_use/tcs_plist.plist",
				   "tcs_use/tcs_skins.plist"}
