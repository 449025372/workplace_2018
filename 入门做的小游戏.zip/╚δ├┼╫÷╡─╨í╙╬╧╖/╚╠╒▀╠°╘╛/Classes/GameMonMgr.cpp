#include "GameMonMgr.h"
#include "GamePlayer.h"
#include "header.h"

float g_fMonsterTime = 2.0;

static CGameMonMgr* s_pMonMgr = NULL;
CGameMonMgr* CGameMonMgr::getMonsterMgr()
{
	if (s_pMonMgr == NULL)
	{
		s_pMonMgr = CGameMonMgr::create();
	}
	return s_pMonMgr;
}

bool CGameMonMgr::init()
{
	if (!Layer::init())
	{
		return false;
	}

	m_pMonsterList = Array::create();
	m_pMonsterList->retain();

	this->scheduleUpdate();

	return true;
}

void  CGameMonMgr::update(float dt)
{
	//���ݵ÷�ˢ�¹����ٶ�
	if (g_iScore > 1000 && g_iScore <= 2000)
	{
		g_fMonsterTime = 1.5f;
	}
	else if (g_iScore > 2000)
	{
		g_fMonsterTime = 1.0f;
	}

	this->schedule(schedule_selector(CGameMonMgr::updateMonster), g_fMonsterTime);
}

void CGameMonMgr::updateMonster(float dt)
{
	CGameMonster* pMonster = CGameMonster::create();
	m_pMonsterList->addObject(pMonster);					//��������������б�
	this->addChild(pMonster);
}

void  CGameMonMgr::setStaticNull()
{
	s_pMonMgr = NULL;
}