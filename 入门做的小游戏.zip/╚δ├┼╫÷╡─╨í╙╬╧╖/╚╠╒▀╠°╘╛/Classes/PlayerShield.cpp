#include "PlayerShield.h"
#include "GamePlayer.h"
#include "header.h"

bool CPlayerShield::init()
{
	if (!Layer::init())
	{
		return false;
	}

	//���ڳߴ�
	auto size = Director::getInstance()->getVisibleSize();
	//���
	CGamePlayer* pCurPlayer = CGamePlayer::getPlayer();
	//�����ͼ
	Sprite* pPlayer = pCurPlayer->m_pPlayerSprite;

	//��ʼ����ͼ
	m_pShield = Sprite::createWithSpriteFrameName("shieldpack.png");
	m_pShield->setPosition(size.width - 52, 700);

	this->addChild(m_pShield);

	//��ʱ��
	this->scheduleUpdate();

	return true;
}

void CPlayerShield::update(float dt)
{
	m_pShield->setPositionY(m_pShield->getPositionY()-g_fRoadSpeed);
}