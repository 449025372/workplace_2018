#include "GameMenu.h"
#include "GameMain.h"
#include "header.h"

Scene* CGameMenu::createMenu()
{
	auto scene = Scene::create();
	auto layer = CGameMenu::create();
#ifdef WIN32        // WIN32ƽ̨
#else
	layer->setPositionX(25.0f);  // ����
#endif
	scene->addChild(layer);
	return scene;
}

bool CGameMenu::init()
{
	//�ָ���ͣ
	Director::getInstance()->resume();

	if (!Layer::init())
	{
		return false;
	}
	auto size = Director::getInstance()->getVisibleSize();

	//�˵�����
	auto bg = Sprite::createWithSpriteFrameName("bg.png");
	bg->setPosition(size.width / 2 , size.height / 2);
	bg->setContentSize(size);
	this->addChild(bg, 0);

	//�˵�
	SpriteFrameCache* pCache = SpriteFrameCache::getInstance();
	//��ʼ��ť
	auto startBtn = MenuItemImage::create();
	startBtn->setNormalSpriteFrame(pCache->getSpriteFrameByName("play_button.png"));
	startBtn->setSelectedSpriteFrame(pCache->getSpriteFrameByName("sel_play_button.png"));
	startBtn->initWithCallback(CC_CALLBACK_1(CGameMenu::startGame, this));
	startBtn->setPosition(size.width/2, 180);
	auto act = ScaleTo::create(1.0, 1.2f);
	auto act2 = ScaleTo::create(1.0, 1.5f);
	Sequence* pSeq = Sequence::create(act, act2, nullptr);
	startBtn->runAction(RepeatForever::create(pSeq));
	//�뿪��ť
	auto exitBtn = MenuItemImage::create();
	exitBtn->setNormalSpriteFrame(pCache->getSpriteFrameByName("exit_button.png"));
	exitBtn->setSelectedSpriteFrame(pCache->getSpriteFrameByName("sel_exit_button.png"));
	exitBtn->initWithCallback(CC_CALLBACK_1(CGameMenu::exitGame, this));
	exitBtn->setPosition(size.width / 2, 100);
	//�˵�����
	Menu* pMenu = Menu::create();
	pMenu->addChild(startBtn);
	pMenu->addChild(exitBtn);
	pMenu->setPosition(Vec2::ZERO);
	this->addChild(pMenu, 1);

	//��������
	m_pMusic = SimpleAudioEngine::getInstance();
	m_pMusic->preloadBackgroundMusic("audio/bgm.mp3");
	m_pMusic->playBackgroundMusic("audio/bgm.mp3", true);

	//��������
	CheckBox* pAudioBox = CheckBox::create("menu/audioon.png", "menu/audiooff.png");
	pAudioBox->setPosition(Vec2(40 , 40));
	pAudioBox->addEventListener(CC_CALLBACK_2(CGameMenu::audioCallBack, this));
	this->addChild(pAudioBox);

	return true;
}

void CGameMenu::startGame(Ref* pSender)
{
	Scene* pScene = TransitionFade::create(1.0f,CGameMain::createGame(),Color3B(255,255,255));
	Director::getInstance()->replaceScene(pScene);
}

void CGameMenu::exitGame(Ref* pSender)
{
	Director::getInstance()->end();
}

void CGameMenu::audioCallBack(Ref* pSender, CheckBox::EventType type)
{
	switch (type)
	{
	case CheckBox::EventType::SELECTED:
		SimpleAudioEngine::getInstance()->stopBackgroundMusic();
		break;

	case CheckBox::EventType::UNSELECTED:
		SimpleAudioEngine::getInstance()->resumeBackgroundMusic();
		break;

	default:
		break;
	}
}
