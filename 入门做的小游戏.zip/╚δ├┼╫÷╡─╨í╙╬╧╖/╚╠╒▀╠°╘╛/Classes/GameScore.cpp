#include "GameScore.h"
#include "header.h"

//�÷�
int g_iScore = 0;

bool CGameScore::init()
{
	if (!Layer::init())
	{
		return false;
	}

	//���ڳߴ�
	auto size = Director::getInstance()->getVisibleSize();
	//�÷ֱ���
	m_pScoreBg = Sprite::create("score/score_bar.png");
	m_pScoreBg->setPosition(Vec2(size.width / 2, size.height / 2 + 160));
	this->addChild(m_pScoreBg);
	
	//�÷���ʾ
	m_lScore = Label::createWithTTF("0", "fonts/simhei.ttf", 24);
	m_lScore->setPosition(Vec2(size.width / 2, size.height / 2 + 160));
	this->addChild(m_lScore);
	//���µ÷�
	this->scheduleUpdate();

	return true;
}

void CGameScore::update(float dt)
{
	g_iScore++;
	char szText[100] = { 0 }; 
	sprintf(szText, "%d", g_iScore);
	m_lScore->setString(szText);
}