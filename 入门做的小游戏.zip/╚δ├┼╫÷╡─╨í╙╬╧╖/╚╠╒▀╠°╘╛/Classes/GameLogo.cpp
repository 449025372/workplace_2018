#include "GameLogo.h"
#include "GameLoad.h"

 Scene* CGameLogo::createLogo()
{
	 auto scene = Scene::create();
	 auto layer = CGameLogo::create();
#ifdef WIN32        // WIN32ƽ̨
#else
	 layer->setPositionX(25.0f);  // ����
#endif
	 scene->addChild(layer);
	 return scene;
}

 bool CGameLogo::init()
{
	 if (!Layer::init())
	 {
		 return false;
	 }
	 //��ȡ��Ļ�ߴ�
	 auto size = Director::getInstance()->getVisibleSize();
	 //����logoͼƬ
	 auto bg = Sprite::create("logo/logo.png");
	 bg->setPosition(size.width / 2, size.height / 2);
	 this->addChild(bg, 0);

	 this->scheduleOnce(schedule_selector(CGameLogo::loadingLoad), 1.0f);

	 return true;
}

 void CGameLogo::loadingLoad(float dt)
 {
	 Scene* pScene = TransitionFade::create(0.1f, CGameLoad::createLoad());
	 Director::getInstance()->replaceScene(pScene);
 }