#include "GamePlayer.h"
#include "GameMenu.h"
#include "header.h"

enum
{
	FACE_LEFT,
	FACE_RIGHT,
};

static CGamePlayer* s_pPlayer = NULL;		//��̬��Ҷ���
CGamePlayer* CGamePlayer::getPlayer()
{
	if (s_pPlayer == NULL)
	{
		s_pPlayer = CGamePlayer::create();
	}
	return s_pPlayer;
}

bool CGamePlayer::init()
{
	if (!Layer::create())
	{
		return false;
	}
	m_bTouch = false;
	m_iFace = FACE_LEFT;
	m_bAtk = false;

	//��ҳ�ʼ��
	playerInit();

	//������ӳ�ʼ��
	patricleInit();

	//�Ƿ�����
	m_bDead = false;

	//������ʼ��
	bonusInit();
	m_bBonusAni = false;
	m_bBonusBegin = false;

	// ������������
	auto touchListener = EventListenerTouchOneByOne::create();
	touchListener->onTouchBegan = CC_CALLBACK_2(CGamePlayer::onTouchBegan, this);		//������Ļ
	touchListener->onTouchMoved = CC_CALLBACK_2(CGamePlayer::onTouchMoved, this);		//�ƶ���Ļ
	touchListener->onTouchEnded = CC_CALLBACK_2(CGamePlayer::onTouchEnded, this);		//�뿪��Ļ
	_eventDispatcher->addEventListenerWithSceneGraphPriority(touchListener, this);

	//��ʱ��
	this->scheduleUpdate();

	return true;
}

bool CGamePlayer::onTouchBegan(Touch* touch, Event* event)
{
	//����״̬����
	m_bAtk = true;
	//���ڳߴ�
	auto size = Director::getInstance()->getVisibleSize();

	//���ڷ�	������Ч
	if (m_pPlayerSprite->getPositionX() > 40 && m_pPlayerSprite->getPositionX() < size.width - 40)
	{
		return true;
	}

	//ֹͣ���ж���
	m_pPlayerSprite->stopAllActions();
	m_bTouch = true;

	auto pCache = SpriteFrameCache::getInstance();
	auto animation = Animation::create();
	for (int i = 1; i < 11; i++)
	{
		char szText[100] = { 0 };
		sprintf(szText, "attack%d.png", i);
		animation->addSpriteFrame(pCache->getSpriteFrameByName(szText));
	}
	animation->setDelayPerUnit(0.05);
	animation->setRestoreOriginalFrame(true);
	auto animate = Animate::create(animation);
	m_pPlayerSprite->runAction(RepeatForever::create(animate));

	return true;
}

void CGamePlayer::onTouchEnded(Touch* touch, Event* event)
{
	
}

void CGamePlayer::onTouchMoved(Touch* touch, Event* event)
{

}

void CGamePlayer::playerInit()
{
	//���������ͼ
	m_pPlayerSprite = Sprite::createWithSpriteFrameName("run1.png");
	m_pPlayerSprite->setPosition(Vec2(40, 140));
	this->addChild(m_pPlayerSprite);
	//��Ҷ���
	auto animation = Animation::create();
	auto pCache = SpriteFrameCache::getInstance();
	for (int i = 1; i < 17; i++)
	{
		char szText[100] = { 0 };
		sprintf(szText, "run%d.png", i);
		animation->addSpriteFrame(pCache->getSpriteFrameByName(szText));
	}
	animation->setDelayPerUnit(0.04f);
	animation->setRestoreOriginalFrame(true);
	auto animate = Animate::create(animation);
	m_pPlayerSprite->runAction(RepeatForever::create(animate));
	//���Ѫ��
	m_iHp = 1;
}

void CGamePlayer::update(float dt)
{
	//���ڳߴ�
	auto size = Director::getInstance()->getVisibleSize();

	//���Ӹ���
	patricleFollow();

	//��èת��
	squirrelTurn();
	//����ת��
	bombTurn();

	//�����ƶ�
	if (m_bBonusAni)
	{
		//���������е�����ƶ�
		bonusMove();
		return;
	}

	//�����Ҵ���
	if (m_bTouch == true)
	{
		//���һ���ƶ�����
		int iMove = 10;
		//�����һ�û���ұ�	������ƶ����ұ�	���ж���
		if (m_iFace == FACE_LEFT)
		{
			//����ƶ�
			m_pPlayerSprite->setPositionX(m_pPlayerSprite->getPositionX() + iMove);
			//��������ұ�λ��	���ж���
			if (m_pPlayerSprite->getPositionX() >= size.width - 40)
			{
				m_pPlayerSprite->setPosition(size.width - 40, 140);
				m_bAtk = false;					//����״̬�ر�
				m_pPlayerSprite->stopAllActions();
				auto animation = Animation::create();
				auto pCache = SpriteFrameCache::getInstance();
				for (int i = 1; i < 17; i++)
				{
					char szText[100] = { 0 };
					sprintf(szText, "run%d.png", i);
					animation->addSpriteFrame(pCache->getSpriteFrameByName(szText));
				}
				animation->setDelayPerUnit(0.04f);
				animation->setRestoreOriginalFrame(true);

				auto animate = Animate::create(animation);
				m_pPlayerSprite->runAction(RepeatForever::create(animate));
				m_iFace = FACE_RIGHT;
				m_bTouch = false;
				m_pPlayerSprite->setFlipX(true);
			}
		}
		//�����һ�û�����	������ƶ������	���ж���
		else if (m_iFace == FACE_RIGHT)
		{
			//����ƶ�
			m_pPlayerSprite->setPositionX(m_pPlayerSprite->getPositionX() - iMove);
			//����������λ��	���ж���
			if (m_pPlayerSprite->getPositionX() <= 40)
			{
				m_pPlayerSprite->setPosition(40, 140);
				m_bAtk = false;			//����״̬�ر�
				m_pPlayerSprite->stopAllActions();
				auto animation = Animation::create();
				auto pCache = SpriteFrameCache::getInstance();
				for (int i = 1; i < 17; i++)
				{
					char szText[100] = { 0 };
					sprintf(szText, "run%d.png", i);
					animation->addSpriteFrame(pCache->getSpriteFrameByName(szText));
				}
				animation->setDelayPerUnit(0.04f);
				animation->setRestoreOriginalFrame(true);

				auto animate = Animate::create(animation);
				m_pPlayerSprite->runAction(RepeatForever::create(animate));
				m_iFace = FACE_LEFT;
				m_bTouch = false;
				m_pPlayerSprite->setFlipX(false);
			}
		}
	}
}

void CGamePlayer::bonusInit()
{
	m_iBirdBonus = 0;					//�����ۼ�
	m_iSquirrelBonus = 0;				//��è�����ۼ�
	m_iStarBonus = 0;					//���ڽ����ۼ�
	m_iBombBonus = 0;					//���ڽ����ۼ�

	//��ҽ���
	//��
	for (int i = 0; i < 3; i++)
	{
		//��ʼ��
		m_pPlayerBonus[i] = Sprite::createWithSpriteFrameName("bird1.png");
		m_pPlayerBonus[i]->setPosition(Vec2(50 + (i * 30), 30));
		
		//����
		m_pPlayerBonus[i]->setScale(0.8f);

		//����
		auto animation = Animation::create();
		auto pCache = SpriteFrameCache::getInstance();
		for (int i = 1; i < 13; i++)
		{
			char szText[32];
			sprintf(szText, "bird%d.png", i);
			animation->addSpriteFrame(pCache->getSpriteFrameByName(szText));
		}
		animation->setDelayPerUnit(0.05f);
		animation->setRestoreOriginalFrame(true);
		auto animate = Animate::create(animation);
		m_pPlayerBonus[i]->runAction(RepeatForever::create(animate));
		m_pPlayerBonus[i]->setVisible(false);

		this->addChild(m_pPlayerBonus[i]);
	}
	//��è
	for (int i = 3; i < 6; i++)
	{
		//��ʼ��
		m_pPlayerBonus[i] = Sprite::createWithSpriteFrameName("squirrel1.png");
		m_pPlayerBonus[i]->setPosition(Vec2(50 + (i - 3) * 30, 30));

		//����
		m_pPlayerBonus[i]->setScale(0.8f);

		//����
		auto animation = Animation::create();
		auto pCache = SpriteFrameCache::getInstance();
		for (int i = 1; i < 9; i++)
		{
			char szText[32];
			sprintf(szText, "squirrel%d.png", i);
			animation->addSpriteFrame(pCache->getSpriteFrameByName(szText));
		}
		animation->setDelayPerUnit(0.05f);
		animation->setRestoreOriginalFrame(true);
		auto animate = Animate::create(animation);
		m_pPlayerBonus[i]->runAction(RepeatForever::create(animate));
		m_pPlayerBonus[i]->setVisible(false);

		this->addChild(m_pPlayerBonus[i]);
	}
	//����
	for (int i = 6; i < 9; i++)
	{
		//��ʼ��
		m_pPlayerBonus[i] = Sprite::createWithSpriteFrameName("star.png");
		m_pPlayerBonus[i]->setPosition(Vec2(50 + (i - 6) * 30, 30));

		//����
		m_pPlayerBonus[i]->setScale(0.8f);

		//����
		auto act = RotateBy::create(1.5f, 360);
		m_pPlayerBonus[i]->runAction(RepeatForever::create(act));
		m_pPlayerBonus[i]->setVisible(false);
		this->addChild(m_pPlayerBonus[i]);
	}
	//����
	for (int i = 9; i < 12; i++)
	{
		//��ʼ��
		m_pPlayerBonus[i] = Sprite::createWithSpriteFrameName("bomb1.png");
		m_pPlayerBonus[i]->setPosition(Vec2(50 + (i - 9) * 30, 30));

		//����
		m_pPlayerBonus[i]->setScale(0.8f);

		//����
		auto animation = Animation::create();
		auto pCache = SpriteFrameCache::getInstance();
		for (int i = 1; i < 7; i++)
		{
			char szText[32];
			sprintf(szText, "bomb%d.png", i);
			animation->addSpriteFrame(pCache->getSpriteFrameByName(szText));
		}
		animation->setDelayPerUnit(0.05f);
		animation->setRestoreOriginalFrame(true);
		auto animate = Animate::create(animation);
		m_pPlayerBonus[i]->runAction(RepeatForever::create(animate));
		m_pPlayerBonus[i]->setVisible(false);

		this->addChild(m_pPlayerBonus[i]);
	}
}

void CGamePlayer::addBonus(int iBonus)
{
	//�����������
	if (iBonus == BONUS_BIRD)
	{
		//����������ȫ����ʼ��
		m_iSquirrelBonus = 0;
		m_iStarBonus = 0;
		m_iBombBonus = 0;
		for (int i = 3; i < 12; i++)
		{
			m_pPlayerBonus[i]->setVisible(false);
		}

		m_iBirdBonus++;
		//���ý�����ʾ
		if (m_iBirdBonus == 1)
		{
			m_pPlayerBonus[0]->setVisible(true);
		}
		if (m_iBirdBonus == 2)
		{
			m_pPlayerBonus[1]->setVisible(true);
		}
		if (m_iBirdBonus == 3)
		{
			m_pPlayerBonus[2]->setVisible(true);
		}
	}
	//�����������è
	if (iBonus == BONUS_SQUIRREL)
	{
		//����������ȫ����ʼ��
		m_iBirdBonus = 0;
		m_iStarBonus = 0;
		m_iBombBonus = 0;
		for (int i = 0; i < 3; i++)
		{
			m_pPlayerBonus[i]->setVisible(false);
		}
		for (int i = 6; i < 12; i++)
		{
			m_pPlayerBonus[i]->setVisible(false);
		}

		m_iSquirrelBonus++;
		//���ý�����ʾ
		if (m_iSquirrelBonus == 1)
		{
			m_pPlayerBonus[3]->setVisible(true);
		}
		if (m_iSquirrelBonus == 2)
		{
			m_pPlayerBonus[4]->setVisible(true);
		}
		if (m_iSquirrelBonus == 3)
		{
			m_pPlayerBonus[5]->setVisible(true);
		}
	}
	//��������Ƿ���
	if (iBonus == BONUS_STAR)
	{
		//����������ȫ����ʼ��
		m_iBirdBonus = 0;
		m_iSquirrelBonus = 0;
		m_iBombBonus = 0;
		for (int i = 0; i < 6; i++)
		{
			m_pPlayerBonus[i]->setVisible(false);
		}
		for (int i = 9; i < 12; i++)
		{
			m_pPlayerBonus[i]->setVisible(false);
		}

		m_iStarBonus++;
		//���ý�����ʾ
		if (m_iStarBonus == 1)
		{
			m_pPlayerBonus[6]->setVisible(true);
		}
		if (m_iStarBonus == 2)
		{
			m_pPlayerBonus[7]->setVisible(true);
		}
		if (m_iStarBonus == 3)
		{
			m_pPlayerBonus[8]->setVisible(true);
		}
	}
	//��������Ǳ���
	if (iBonus == BONUS_BOMB)
	{
		//����������ȫ����ʼ��
		m_iBirdBonus = 0;
		m_iSquirrelBonus = 0;
		m_iStarBonus = 0;
		for (int i = 0; i < 9; i++)
		{
			m_pPlayerBonus[i]->setVisible(false);
		}

		m_iBombBonus++;
		//���ý�����ʾ
		if (m_iBombBonus == 1)
		{
			m_pPlayerBonus[9]->setVisible(true);
		}
		if (m_iBombBonus == 2)
		{
			m_pPlayerBonus[10]->setVisible(true);
		}
		if (m_iBombBonus == 3)
		{
			m_pPlayerBonus[11]->setVisible(true);
		}
	}
	//��������ﵽ3��	��ʼ��	���ж���
	if (m_iBirdBonus == 3 || m_iSquirrelBonus == 3 || m_iStarBonus == 3 || m_iBombBonus == 3)
	{
		//����������ʼ
		m_bBonusAni = true;
		//���ؽ���
		for (int i = 0; i < 12; i++)
		{
			m_pPlayerBonus[i]->setVisible(false);
		}
		//����
		bonusAnimation();

		return;
	}

}

void CGamePlayer::bonusMove()
{
	//���ڳߴ�
	auto size = Director::getInstance()->getVisibleSize();

	//�����ƶ�
	if (m_iBirdBonus >= 3)
	{
		//�����Ҵ������
		if (m_iFace == FACE_LEFT && m_bBonusBegin == false)
		{
			auto act1 = MoveTo::create(1.0f, Vec3(size.width - 100, size.height / 2, 0));
			auto act2 = MoveTo::create(1.0f, Vec3(100, size.height / 2, 0));
			auto act3 = MoveTo::create(1.0f, Vec3(size.width - 40, 140, 0));
			Sequence* pSeq = Sequence::create(act1, act2, act3, nullptr);
			m_pPlayerSprite->runAction(pSeq);
			m_bBonusBegin = true;
		}
		//�����Ҵ��ұ���
		if (m_iFace == FACE_RIGHT && m_bBonusBegin == false)
		{
			auto act1 = MoveTo::create(1.0f, Vec3(100, size.height / 2, 0));
			auto act2 = MoveTo::create(1.0f, Vec3(size.width - 100, size.height / 2, 0));
			auto act3 = MoveTo::create(1.0f, Vec3(40, 140, 0));
			Sequence* pSeq = Sequence::create(act1, act2, act3, nullptr);
			m_pPlayerSprite->runAction(RepeatForever::create(pSeq));
			m_bBonusBegin = true;
		}
	}
	//���ڽ����ƶ�
	if (m_iStarBonus >= 3)
	{
		//�����Ҵ������
		if (m_iFace == FACE_LEFT && m_bBonusBegin == false)
		{
			auto act1 = MoveTo::create(0.5f, Vec3(size.width - 100, size.height / 2, 0));
			auto act2 = MoveTo::create(0.5f, Vec3(100, size.height / 2, 0));
			auto act3 = MoveTo::create(0.5f, Vec3(size.width - 100, size.height / 2, 0));
			auto act4 = MoveTo::create(0.5f, Vec3(100, size.height / 2, 0));
			auto act5 = MoveTo::create(0.5f, Vec3(size.width - 40, 140, 0));
			Sequence* pSeq = Sequence::create(act1, act2, act3, act4,act5, nullptr);
			m_pPlayerSprite->runAction(pSeq);
			m_bBonusBegin = true;
		}
		//�����Ҵ��ұ���
		if (m_iFace == FACE_RIGHT && m_bBonusBegin == false)
		{
			auto act1 = MoveTo::create(0.5f, Vec3(100, size.height / 2, 0));
			auto act2 = MoveTo::create(0.5f, Vec3(size.width - 100, size.height / 2, 0));
			auto act3 = MoveTo::create(0.5f, Vec3(100, size.height / 2, 0));
			auto act4 = MoveTo::create(0.5f, Vec3(size.width - 100, 140, 0));
			auto act5 = MoveTo::create(0.5f, Vec3(40, 140, 0));
			Sequence* pSeq = Sequence::create(act1, act2, act3, act4,act5, nullptr);
			m_pPlayerSprite->runAction(pSeq);
			m_bBonusBegin = true;
		}
	}
	//��è�����ƶ�
	if (m_iSquirrelBonus >= 3)
	{
		//�����Ҵ������
		if (m_iFace == FACE_LEFT && m_bBonusBegin == false)
		{
			m_pPlayerSprite->setFlipX(true);
			auto act1 = MoveTo::create(1.0f, Vec3(size.width - 40, size.height / 2, 0));
			auto act2 = MoveTo::create(1.0f, Vec3(40, size.height / 2, 0));
			auto act3 = MoveTo::create(1.0f, Vec3(size.width - 40, 140, 0));
			auto act4 = MoveTo::create(1.0f, Vec3(40, size.height / 2, 0));
			auto act5 = MoveTo::create(1.0f, Vec3(size.width - 40, 140, 0));
			Sequence* pSeq = Sequence::create(act1, act2, act3, act4, act5 ,nullptr);
			m_pPlayerSprite->runAction(RepeatForever::create(pSeq));

			m_bBonusBegin = true;
		}
		//�����Ҵ��ұ���
		if (m_iFace == FACE_RIGHT && m_bBonusBegin == false)
		{
			m_pPlayerSprite->setFlipX(false);
			auto act1 = MoveTo::create(1.0f, Vec3(40, size.height / 2, 0));
			auto act2 = MoveTo::create(1.0f, Vec3(size.width - 40, size.height / 2, 0));
			auto act3 = MoveTo::create(1.0f, Vec3( 40, 140, 0));
			auto act4 = MoveTo::create(1.0f, Vec3(size.width - 40, size.height / 2, 0));
			auto act5 = MoveTo::create(1.0f, Vec3(40, 140, 0));
			Sequence* pSeq = Sequence::create(act1, act2, act3, act4, act5, nullptr);
			m_pPlayerSprite->runAction(RepeatForever::create(pSeq));

			m_bBonusBegin = true;
		}
	}
	//���ڽ������ƶ�
	if (m_iBombBonus >= 3)
	{
		//�����Ҵ������
		if (m_iFace == FACE_LEFT && m_bBonusBegin == false)
		{
			m_pPlayerSprite->setFlipX(false);
			auto act1 = MoveTo::create(1.2f, Vec3(size.width - 100, size.height / 2, 0));
			auto act2 = MoveTo::create(1.2f, Vec3(100, size.height / 2, 0));
			auto act3 = MoveTo::create(1.2f, Vec3(size.width - 100, size.height / 2, 0));
			auto act4 = MoveTo::create(1.2f, Vec3(100, size.height / 2, 0));
			auto act5 = MoveTo::create(1.2f, Vec3(size.width - 40, 140, 0));
			Sequence* pSeq = Sequence::create(act1, act2, act3, act4, act5, nullptr);
			m_pPlayerSprite->runAction(pSeq);
			m_bBonusBegin = true;
		}
		//�����Ҵ��ұ���
		if (m_iFace == FACE_RIGHT && m_bBonusBegin == false)
		{
			m_pPlayerSprite->setFlipX(true);
			auto act1 = MoveTo::create(1.2f, Vec3(100, size.height / 2, 0));
			auto act2 = MoveTo::create(1.2f, Vec3(size.width - 100, size.height / 2, 0));
			auto act3 = MoveTo::create(1.2f, Vec3(100, size.height / 2, 0));
			auto act4 = MoveTo::create(1.2f, Vec3(size.width - 100, 140, 0));
			auto act5 = MoveTo::create(1.2f, Vec3(40, 140, 0));
			Sequence* pSeq = Sequence::create(act1, act2, act3, act4, act5, nullptr);
			m_pPlayerSprite->runAction(pSeq);
			m_bBonusBegin = true;
		}
	}
}

void  CGamePlayer::bonusAnimation()
{ 
	//���ڳߴ�
	auto size = Director::getInstance()->getVisibleSize();
	//�ƶ�����
	int iMove = 3;

	//��������
	if (m_iBirdBonus == 3)
	{
		m_pPlayerSprite->stopAllActions();

		//��
		auto animation = Animation::create();
		auto pCache = SpriteFrameCache::getInstance();
		for (int i = 1; i < 16; i++)
		{
			char szText[32];
			sprintf(szText, "bonus_bird%d.png", i);
			animation->addSpriteFrame(pCache->getSpriteFrameByName(szText));
		}
		animation->setDelayPerUnit(0.1f);
		animation->setRestoreOriginalFrame(true);
		auto animate = Animate::create(animation);
		m_pPlayerSprite->runAction(RepeatForever::create(animate));
		scheduleOnce(schedule_selector(CGamePlayer::rePlayerMove), 3.0f);
	}
	//���ڽ�������
	if (m_iStarBonus == 3)
	{
		m_pPlayerSprite->stopAllActions();

		//��
		auto animation = Animation::create();
		auto pCache = SpriteFrameCache::getInstance();
		for (int i = 1; i < 9; i++)
		{
			char szText[32];
			sprintf(szText, "stars%d.png", i);
			animation->addSpriteFrame(pCache->getSpriteFrameByName(szText));
		}
		animation->setDelayPerUnit(0.05f);
		animation->setRestoreOriginalFrame(true);
		auto animate = Animate::create(animation);
		m_pPlayerSprite->runAction(RepeatForever::create(animate));
		scheduleOnce(schedule_selector(CGamePlayer::rePlayerMove), 2.5f);
	}
	//��è��������
	if (m_iSquirrelBonus == 3)
	{
		m_pPlayerSprite->stopAllActions();

		//��
		auto animation = Animation::create();
		auto pCache = SpriteFrameCache::getInstance();
		for (int i = 1; i < 16; i++)
		{
			char szText[32];
			sprintf(szText, "bonus_squirrel%d.png", i);
			animation->addSpriteFrame(pCache->getSpriteFrameByName(szText));
		}
		animation->setDelayPerUnit(0.05f);
		animation->setRestoreOriginalFrame(true);
		auto animate = Animate::create(animation);
		m_pPlayerSprite->runAction(RepeatForever::create(animate));
		scheduleOnce(schedule_selector(CGamePlayer::rePlayerMove), 5.0f);
	}
	//���ڽ�������
	if (m_iBombBonus == 3)
	{
		m_pPlayerSprite->stopAllActions();

		//��
		auto animation = Animation::create();
		auto pCache = SpriteFrameCache::getInstance();
		animation->addSpriteFrame(pCache->getSpriteFrameByName("bomb.png"));
		animation->setDelayPerUnit(0.1f);
		animation->setRestoreOriginalFrame(true);
		auto animate = Animate::create(animation);
		m_pPlayerSprite->runAction(RepeatForever::create(animate));

		scheduleOnce(schedule_selector(CGamePlayer::rePlayerMove), 6.0f);
	}
}

void CGamePlayer::squirrelTurn()
{
	//���ڴ�С
	auto size = Director::getInstance()->getVisibleSize();

	//��èת��
	if (m_iSquirrelBonus >= 3)
	{
		//�տ�ʼ��������
		if (m_iFace == FACE_LEFT)
		{
			if (m_pPlayerSprite->getPositionX() <= 48)
			{
				m_pPlayerSprite->setFlipX(true);
			}
			if (m_pPlayerSprite->getPositionX() >= size.width - 48)
			{
				m_pPlayerSprite->setFlipX(false);
			}
		}
		//�տ�ʼ��������
		else if (m_iFace == FACE_RIGHT)
		{
			if (m_pPlayerSprite->getPositionX() <= 48)
			{
				m_pPlayerSprite->setFlipX(true);
			}
			if (m_pPlayerSprite->getPositionX() >= size.width - 48)
			{
				m_pPlayerSprite->setFlipX(false);
			}
		}
	}
}

void CGamePlayer::rePlayerMove(float dt)
{
	//��ʼ������
	m_iBirdBonus = 0;
	m_iSquirrelBonus = 0;
	m_iStarBonus = 0;
	m_iBombBonus = 0;
	//��������
	m_bBonusAni = false;
	m_bBonusBegin = false;
}

void CGamePlayer::setStaticNull()
{
	s_pPlayer = NULL;
}

void CGamePlayer::bombTurn()
{
	//���ڴ�С
	auto size = Director::getInstance()->getVisibleSize();

	//����ת��
	if (m_iBombBonus >= 3)
	{
		//�տ�ʼ��������
		if (m_iFace == FACE_LEFT)
		{
			if (m_pPlayerSprite->getPositionX() <= 101)
			{
				m_pPlayerSprite->setFlipX(false);
			}
			if (m_pPlayerSprite->getPositionX() >= size.width - 101)
			{
				m_pPlayerSprite->setFlipX(true);
			}
		}
		//�տ�ʼ��������
		else if (m_iFace == FACE_RIGHT)
		{
			if (m_pPlayerSprite->getPositionX() <= 101)
			{
				m_pPlayerSprite->setFlipX(false);
			}
			if (m_pPlayerSprite->getPositionX() >= size.width - 101)
			{
				m_pPlayerSprite->setFlipX(true);
			}
		}
	}
}

void CGamePlayer::patricleInit()
{
	//�������
	m_pEmitter = ParticleSystemQuad::create("particles/player.plist");
	m_pEmitter->retain();
	this->addChild(m_pEmitter);

	//�������
	m_pRocket = ParticleSystemQuad::create("particles/rocket.plist");
	m_pRocket->retain();
	this->addChild(m_pRocket);
	//��è����
	m_pSquirrel = ParticleSystemQuad::create("particles/squirrel.plist");
	m_pSquirrel->retain();
	this->addChild(m_pSquirrel);
	//������
	m_pBird = ParticleSystemQuad::create("particles/bird.plist");
	m_pBird->retain();
	this->addChild(m_pBird);
	//������1
	m_pBird1 = ParticleSystemQuad::create("particles/bird.plist");
	m_pBird1->retain();
	this->addChild(m_pBird1);

}

void CGamePlayer::patricleFollow()
{
	//������Ӹ���
	Sprite* pSpri = s_pPlayer->m_pPlayerSprite;
	m_pEmitter->setPosition(Vec2(pSpri->getPositionX(), pSpri->getPositionY() - 10));
	//������Ӹ���
	m_pRocket->setPosition(Vec2(pSpri->getPositionX(), pSpri->getPositionY() - 35));
	m_pRocket->setVisible(false);
	//��è���Ӹ���
	m_pSquirrel->setPosition(Vec2(pSpri->getPositionX(), pSpri->getPositionY() - 35));
	m_pSquirrel->setVisible(false);
	//�����Ӹ���
	m_pBird->setPosition(Vec2(pSpri->getPositionX() + 30, pSpri->getPositionY() - 20));
	m_pBird->setVisible(false);
	m_pBird1->setPosition(Vec2(pSpri->getPositionX() - 30, pSpri->getPositionY() - 20));
	m_pBird1->setVisible(false);
	if (s_pPlayer->m_iBombBonus >= 3)
	{
		m_pRocket->setVisible(true);
		m_pEmitter->setVisible(false);
	}
	else if (s_pPlayer->m_iSquirrelBonus >= 3)
	{
		m_pSquirrel->setVisible(true);
		m_pEmitter->setVisible(false);
	}
	else if (s_pPlayer->m_iBirdBonus >= 3)
	{
		m_pBird->setVisible(true);
		m_pBird1->setVisible(true);
		m_pEmitter->setVisible(false);
	}

	else
	{
		m_pRocket->setVisible(false);
		m_pSquirrel->setVisible(false);
		m_pBird->setVisible(false);
		m_pBird1->setVisible(false);
		m_pEmitter->setVisible(true);
	}
}