#include "GamePause.h"
#include "header.h"
#include "GameMenu.h"

bool CGamePause::init()
{
	if (!Layer::init())
	{
		return false;
	}

	//���ڳߴ�
	auto size = Director::getInstance()->getVisibleSize();

	//����
	m_pBg = Sprite::createWithSpriteFrameName("pause_menu.png");
	m_pBg->setPosition(Vec2(size.width / 2, -130));
	this->addChild(m_pBg);

	auto layer = Layer::create();
	this->addChild(layer, 10);

	//������ť
	m_pContinueBtn = Button::create("pause/continue_button.png", "pause/sel_continue_button.png");
	m_pContinueBtn->setPosition(Vec2(size.width / 2, -100));
	m_pContinueBtn->setTag(1);
	m_pContinueBtn->addTouchEventListener(CC_CALLBACK_2(CGamePause::continueGame, this));
	layer->addChild(m_pContinueBtn);
	//�ز˵���ť
	m_pMenuBtn = Button::create("pause/menu_button.png", "pause/sel_menu_button.png");
	m_pMenuBtn->setPosition(Vec2(size.width / 2, -180));
	m_pMenuBtn->addTouchEventListener(CC_CALLBACK_2(CGamePause::gameMenu, this));
	m_pMenuBtn->setTag(2);
	layer->addChild(m_pMenuBtn);

	//��update
	this->scheduleUpdate();

	return true;
}

void CGamePause::update(float dt)
{
	//���ڳߴ�
	auto size = Director::getInstance()->getVisibleSize();

	//�����ͣ
	if (g_bPause == true)
	{
		if (m_pBg->getPositionY() <= size.height / 2)
		{
			m_pBg->setPositionY(m_pBg->getPositionY() + 30);
			m_pContinueBtn->setPositionY(m_pContinueBtn->getPositionY() + 30);
			m_pMenuBtn->setPositionY(m_pMenuBtn->getPositionY() + 30);
		}
		if (m_pBg->getPositionY() >= size.height / 2)
		{
			Director::getInstance()->pause();
		}
	}
	//���û��ͣ
	if (g_bPause == false)
	{
		if (m_pBg->getPositionY() >= -130)
		{
			m_pBg->setPositionY(m_pBg->getPositionY() - 30);
			m_pContinueBtn->setPositionY(m_pContinueBtn->getPositionY() - 30);
			m_pMenuBtn->setPositionY(m_pMenuBtn->getPositionY() - 30);
		}
	}

}

void CGamePause::continueGame(Ref* pSender, Widget::TouchEventType type)
{
	switch (type)
	{
	case Widget::TouchEventType::BEGAN:
		break;

	case Widget::TouchEventType::MOVED:
		break;

	case Widget::TouchEventType::ENDED:
		g_bPause = false;
		Director::getInstance()->resume();
		break;
	}
}

void CGamePause::gameMenu(Ref* pSender, Widget::TouchEventType type)
{
	switch (type)
	{
	case Widget::TouchEventType::BEGAN:
		
		break;

	case Widget::TouchEventType::MOVED:

		break;

	case Widget::TouchEventType::ENDED:
		g_bPause = false;
		Director::getInstance()->resume();
		Scene* pScene = TransitionFade::create(0.3f, CGameMenu::createMenu(), Color3B(255, 255, 255));
		Director::getInstance()->replaceScene(pScene);
		break;
	}

}
