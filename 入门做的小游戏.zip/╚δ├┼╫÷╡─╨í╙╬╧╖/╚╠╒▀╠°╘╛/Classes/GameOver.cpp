#include "GameOver.h"
#include "GameMenu.h"
#include "GamePlayer.h"
#include "header.h"

int g_iMaxScore = 0;

bool  CGameOver::init()
{
	if (!Layer::init())
	{
		return false;
	}

	//���ڳߴ�
	auto size = Director::getInstance()->getVisibleSize();

	//����
	m_pBg = Sprite::createWithSpriteFrameName("death_menu.png");
	m_pBg->setPosition(Vec2(-300, size.height / 2));
	this->addChild(m_pBg);
	//���¿�ʼ��ť
	m_pRestartBtn = Button::create("gameover/replay_button.png", "pause/sel_replay_button.png");
	m_pRestartBtn->setPosition(Vec2(-300, size.height / 2 - 10));
	m_pRestartBtn->addTouchEventListener(CC_CALLBACK_2(CGameOver::restartGame, this));
	this->addChild(m_pRestartBtn);
	//�ز˵���ť
	m_pMenuBtn = Button::create("gameover/menu_button.png", "pause/sel_menu_button.png");
	m_pMenuBtn->setPosition(Vec2(-300, size.height / 2 - 60));
	m_pMenuBtn->addTouchEventListener(CC_CALLBACK_2(CGameOver::gameMenu, this));
	this->addChild(m_pMenuBtn);

	//��update
	this->scheduleUpdate();

	m_bPause = false;

	return true;
}

void CGameOver::restartGame(Ref* pSender, Widget::TouchEventType type)
{
	switch (type)
	{
	case Widget::TouchEventType::BEGAN:
		break;

	case Widget::TouchEventType::MOVED:
		break;

	case Widget::TouchEventType::ENDED:
		g_bRestart = true;
		Director::getInstance()->resume();
		break;
	}
}

void CGameOver::gameMenu(Ref* pSender, Widget::TouchEventType type)
{

	switch (type)
	{
	case Widget::TouchEventType::BEGAN:
		break;

	case Widget::TouchEventType::MOVED:
		break;

	case Widget::TouchEventType::ENDED:
		Director::getInstance()->resume();
		Scene* pScene = TransitionFade::create(0.3f, CGameMenu::createMenu(), Color3B(255, 255, 255));
		Director::getInstance()->replaceScene(pScene);		
		break;
	}
}

void CGameOver::update(float dt)
{
	//���ڳߴ�
	auto size = Director::getInstance()->getVisibleSize();

	//���Ѫ��
	auto player = CGamePlayer::getPlayer();
	int iHp = player->m_iHp;
	//������С�ڵ���0 
	if (iHp <= 0)
	{
		//������������
		if (m_pBg->getPositionX() <= -300)
		{
			auto act1 = MoveTo::create(0.5f, Vec3(size.width / 2 - 14, size.height / 2, 0));
			m_pBg->runAction(act1);
			auto act2 = MoveTo::create(0.5f, Vec3(size.width / 2 - 14, size.height / 2 - 10, 0));
			m_pRestartBtn->runAction(act2);
			auto act3 = MoveTo::create(0.5f, Vec3(size.width / 2 - 14, size.height / 2 - 60, 0));
			m_pMenuBtn->runAction(act3);
			iHp = 1;
		}
	}
	if (m_pBg->getPositionX() >= size.width / 2 - 14 && m_bPause == false)
	{
		Director::getInstance()->pause();
		m_bPause = true;

		//ʵ�ʵ÷�
		int curScore = g_iScore + 1;

		//�÷�
		char szText[32];
		sprintf(szText, "%d", curScore);
		m_pLblScore = Label::createWithTTF(szText, "fonts/simhei.ttf", 24);
		m_pLblScore->setPosition(Vec2(size.width / 2 - 25, size.height / 2 + 43));
		this->addChild(m_pLblScore);

		//������߷�
		//����÷ִ�����߷�	����÷�
		if (curScore >= g_iMaxScore)
		{
			g_iMaxScore = curScore;
		}

		//��߷�
		char szText1[32];
		sprintf(szText1, "%d", g_iMaxScore);
		m_pLblMaxScore = Label::createWithTTF(szText1, "fonts/simhei.ttf", 20);
		m_pLblMaxScore->setPosition(Vec2(size.width / 2 + 80, size.height / 2 + 35));
		this->addChild(m_pLblMaxScore);
	}
}