#include "GameRoad.h"
#include "GamePlayer.h"
#include "header.h"

float g_fRoadSpeed = 3.0f;

bool CGameRoad::init()
{
	if (!Layer::init())
	{
		return false;
	}

	//���ڳߴ�
	auto size = Director::getInstance()->getVisibleSize();

	//�ܵ�1
	m_pRoad1 = Sprite::createWithSpriteFrameName("TiledMap.png");
	m_pRoad1->setPosition(Vec2(size.width / 2 , size.height / 2));
	m_pRoad1->setContentSize(size);
	this->addChild(m_pRoad1, 0);
	//�ܵ�2
	m_pRoad2 = Sprite::createWithSpriteFrameName("TiledMap.png");
	m_pRoad2->setPosition(Vec2(size.width / 2, size.height + size.height / 2));
	m_pRoad2->setContentSize(size);
	this->addChild(m_pRoad2, 0);

	m_iSpeedBk = 0;

	//����
	this->scheduleUpdate();

	return true;
}

void CGameRoad::update(float dt)
{
	//���ڳߴ�
	auto size = Director::getInstance()->getVisibleSize();
	
	auto pPlayer = CGamePlayer::getPlayer();
	//�����������û��ʼ
	if (pPlayer->m_bBonusAni == false)
	{	
		//�ܵ��ٶ�
		if (g_iScore >= 1000)
		{
			g_fRoadSpeed = 4.0f;
		}
		if (g_iScore > 1000 && g_iScore <= 2000)
		{
			g_fRoadSpeed = 5.0f;
		}
		if (g_iScore > 2000)
		{
			g_fRoadSpeed = 6.0f;
		}
		m_iSpeedBk = g_fRoadSpeed;
	}
	//�������������ʼ
	else
	{
		g_fRoadSpeed = m_iSpeedBk * 2;
	}


	//�ܵ�
	//�ܵ���������
	m_pRoad1->setPositionY(m_pRoad1->getPositionY() - g_fRoadSpeed);
	m_pRoad2->setPositionY(m_pRoad2->getPositionY() - g_fRoadSpeed);
	//���ײ�����
	if (m_pRoad1->getPositionY() <= -size.height / 2)
	{
		m_pRoad1->setPosition(Vec2(size.width / 2, size.height + size.height / 2));
	}
	if (m_pRoad2->getPositionY() <= -size.height / 2)
	{
		m_pRoad2->setPosition(Vec2(size.width / 2, size.height + size.height / 2));
	}
}