#include "GameFore.h"
#include "header.h"

bool CGameFore::init()
{
	if (!Layer::init())
	{
		return false;
	}
	auto size = Director::getInstance()->getVisibleSize();
	//��¥
	m_pFore = Sprite::createWithSpriteFrameName("foreground.png");
	m_pFore->setPosition(Vec2(size.width / 2, size.height / 2));
	m_pFore->setContentSize(size);
	this->addChild(m_pFore, 0);

	m_pExist = true;
	this->scheduleUpdate();

	return true;
}

void CGameFore::update(float dt)
{
	//���ڳߴ�
	auto size = Director::getInstance()->getVisibleSize();

	//��¥
	if (m_pExist)
	{
		//��¥��������
		m_pFore->setPositionY(m_pFore->getPositionY() - 3);
		//������˵�ͼ	�Ƴ���ֹͣ����	���Ƴ���ʱ��
		if (m_pFore->getPositionY() <= -size.height / 2)
		{
			this->removeChild(m_pFore);
			m_pExist = false;
			this->unscheduleUpdate();
		}
	}

}