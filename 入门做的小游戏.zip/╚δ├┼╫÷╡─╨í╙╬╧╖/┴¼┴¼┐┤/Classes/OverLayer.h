#include "cocos2d.h"
#include "extensions/cocos-ext.h"
#include "ui/CocosGUI.h"
using namespace cocos2d::ui;
USING_NS_CC;

class COverLayer : public Layer
{
public:
	virtual bool init();													// ��ʼ����Ϸ������
	CREATE_FUNC(COverLayer);

	void loadingLevel(Ref* pSender, Widget::TouchEventType type);			// �ص�ѡ��
	void restartCallBack(Ref* pSender, Widget::TouchEventType type);		// ���¿�ʼ
};