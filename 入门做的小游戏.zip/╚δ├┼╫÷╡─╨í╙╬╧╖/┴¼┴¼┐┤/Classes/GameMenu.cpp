#include "GameMenu.h"
#include "GameHelp.h"
#include "GameModel.h"
#include "header.h"
#include "SimpleAudioEngine.h"
using namespace CocosDenshion;

// �Ƿ񲥷ű�������Ĭ��Ϊ����
bool g_bPlayBg = true;
// �Ƿ񲥷���ЧĬ��Ϊ����
bool g_bPlayEffect = true;

//���ó��ֶ���ʱ��
const float SETTIME = 0.5f;
//���ó��ֶ�����ת�Ƕ�
const float SETANGLE = 720;;

Scene* CGameMenu::createMenu()
{
	auto scene = Scene::create();
	auto layer = CGameMenu::create();

#ifdef WIN32					 // WIN32ƽ̨
#else
	layer->setPositionX(13.0f);  // ����
#endif

	scene->addChild(layer);
	return scene;
}

bool CGameMenu::init()
{
	if (!Layer::init())
	{
		return false;
	}

	// �˵��ĳ�ʼ��
	menuInit();
	// �˵��������ֳ�ʼ��
	menubgInit();

	return true;
}

void CGameMenu::menuInit()
{
	// ���ڳߴ�
	auto size = Director::getInstance()->getVisibleSize();

	// �˵�����
	auto bg = Sprite::createWithSpriteFrameName("menubg.png");
	bg->setPosition(Vec2(size.width / 2, size.height / 2));
	this->addChild(bg);

	// ���ޱ�־
	auto text = Sprite::createWithSpriteFrameName("logo.png");
	text->setPosition(Vec2(size.width / 2, size.height / 2 + 180));
	this->addChild(text);

	// ����
	auto sign = Sprite::createWithSpriteFrameName("douwa.png");
	sign->setPosition(Vec2(size.width / 2, size.height / 2 - 240));
	// ͼƬ�ĵ���
	sign->setOpacity(0);			// ����ͼƬ͸����Ϊ0
	auto act = FadeIn::create(2.0f);
	sign->runAction(act);
	this->addChild(sign);

	// �˵�
	SpriteFrameCache* pCache = SpriteFrameCache::getInstance();
	// ��ʼ��ť
	auto startBtn = MenuItemImage::create();
	startBtn->setNormalSpriteFrame(pCache->getSpriteFrameByName("play_n.png"));
	startBtn->setSelectedSpriteFrame(pCache->getSpriteFrameByName("play_d.png"));
	startBtn->initWithCallback(CC_CALLBACK_1(CGameMenu::loadingModel, this));
	startBtn->setPosition(Vec2(size.width / 2, size.height / 2 + 15));
	// ������ť
	auto backBoard = MenuItemImage::create();
	backBoard->setNormalSpriteFrame(pCache->getSpriteFrameByName("bticonbg.png"));
	backBoard->setSelectedSpriteFrame(pCache->getSpriteFrameByName("bticonbged.png"));
	backBoard->initWithCallback(CC_CALLBACK_1(CGameMenu::loadingExit, this));
	backBoard->setPosition(Vec2(backBoard->getContentSize().width / 2, backBoard->getContentSize().height / 2));
	auto back = Sprite::createWithSpriteFrameName("backbt.png");
	back->setPosition(backBoard->getPosition());
	this->addChild(back, 2);
	// ������ť
	auto helpBoard = MenuItemImage::create();
	helpBoard->setNormalSpriteFrame(pCache->getSpriteFrameByName("bticonbg.png"));
	helpBoard->setSelectedSpriteFrame(pCache->getSpriteFrameByName("bticonbged.png"));
	helpBoard->initWithCallback(CC_CALLBACK_1(CGameMenu::loadingHelp, this));
	helpBoard->setPosition(Vec2(backBoard->getPositionX(), backBoard->getPositionY() + helpBoard->getContentSize().height));
	auto help = Sprite::createWithSpriteFrameName("aboutbt.png");
	help->setPosition(helpBoard->getPosition());
	this->addChild(help, 2);
	// ���ð�ť
	auto setBoard = MenuItemImage::create();
	setBoard->setNormalSpriteFrame(pCache->getSpriteFrameByName("bticonbg.png"));
	setBoard->setSelectedSpriteFrame(pCache->getSpriteFrameByName("bticonbged.png"));
	setBoard->initWithCallback(CC_CALLBACK_1(CGameMenu::setCallBack, this));
	setBoard->setPosition(Vec2(size.width - setBoard->getContentSize().width / 2, setBoard->getContentSize().height / 2));
	m_pSet = Sprite::createWithSpriteFrameName("setbt.png");
	m_pSet->setPosition(setBoard->getPosition());
	this->addChild(m_pSet, 2);
	// ���а�ť
	m_pRankBoard = MenuItemImage::create();
	m_pRankBoard->setNormalSpriteFrame(pCache->getSpriteFrameByName("bticonbg.png"));
	m_pRankBoard->setSelectedSpriteFrame(pCache->getSpriteFrameByName("bticonbged.png"));
	m_pRankBoard->initWithCallback(CC_CALLBACK_1(CGameMenu::loadingRank, this));
	m_pRankBoard->setPosition(Vec2(setBoard->getPositionX(), setBoard->getPositionY() + m_pRankBoard->getContentSize().height));
	m_pRank = Sprite::createWithSpriteFrameName("scorebt.png");
	m_pRank->setPosition(m_pRankBoard->getPosition());
	this->addChild(m_pRank, 2);
	// �˵�����
	Menu* pMenu = Menu::create();
	pMenu->addChild(startBtn);
	pMenu->addChild(backBoard);
	pMenu->addChild(helpBoard);
	pMenu->addChild(setBoard);
	pMenu->addChild(m_pRankBoard);
	pMenu->setPosition(Vec2::ZERO);
	this->addChild(pMenu, 1);

	// ��Ϸ���ñ�����
	m_pSoundBoard = Sprite::createWithSpriteFrameName("soundbg.png");
	m_pSoundBoard->setPosition(Vec2(m_pSet->getPositionX(), m_pSet->getPositionY() + m_pSoundBoard->getContentSize().height / 2 + m_pSet->getPositionY() / 2));
	m_pSoundBoard->setVisible(false);
	this->addChild(m_pSoundBoard, 0);
	// ��Ϸ����������
	m_pBgBox = CheckBox::create("UI/music.png", "UI/music_no.png");
	m_pBgBox->setPosition(Vec2(m_pSoundBoard->getPositionX(), m_pSoundBoard->getPositionY() / 2 + 130));
	m_pBgBox->addEventListener(CC_CALLBACK_2(CGameMenu::bgCallBack, this));
	m_pBgBox->setVisible(false);
	this->addChild(m_pBgBox, 0);
	// ��Ϸ��Ч����
	m_pEffectBox = CheckBox::create("UI/sound.png", "UI/sound_no.png");
	m_pEffectBox->setPosition(Vec2(m_pSoundBoard->getPositionX(), m_pSoundBoard->getPositionY() - 50));
	m_pEffectBox->addEventListener(CC_CALLBACK_2(CGameMenu::effectCallBack, this));
	m_pEffectBox->setVisible(false);
	this->addChild(m_pEffectBox, 0);
}
void CGameMenu::menubgInit()
{
	// Ԥ���ر�������
	SimpleAudioEngine::getInstance()->preloadBackgroundMusic("sound/bgmusic.mp3");
	// ������Բ��ű�������
	if (g_bPlayBg == true)
	{
		// ���ű�������
		SimpleAudioEngine::getInstance()->playBackgroundMusic("sound/bgmusic.mp3", true);
		// ���ú���Ϊδѡ��
		m_pBgBox->setSelected(false);
	}
	else
	{
		// ֹͣ���ű�������
		SimpleAudioEngine::getInstance()->pauseBackgroundMusic();
		// ���ú���Ϊѡ��
		m_pBgBox->setSelected(true);
	}

	// ������Բ�����Ч
	if (g_bPlayEffect == true)
	{
		// ���ú���Ϊδѡ��
		m_pEffectBox->setSelected(false);
	}
	else
	{
		// ���ú���Ϊѡ��
		m_pEffectBox->setSelected(true);
	}
}

void CGameMenu::loadingModel(Ref* pSender)
{
	// ����
	Scene* pScene = TransitionMoveInR::create(0.5f, CGameModel::createModel());
	Director::getInstance()->replaceScene(pScene);
}
void CGameMenu::loadingExit(Ref* pSender)
{
	Director::getInstance()->end();
}
void CGameMenu::setCallBack(Ref* pSender)
{
	// ���ö���
	auto act = RotateBy::create(SETTIME, SETANGLE);
	m_pSet->runAction(act);
	// �������а�����غ���ʾ
	if (m_pRank->isVisible())	// �����ǰ����ʾ��  �������а�	��ʾ��������
	{
		m_pRank->setVisible(false);
		m_pRankBoard->setVisible(false);
		m_pSoundBoard->setVisible(true);
		m_pBgBox->setVisible(true);
		m_pEffectBox->setVisible(true);
	}
	else						// �����ǰ�����ص�	 ��ʾ���а�	������������
	{
		m_pRank->setVisible(true);
		m_pRankBoard->setVisible(true);
		m_pSoundBoard->setVisible(false);
		m_pBgBox->setVisible(false);
		m_pEffectBox->setVisible(false);
	}
}
void CGameMenu::loadingHelp(Ref* pSender)
{
	Scene* pScene = TransitionMoveInR::create(0.5f,CGameHelp::createHelp());
	Director::getInstance()->replaceScene(pScene);
}
void CGameMenu::loadingRank(Ref* pSender)
{

}

void CGameMenu::bgCallBack(Ref* pSender, CheckBox::EventType type)
{
	switch (type)
	{
	case CheckBox::EventType::SELECTED:
		g_bPlayBg = false;
		// ֹͣ���ű�������
		SimpleAudioEngine::getInstance()->pauseBackgroundMusic();
		break;

	case CheckBox::EventType::UNSELECTED:
		g_bPlayBg = true;
		// ���ű�������
		SimpleAudioEngine::getInstance()->playBackgroundMusic("sound/bgmusic.mp3");
		break;

	default:
		break;
	}
}
void CGameMenu::effectCallBack(Ref* pSender, CheckBox::EventType type)
{
	switch (type)
	{
	case CheckBox::EventType::SELECTED:
		g_bPlayEffect = false;
		break;

	case CheckBox::EventType::UNSELECTED:
		g_bPlayEffect = true;
		break;

	default:
		break;
	}
}