#include "OverLayer.h"
#include "GameMain.h"
#include "GameLevel.h"
#include "header.h"

bool COverLayer::init()
{
	if (!Layer::init())
	{
		return false;
	}

	// ���ڳߴ�
	auto size = Director::getInstance()->getVisibleSize();

	// �װ�
	auto board = Sprite::createWithSpriteFrameName("dialogbg.png");
	board->setPosition(Vec2(size.width / 2, size.height / 2));
	this->addChild(board);

	// ��սʧ��
	auto losetext = Sprite::createWithSpriteFrameName("lose.png");
	losetext->setPosition(Vec2(board->getPosition()));
	this->addChild(losetext);

	// ����
	auto lose = Sprite::createWithSpriteFrameName("lost1.png");
	lose->setPosition(Vec2(board->getPositionX(), board->getPositionY() + board->getContentSize().height / 2));
	this->addChild(lose);
	auto animation = Animation::create();
	auto pCache = SpriteFrameCache::getInstance();
	for (int i = 1; i < 3; i++)
	{
		char szText[16];
		sprintf(szText, "lost%d.png", i);
		animation->addSpriteFrame(pCache->getSpriteFrameByName(szText));
	}
	animation->setDelayPerUnit(0.2f);
	animation->setRestoreOriginalFrame(true);
	auto animate = Animate::create(animation);
	lose->runAction(RepeatForever::create(animate));

	// �ص�ѡ�ذ�ť
	auto backBtn = Button::create("UI/bticonbg.png", "UI/bticonbged.png");
	backBtn->setPosition(Vec2(board->getPositionX() - 60, board->getPositionY() - 120));
	backBtn->addTouchEventListener(CC_CALLBACK_2(COverLayer::loadingLevel, this));						 // �ص�ѡ�ذ�ť�ص�����
	auto back = Sprite::createWithSpriteFrameName("backbt.png");
	back->setPosition(backBtn->getPosition());
	this->addChild(back, 3);
	this->addChild(backBtn, 2);

	// ���¿�ʼ��ť
	auto restartBtn = Button::create("UI/bticonbg.png", "UI/bticonbged.png");
	restartBtn->setPosition(Vec2(board->getPositionX() + 60, board->getPositionY() - 120));
	restartBtn->addTouchEventListener(CC_CALLBACK_2(COverLayer::restartCallBack, this));				 // ���¿�ʼ��ť�ص�����
	auto back1 = Sprite::createWithSpriteFrameName("restartbtn.png");
	back1->setPosition(restartBtn->getPosition());
	this->addChild(back1, 3);
	this->addChild(restartBtn, 2);

	return true;
}

void COverLayer::loadingLevel(Ref* pSender, Widget::TouchEventType type)
{
	switch (type)
	{
	case Widget::TouchEventType::BEGAN:
		break;

	case Widget::TouchEventType::MOVED:
		break;

	case Widget::TouchEventType::ENDED:

		//����
		Scene* pScene = TransitionMoveInL::create(0.5f, CGameLevel::createLevel());
		Director::getInstance()->replaceScene(pScene);

		break;
	}
}

void COverLayer::restartCallBack(Ref* pSender, Widget::TouchEventType type)
{
	switch (type)
	{
	case Widget::TouchEventType::BEGAN:
		break;

	case Widget::TouchEventType::MOVED:
		break;

	case Widget::TouchEventType::ENDED:

		// ����
		Scene* pScene = TransitionMoveInR::create(0.5f, CGameMain::createGame());
		Director::getInstance()->replaceScene(pScene);

		break;
	}
}