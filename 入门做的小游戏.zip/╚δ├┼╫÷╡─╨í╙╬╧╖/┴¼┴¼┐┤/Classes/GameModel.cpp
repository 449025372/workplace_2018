#include "GameModel.h"
#include "GameMenu.h"
#include "GameStar.h"
#include "GameLevel.h"
#include "header.h"

// �ؿ�����Ĭ��Ϊ��
int g_iModel = MODEL_NONE;
// �õ�����������Ĭ��Ϊ��
int g_iTotalStar = 0;
// �õ��ľ���ģʽ��������Ĭ��Ϊ��
int g_iClassicStar = 0;
// �õ������ֶ���ģʽ��������Ĭ��Ϊ��
int g_iTimeStar = 0;

Scene* CGameModel::createModel()
{
	auto scene = Scene::create();
	auto layer = CGameModel::create();
#ifdef WIN32					 // WIN32ƽ̨
#else
	layer->setPositionX(13.0f);  // ����
#endif
	scene->addChild(layer);
	return scene;
}

bool CGameModel::init()
{
	if (!Layer::init())
	{
		return false;
	}

	// ģʽ�����ʼ��
	modelInit();		
	// ����ѡ�س�ʼ��
	listViewInit();		
	// ���ǳ�ʼ��
	starInit();

	return true;
}

void CGameModel::modelInit()
{
	//���ڳߴ�
	auto size = Director::getInstance()->getVisibleSize();

	//����
	auto bg = Sprite::createWithSpriteFrameName("modelbg.png");
	bg->setPosition(Vec2(size.width / 2, size.height / 2));
	this->addChild(bg);
	//С��������
	auto dinosaur = Sprite::createWithSpriteFrameName("konglong1.png");
	dinosaur->setPosition(Vec2(size.width / 2, 110));
	this->addChild(dinosaur);

	//����button
	auto backBoard = Button::create("UI/bticonbg.png","UI/bticonbged.png");
	backBoard->setPosition(Vec2(backBoard->getContentSize().width / 2, backBoard->getContentSize().height / 2));
	backBoard->addTouchEventListener(CC_CALLBACK_2(CGameModel::loadMenu, this));	//���ذ�ť�ص�����
	auto back = Sprite::createWithSpriteFrameName("backbt.png");
	back->setPosition(backBoard->getPosition());
	this->addChild(backBoard, 2);
	this->addChild(back, 2);
}
void CGameModel::listViewInit()
{
	// ���ڳߴ�
	auto size = Director::getInstance()->getVisibleSize();

	// create listview
	auto listview = ListView::create();
	listview->setPosition(Vec2(100, size.height / 2 - 50));
	listview->setContentSize(Size(size.width - 100, 390));			// ����listview�Ĵ�С
	listview->setDirection(ui::ScrollView::Direction::HORIZONTAL);
	listview->setItemsMargin(4);									// ���ü��
	listview->setScrollBarEnabled(false);	
	this->addChild(listview);
	// ����������button
	for (int i = 0; i < 3; i++)
	{
		if (i == 0)				// ����ģʽ
		{
			m_pClassicBtn = Button::create("model/classicmodel.png", "model/classicmodel.png");
			m_pClassicBtn->addTouchEventListener(CC_CALLBACK_2(CGameModel::loadClassicModel, this));
			listview->addChild(m_pClassicBtn);
		}
		else if (i == 1)		// ���ֶ���ģʽ
		{
			m_pTimeBtn = Button::create("model/timemodel.png", "model/timemodel.png");
			m_pTimeBtn->addTouchEventListener(CC_CALLBACK_2(CGameModel::loadTimeModel, this));
			listview->addChild(m_pTimeBtn);
		}
		else                    // ����ģʽ
		{
			m_pEndlessBtn = Button::create("model/endlessmodel.png", "model/endlessmodel.png");
			m_pEndlessBtn->addTouchEventListener(CC_CALLBACK_2(CGameModel::loadEndlessModel, this));
			listview->addChild(m_pEndlessBtn);
		}
	}
}
void CGameModel::starInit()
{
	//��ʾ��������
	auto star = CGameStar::create();
	this->addChild(star, 3);
	g_iTotalStar = g_iClassicStar + g_iTimeStar;
	star->setTotalStar(g_iTotalStar);
}

void CGameModel::loadMenu(Ref* pSender, Widget::TouchEventType type)
{
	switch (type)
	{
	case Widget::TouchEventType::BEGAN:
		break;

	case Widget::TouchEventType::MOVED:
		break;

	case Widget::TouchEventType::ENDED:
		// ����
		Scene* pScene = TransitionMoveInL::create(0.5f, CGameMenu::createMenu());
		Director::getInstance()->replaceScene(pScene);
		break;
	}
}
void CGameModel::loadClassicModel(Ref* pSender, Widget::TouchEventType type)
{
	switch (type)
	{
	case Widget::TouchEventType::BEGAN:
		break;

	case Widget::TouchEventType::MOVED:
		break;

	case Widget::TouchEventType::ENDED:
		// ��ǰ�ؿ�Ϊ����ģʽ
		g_iModel = MODEL_CLASSIC;
		Scene* pScene = TransitionMoveInR::create(0.5f, CGameLevel::createLevel());
		Director::getInstance()->replaceScene(pScene);
		break;
	}
}
void CGameModel::loadTimeModel(Ref* pSender, Widget::TouchEventType type)
{
	switch (type)
	{
	case Widget::TouchEventType::BEGAN:
		break;

	case Widget::TouchEventType::MOVED:
		break;

	case Widget::TouchEventType::ENDED:
		// ��ǰ�ؿ�Ϊ���ֶ���ģʽ
		g_iModel = MODEL_TIME;
		Scene* pScene = TransitionMoveInR::create(0.5f, CGameLevel::createLevel());
		Director::getInstance()->replaceScene(pScene);
		break;
	}
}
void CGameModel::loadEndlessModel(Ref* pSender, Widget::TouchEventType type)
{
	switch (type)
	{
	case Widget::TouchEventType::BEGAN:
		break;

	case Widget::TouchEventType::MOVED:
		break;

	case Widget::TouchEventType::ENDED:
		// ����ģʽ
		g_iModel = MODEL_ENDLESS;
		break;
	}
}


