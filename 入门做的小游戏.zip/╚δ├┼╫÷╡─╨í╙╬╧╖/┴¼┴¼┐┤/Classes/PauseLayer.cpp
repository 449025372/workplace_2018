#include "PauseLayer.h"
#include "GameLevel.h"
#include "GameMain.h"
#include "header.h"
#include "SimpleAudioEngine.h"
using namespace CocosDenshion;

bool CPauseLayer::init()
{
	if (!Layer::init())
	{
		return false;
	}

	// ���ڳߴ�
	auto size = Director::getInstance()->getVisibleSize();

	// �·�UI������
	m_pBoard = Sprite::createWithSpriteFrameName("dialogbg1.png");
	m_pBoard->setPosition(Vec2(size.width / 2, 0));
	this->addChild(m_pBoard);

	// ������Ϸ��ť
	m_pResumeBtn = Button::create("UI/startgamebt.png", "UI/startgamebted.png");
	m_pResumeBtn->setPosition(Vec2(size.width / 2, m_pBoard->getContentSize().height / 2));
	m_pResumeBtn->addTouchEventListener(CC_CALLBACK_2(CPauseLayer::resumeCallBack, this));					// ������ť�ص�����
	this->addChild(m_pResumeBtn, 3);

	// ����ѡ�ذ�ť
	m_pReturnLevelBtn = Button::create("UI/bticonbg.png", "UI/bticonbged.png");
	m_pReturnLevelBtn->setPosition(Vec2(size.width / 2 - m_pBoard->getContentSize().width / 2 + 60, 50));
	m_pReturnLevelBtn->addTouchEventListener(CC_CALLBACK_2(CPauseLayer::levelCallBack, this));				// ���ذ�ť�ص�����
	auto back = Sprite::createWithSpriteFrameName("backbt.png");
	back->setPosition(m_pReturnLevelBtn->getPosition());
	this->addChild(back, 3);
	this->addChild(m_pReturnLevelBtn, 2);

	// ������ť
	m_pAudioBox = CheckBox::create("UI/music_white.png", "UI/music_white_no.png");
	m_pAudioBox->setPosition(Vec2(size.width / 2 + m_pBoard->getContentSize().width / 2 - 60, 50));
	m_pAudioBox->addEventListener(CC_CALLBACK_2(CPauseLayer::audioCallBack, this));							 // ������ť�ص�����
	auto back2 = Sprite::createWithSpriteFrameName("bticonbg.png");
	back2->setPosition(m_pAudioBox->getPosition());
	this->addChild(back2, 2);
	this->addChild(m_pAudioBox, 3);

	// ���¿�ʼ��ť
	m_pRestartBtn = Button::create("UI/bticonbg.png", "UI/bticonbged.png");
	m_pRestartBtn->setPosition(Vec2(size.width / 2, 50));
	m_pRestartBtn->addTouchEventListener(CC_CALLBACK_2(CPauseLayer::restartCallBack, this));				 // ���¿�ʼ��ť�ص�����
	auto back1 = Sprite::createWithSpriteFrameName("restartbtn.png");
	back1->setPosition(m_pRestartBtn->getPosition());
	this->addChild(back1, 3);
	this->addChild(m_pRestartBtn, 2);

	// ��������ű�������
	if (g_bPlayBg == false || g_bPlayEffect == false)
	{
		m_pAudioBox->setSelected(true);
	}
	else
	{
		m_pAudioBox->setSelected(false);
	}

	return true;
}

void CPauseLayer::resumeCallBack(Ref* pSender, Widget::TouchEventType type)
{
	switch (type)
	{
	case Widget::TouchEventType::BEGAN:
		break;

	case Widget::TouchEventType::MOVED:
		break;

	case Widget::TouchEventType::ENDED:
		// �Ƿ���ͣΪ��
		g_bPause = false;
		// ������Ϸ
		Director::getInstance()->resume();
		// ��������
		this->setVisible(false);
		break;
	}
}
void CPauseLayer::levelCallBack(Ref* pSender, Widget::TouchEventType type)
{
	switch (type)
	{
	case Widget::TouchEventType::BEGAN:
		break;

	case Widget::TouchEventType::MOVED:
		break;

	case Widget::TouchEventType::ENDED:
		// �ر�����
		SimpleAudioEngine::getInstance()->stopBackgroundMusic();
		SimpleAudioEngine::getInstance()->stopAllEffects();
		// ������Ϸ
		Director::getInstance()->resume();
		// �Ƿ���ͣΪ��
		g_bPause = false;
		// ����
		Scene* pScene = TransitionMoveInL::create(0.5f, CGameLevel::createLevel());
		Director::getInstance()->replaceScene(pScene);
		break;
	}
}
void CPauseLayer::restartCallBack(Ref* pSender, Widget::TouchEventType type)
{
	switch (type)
	{
	case Widget::TouchEventType::BEGAN:
		break;

	case Widget::TouchEventType::MOVED:
		break;

	case Widget::TouchEventType::ENDED:
		// �Ƿ���ͣΪ��
		g_bPause = false;
		// �ָ���ͣ
		Director::getInstance()->resume();
		// ���´�������Ϸ����
		Scene* pScene = TransitionMoveInR::create(0.5f, CGameMain::createGame());
		Director::getInstance()->replaceScene(pScene);
		break;
	}
}
void CPauseLayer::audioCallBack(Ref* pSender, CheckBox::EventType type)
{
	switch (type)
	{
	case CheckBox::EventType::SELECTED:

		// ��ͣ����������Ч
		SimpleAudioEngine::getInstance()->stopBackgroundMusic();
		g_bPlayBg = false;
		g_bPlayEffect = false;
		break;

	case CheckBox::EventType::UNSELECTED:
		// �ָ�����������Ч
		SimpleAudioEngine::getInstance()->playBackgroundMusic("sound/gamemusic.mp3");
		g_bPlayBg = true;
		g_bPlayEffect = true;
		break;

	default:
		break;
	}
}
