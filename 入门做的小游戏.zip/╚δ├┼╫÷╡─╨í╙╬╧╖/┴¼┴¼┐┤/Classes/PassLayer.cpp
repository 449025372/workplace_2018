#include "PassLayer.h"
#include "GameLevel.h"
#include "GameMain.h"
#include "header.h"

bool CPassLayer::init()
{
	if (!Layer::init())
	{
		return false;
	}

	// ���ڳߴ�
	auto size = Director::getInstance()->getVisibleSize();

	// �װ�
	auto board = Sprite::createWithSpriteFrameName("dialogbg.png");
	board->setPosition(Vec2(size.width / 2, size.height / 2));
	this->addChild(board);

	// ���غ�ʱ
	auto second = Sprite::createWithSpriteFrameName("thislevelsorce.png");
	second->setPosition(Vec2(board->getPositionX() - 50, board->getPositionY() + 50));
	this->addChild(second);

	// ��
	auto time = Sprite::createWithSpriteFrameName("time_s.png");
	time->setPosition(Vec2(second->getPositionX() + 140, second->getPositionY()));
	this->addChild(time);

	// ����
	auto lose = Sprite::createWithSpriteFrameName("win1.png");
	lose->setPosition(Vec2(board->getPositionX(), board->getPositionY() + board->getContentSize().height / 2));
	this->addChild(lose);
	auto animation = Animation::create();
	auto pCache = SpriteFrameCache::getInstance();
	for (int i = 1; i < 3; i++)
	{
		char szText[16];
		sprintf(szText, "win%d.png", i);
		animation->addSpriteFrame(pCache->getSpriteFrameByName(szText));
	}
	animation->setDelayPerUnit(0.2f);
	animation->setRestoreOriginalFrame(true);
	auto animate = Animate::create(animation);
	lose->runAction(RepeatForever::create(animate));

	// �ص�ѡ�ذ�ť
	auto backBtn = Button::create("UI/bticonbg.png", "UI/bticonbged.png");
	backBtn->setPosition(Vec2(board->getPositionX() - 120, board->getPositionY() - 120));
	backBtn->addTouchEventListener(CC_CALLBACK_2(CPassLayer::loadingLevel, this));						 // �ص�ѡ�ذ�ť�ص�����
	auto back = Sprite::createWithSpriteFrameName("backbt.png");
	back->setPosition(backBtn->getPosition());
	this->addChild(back, 3);
	this->addChild(backBtn, 2);

	// ���¿�ʼ��ť
	auto restartBtn = Button::create("UI/bticonbg.png", "UI/bticonbged.png");
	restartBtn->setPosition(Vec2(board->getPositionX(), board->getPositionY() - 120));
	restartBtn->addTouchEventListener(CC_CALLBACK_2(CPassLayer::restartCallBack, this));				 // ���¿�ʼ��ť�ص�����
	auto back1 = Sprite::createWithSpriteFrameName("restartbtn.png");
	back1->setPosition(restartBtn->getPosition());
	this->addChild(back1, 3);
	this->addChild(restartBtn, 2);

	// ��һ�ذ�ť
	auto nextBtn = Button::create("UI/bticonbg.png", "UI/bticonbged.png");
	nextBtn->setPosition(Vec2(board->getPositionX() + 120, board->getPositionY() - 120));
	nextBtn->addTouchEventListener(CC_CALLBACK_2(CPassLayer::loadNextLevel, this));						 // �ص�ѡ�ذ�ť�ص�����
	auto next = Sprite::createWithSpriteFrameName("nextbtn.png");
	next->setPosition(nextBtn->getPosition());
	this->addChild(next, 3);
	this->addChild(nextBtn, 2);


	return true;
}

void CPassLayer::loadingLevel(Ref* pSender, Widget::TouchEventType type)
{
	switch (type)
	{
	case Widget::TouchEventType::BEGAN:
		break;

	case Widget::TouchEventType::MOVED:
		break;

	case Widget::TouchEventType::ENDED:

		//����
		Scene* pScene = TransitionMoveInL::create(0.5f, CGameLevel::createLevel());
		Director::getInstance()->replaceScene(pScene);

		break;
	}
}
void CPassLayer::restartCallBack(Ref* pSender, Widget::TouchEventType type)
{
	switch (type)
	{
	case Widget::TouchEventType::BEGAN:
		break;

	case Widget::TouchEventType::MOVED:
		break;

	case Widget::TouchEventType::ENDED:

		// ����
		Scene* pScene = TransitionMoveInR::create(0.5f, CGameMain::createGame());
		Director::getInstance()->replaceScene(pScene);

		break;
	}

}

void CPassLayer::loadNextLevel(Ref* pSender, Widget::TouchEventType type)
{
	switch (type)
	{
	case Widget::TouchEventType::BEGAN:
		break;

	case Widget::TouchEventType::MOVED:
		break;

	case Widget::TouchEventType::ENDED:
		
		// ��ǰ�ؿ�
		int iCurLevel = g_iLevel;
		// �ؿ�������һ��
		if (g_iLevel == CLASSIC_ONE)
		{
			g_iLevel = CLASSIC_TWO;
		}
		else if (g_iLevel == CLASSIC_TWO)
		{
			g_iLevel = CLASSIC_THREE;
		}
		else if (g_iLevel == CLASSIC_THREE)
		{
			g_iLevel = CLASSIC_THREE;
		}
		else if (g_iLevel == TIME_ONE)
		{
			g_iLevel = TIME_TWO;
		}
		else if (g_iLevel == TIME_TWO)
		{
			g_iLevel = TIME_THREE;
		}
		else if (g_iLevel == TIME_THREE)
		{
			g_iLevel = TIME_THREE;
		}
		
		// ����
		Scene* pScene = TransitionMoveInR::create(0.5f, CGameMain::createGame());
		Director::getInstance()->replaceScene(pScene);

		break;
	}
}