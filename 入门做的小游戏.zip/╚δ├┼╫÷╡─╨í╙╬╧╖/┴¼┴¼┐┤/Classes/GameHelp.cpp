#include "GameHelp.h"
#include "GameMenu.h"
#include "header.h"
#include "SimpleAudioEngine.h"
using namespace CocosDenshion;

//���ó��ֶ���ʱ��
const float SETTIME = 0.5f;
//���ó��ֶ�����ת�Ƕ�
const float SETANGLE = 720;

Scene* CGameHelp::createHelp()
{
	auto scene = Scene::create();
	auto layer = CGameHelp::create();
#ifdef WIN32					 // WIN32ƽ̨
#else
	layer->setPositionX(13.0f);  // ����
#endif
	scene->addChild(layer);
	return scene;
}
bool CGameHelp::init()
{
	if (!Layer::init())
	{
		return false;
	}

	// ������ʼ��
	helpInit();

	// �˵���ʼ��
	menuInit();

	return true;
}

void CGameHelp::helpInit()
{
	// ���ڳߴ�
	auto size = Director::getInstance()->getVisibleSize();

	// ��������
	auto bg = Sprite::createWithSpriteFrameName("helpbg.png");
	bg->setPosition(Vec2(size.width / 2, size.height / 2));
	this->addChild(bg);

	// �������ݿ�
	auto contentbg = Sprite::createWithSpriteFrameName("contentbg.png");
	contentbg->setPosition(Vec2(size.width / 2, size.height / 2));
	this->addChild(contentbg);

	// ��������
	auto content = Sprite::createWithSpriteFrameName("helpcontent.png");
	content->setPosition(Vec2(contentbg->getPosition()));
	this->addChild(content);

	// ������
	auto helpboard = Sprite::createWithSpriteFrameName("helpboard.png");
	helpboard->setPosition(Vec2(helpboard->getContentSize().width / 2, size.height - helpboard->getContentSize().height / 2));
	this->addChild(helpboard);

	// ������
	auto helptext = Sprite::createWithSpriteFrameName("helptext.png");
	helptext->setPosition(Vec2(helpboard->getPosition()));
	this->addChild(helptext);
}
void CGameHelp::menuInit()
{
	// ���ڳߴ�
	auto size = Director::getInstance()->getVisibleSize();


	// �˵�
	SpriteFrameCache* pCache = SpriteFrameCache::getInstance();

	// ���ذ�ť
	auto backBoard = MenuItemImage::create();
	backBoard->setNormalSpriteFrame(pCache->getSpriteFrameByName("bticonbg.png"));
	backBoard->setSelectedSpriteFrame(pCache->getSpriteFrameByName("bticonbged.png"));
	backBoard->initWithCallback(CC_CALLBACK_1(CGameHelp::loadingMenu, this));
	backBoard->setPosition(Vec2(backBoard->getContentSize().width / 2, backBoard->getContentSize().height / 2));
	auto back = Sprite::createWithSpriteFrameName("backbt.png");
	back->setPosition(backBoard->getPosition());
	this->addChild(back, 2);

	// ���ð�ť
	auto setBoard = MenuItemImage::create();
	setBoard->setNormalSpriteFrame(pCache->getSpriteFrameByName("bticonbg.png"));
	setBoard->setSelectedSpriteFrame(pCache->getSpriteFrameByName("bticonbged.png"));
	setBoard->initWithCallback(CC_CALLBACK_1(CGameHelp::setCallBack, this));
	setBoard->setPosition(Vec2(size.width - setBoard->getContentSize().width / 2, setBoard->getContentSize().height / 2));
	m_pSet = Sprite::createWithSpriteFrameName("setbt.png");
	m_pSet->setPosition(setBoard->getPosition());
	this->addChild(m_pSet, 2);

	// �˵�����
	Menu* pMenu = Menu::create();
	pMenu->addChild(backBoard);
	pMenu->addChild(setBoard);
	pMenu->setPosition(Vec2::ZERO);
	this->addChild(pMenu, 1);

	// ��Ϸ���ñ�����
	m_pSoundBoard = Sprite::createWithSpriteFrameName("soundbg.png");
	m_pSoundBoard->setPosition(Vec2(m_pSet->getPositionX(), m_pSet->getPositionY() + m_pSoundBoard->getContentSize().height / 2 + m_pSet->getPositionY() / 2));
	m_pSoundBoard->setVisible(false);
	this->addChild(m_pSoundBoard, 0);
	// ��Ϸ����������
	m_pBgBox = CheckBox::create("UI/music.png", "UI/music_no.png");
	m_pBgBox->setPosition(Vec2(m_pSoundBoard->getPositionX(), m_pSoundBoard->getPositionY() / 2 + 130));
	m_pBgBox->addEventListener(CC_CALLBACK_2(CGameHelp::bgCallBack, this));
	m_pBgBox->setVisible(false);
	this->addChild(m_pBgBox, 0);
	// ��Ϸ��Ч����
	m_pEffectBox = CheckBox::create("UI/sound.png", "UI/sound_no.png");
	m_pEffectBox->setPosition(Vec2(m_pSoundBoard->getPositionX(), m_pSoundBoard->getPositionY() - 50));
	m_pEffectBox->addEventListener(CC_CALLBACK_2(CGameHelp::effectCallBack, this));
	m_pEffectBox->setVisible(false);
	this->addChild(m_pEffectBox, 0);

	// ������Բ��ű�������
	if (g_bPlayBg == true)
	{
		// ���ú���Ϊδѡ��
		m_pBgBox->setSelected(false);
	}
	else
	{
		// ֹͣ���ű�������
		SimpleAudioEngine::getInstance()->pauseBackgroundMusic();
		// ���ú���Ϊѡ��
		m_pBgBox->setSelected(true);
	}

	// ������Բ�����Ч
	if (g_bPlayEffect == true)
	{
		// ���ú���Ϊδѡ��
		m_pEffectBox->setSelected(false);
		// ������Ч
		SimpleAudioEngine::getInstance()->resumeAllEffects();
	}
	else
	{
		// ֹͣ������Ч
		SimpleAudioEngine::getInstance()->pauseAllEffects();
		// ���ú���Ϊѡ��
		m_pEffectBox->setSelected(true);
	}
}

void CGameHelp::loadingMenu(Ref* pSender)
{
	Scene* pScene = TransitionMoveInL::create(0.5f, CGameMenu::createMenu());
	Director::getInstance()->replaceScene(pScene);
}

void CGameHelp::setCallBack(Ref* pSender)
{
	// ���ö���
	auto act = RotateBy::create(SETTIME, SETANGLE);
	m_pSet->runAction(act);
	// �����������õ���ʾ������
	if (!m_pSoundBoard->isVisible())	// �������  ��Ϊ��ʾ
	{
		m_pSoundBoard->setVisible(true);
		m_pBgBox->setVisible(true);
		m_pEffectBox->setVisible(true);
	}
	else								// �����ʾ  ��Ϊ����
	{ 
		m_pSoundBoard->setVisible(false);
		m_pBgBox->setVisible(false);
		m_pEffectBox->setVisible(false);
	}
}
void CGameHelp::bgCallBack(Ref* pSender, CheckBox::EventType type)
{
	switch (type)
	{
	case CheckBox::EventType::SELECTED:
		g_bPlayBg = false;
		// ֹͣ���ű�������
		SimpleAudioEngine::getInstance()->pauseBackgroundMusic();
		break;

	case CheckBox::EventType::UNSELECTED:
		g_bPlayBg = true;
		// �ָ����ű�������
		SimpleAudioEngine::getInstance()->resumeBackgroundMusic();
		break;

	default:
		break;
	}
}
void CGameHelp::effectCallBack(Ref* pSender, CheckBox::EventType type)
{
	switch (type)
	{
	case CheckBox::EventType::SELECTED:
		g_bPlayEffect = false;
		// ֹͣ������Ч
		SimpleAudioEngine::getInstance()->pauseAllEffects();
		break;

	case CheckBox::EventType::UNSELECTED:
		g_bPlayEffect = true;
		// �ָ�������Ч
		SimpleAudioEngine::getInstance()->resumeAllEffects();
		break;

	default:
		break;
	}
}