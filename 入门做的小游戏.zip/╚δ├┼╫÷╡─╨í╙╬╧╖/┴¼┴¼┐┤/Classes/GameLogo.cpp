#include "GameLogo.h"
#include "GameLoad.h"

Scene* CGameLogo::createLogo()
{
#ifdef WIN32					  // WIN32ƽ̨
	srand(unsigned int(time(0))); // �������
#else
	{
		std::srand(0);				  // �������
	}
#endif

	return CGameLogo::create();
}

bool CGameLogo::init()
{
	if (!Scene::init())
	{
		return false;
	}

	// ���ڳߴ�
	auto size = Director::getInstance()->getVisibleSize();

	// LOGO����
	auto bg = Sprite::create("logo/logobg.png");
	bg->setPosition(Vec2(size.width / 2, size.height / 2));
	this->addChild(bg);

	// LOGO
	auto logo = Sprite::create("logo/logo.png");
	logo->setPosition(Vec2(size.width / 2, size.height / 2));
	this->addChild(logo);

	// ת�����ؽ��涨ʱ����ʱ��
	this->schedule(schedule_selector(CGameLogo::loadingLoad),1.0f);

	return true;
}

void CGameLogo::loadingLoad(float dt)
{
	// ����
	Director::getInstance()->replaceScene(CGameLoad::createLoad());
}