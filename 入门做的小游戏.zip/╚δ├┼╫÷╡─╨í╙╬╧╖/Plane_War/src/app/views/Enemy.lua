local BulletMgr = require("src.app.views.BulletMgr")

-- 获得窗口尺寸
local size = cc.Director:getInstance():getWinSize()

-- 玩家类
local Enemy = class("Enemy",function(name)
	return cc.Sprite:create(name)
end)

	function Enemy:ctor()
		-- 敌人生命
		self.hp = 2
		-- 敌人最大生命
		self.maxHp = self.hp

		-- 敌人子弹类型
		self.bulletType = 3

		-- 敌人精灵
		local x = math.random(100,600)
		local y = math.random(1000,1600)
		self:setPosition(cc.p(x,y))

		if(type == 1) then
			self.score = 10
		elseif(type == 2) then
			self.score = 100
		elseif(type == 3) then
			self.score = 1000
		else
			self.score = 2000
		end

		-- 敌人移动
		local action = cc.MoveBy:create(8,cc.p(0,-2000))
		self:runAction(action)

		-- 血条
		-- local to1 = cc.ProgressTo:create(2, 100)
    	self.bloodbar = cc.ProgressTimer:create(cc.Sprite:create("UI/enemy_bloodbar.png"))
    	self.bloodbar:setType(cc.PROGRESS_TIMER_TYPE_BAR)
   		 -- Setup for a bar starting from the left since the midpoint is 0 for the x
    	self.bloodbar:setMidpoint(cc.p(0, 1)) -- 最右边是起点
    	-- Setup for a horizontal bar since the bar change rate is 0 for y meaning no vertical change
    	self.bloodbar:setBarChangeRate(cc.p(1, 0)) -- 进度条是横方向运动
    	self.bloodbar:setPercentage(100)
   		 -- self.left:runAction(cc.RepeatForever:create(to1))
		self:addChild(self.bloodbar) 	-- 血条挂载在玩家精灵上
		self.bloodbar:setPosition(cc.p(self:getContentSize().width/2,-30))	-- 坐标要考虑到相对坐标
	end

	-- 设置敌人子弹类型
	function Enemy:setEnemyBulletType(type)
		self.bulletType = type
	end

	-- 血条扣血
	function Enemy:reduceBloodBar()
		self.hp = self.hp - 1
		local curPercent = self.hp/self.maxHp * 100
		self.bloodbar:setPercentage(curPercent)
	end
return Enemy