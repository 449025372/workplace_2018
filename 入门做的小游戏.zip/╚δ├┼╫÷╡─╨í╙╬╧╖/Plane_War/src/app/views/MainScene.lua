local menu = (require "src.app.views.GameMenu")

local MainScene = class("MainScene", cc.load("mvc").ViewBase)

-- 获取窗口尺寸
local size = cc.Director:getInstance():getWinSize()

function MainScene:onCreate()
	-- LOGO背景
	local sprite = cc.Sprite:create("Bg/caodi.jpg")
	sprite:setPosition(cc.p(size.width/2,size.height/2))
	self:addChild(sprite,0)

	-- LOGO文本
	local label = cc.Label:createWithTTF("_PlaneWar_","Font/arial.ttf",64)
	label:setPosition(cc.p(size.width/2,size.height - 200))
	self:addChild(label,1)

	-- 创建一个函数用来翻屏
	local function loadMenu()
		local scene = createMenu()
		scene = cc.TransitionMoveInT:create(1.0,scene)
		if scene then
			cc.Director:getInstance():replaceScene(scene)
		end
	end
	-- 延时翻屏
	local action = cc.Sequence:create(cc.DelayTime:create(2.0),cc.CallFunc:create(loadMenu))
	self:runAction(action)
end

return MainScene
