
-- 获得窗口尺寸
local size = cc.Director:getInstance():getWinSize()

-- 子弹类
local Bullet = class("Bullet",function()
	return cc.Sprite:create("Bullet/bullet1.png")
end)

	-- 构造函数
	function Bullet:ctor(curType,x,y,posX,posY)
		-- 子弹类型
		self.type = curType
		self.posX = posX
		self.posY = posY

		-- 如果是玩家正常子弹
		if(self.type == 1) then
			-- 子弹移动
			local action = cc.MoveBy:create(4.0,cc.p(posX,posY))
			self:setPosition(cc.p(x,y))
			self:runAction(action)
		-- 如果是玩家跟踪子弹
		elseif(self.type == 2) then
			-- 子弹移动
			local action = cc.MoveBy:create(4.0,cc.p(posX,posY))
			self:setPosition(cc.p(x,y))
			self:runAction(action)
		
		-- 如果是敌机子弹
		elseif(self.type == 3) then
			-- 子弹移动
			local action = cc.MoveBy:create(4.0,cc.p(posX,posY))
			self:setPosition(cc.p(x,y))
			self:runAction(action)
			-- 翻转
			self:setFlippedY(true)		
		end

		local function update(dt)
			-- 如果子弹是追踪子弹
			if(self.type == 2) then
				-- 如果还没到目标位置
				if(self:getPositionX() < posX) then
					self:setPositionX(self:getPositionX() + 10)
				end
				if(self:getPositionX() > posX) then
					self:setPositionX(self:getPositionX() - 10)
				end
				if(math.abs(self:getPositionX() - posX) <= 10) then
					self:setPositionY(self:getPositionY() + 5)
				end
			end
		end

		self:scheduleUpdateWithPriorityLua(update,0)
	end
return Bullet