local mainscene = (require "src.app.views.GameMain")

-- 获取窗口尺寸
local size = cc.Director:getInstance():getWinSize()
-- 载入plist
local pCache = cc.SpriteFrameCache:getInstance():addSpriteFrames("UI/UI.plist")

-- 菜单背景层
local function createMenuBgLayer()

	local layer = cc.Layer:create()

	-- 背景图片
	local bgSprite = cc.Sprite:create("Bg/caodi.jpg")
	bgSprite:setPosition(cc.p(size.width/2,size.height/2))
	layer:addChild(bgSprite,0)

	return layer 

end 
-- 开始回调函数
local function restartCallBack()

		--进入游戏场景
		local scene = createGame()
		scene = cc.TransitionMoveInT:create(1.0,scene)
		if scene then
			cc.Director:getInstance():replaceScene(scene)
		end

end
-- 菜单UI层
local function createUiLayer()

	local layer = cc.Layer:create()

	-- 开始回调函数
	local function startCallBack()

		--进入游戏场景
		local scene = createGame()
		scene = cc.TransitionMoveInT:create(1.0,scene)
		if scene then
			cc.Director:getInstance():replaceScene(scene)
		end

	end

	-- 退出回调函数
	local function exitCallBack()

		cc.Director:getInstance():endToLua()

	end

	-- 创建开始菜单按钮
	local menuStart = cc.MenuItemImage:create()
	menuStart:registerScriptTapHandler(startCallBack)								-- 回调函数
	menuStart:setNormalSpriteFrame(pCache:getSpriteFrame("OK_button.png"))			-- 设置按钮正常图片
	menuStart:setSelectedSpriteFrame(pCache:getSpriteFrame("OK_button_down.png"))	-- 设置按钮按下图片
	menuStart:setPosition(cc.p(size.width/2,size.height/2+100))						-- 设置按钮位置
	-- 创建退出菜单按钮
	local menuExit = cc.MenuItemImage:create()										
	menuExit:registerScriptTapHandler(exitCallBack)									-- 回调函数
	menuExit:setNormalSpriteFrame(pCache:getSpriteFrame("back.png"))				-- 设置按钮正常图片
	menuExit:setSelectedSpriteFrame(pCache:getSpriteFrame("back_d.png"))				-- 设置按钮按下图片
	menuExit:setPosition(cc.p(size.width/2,size.height/2-100))						-- 设置按钮位置

	-- 创建菜单
	local pMenu = cc.Menu:create()
	pMenu:addChild(menuStart)
	pMenu:addChild(menuExit)
	pMenu:setPosition(0,0)	-- 设置菜单位置 菜单锚点在左下角
	layer:addChild(pMenu)	

	return layer

end

-- 创建场景
function cc.exports.createMenu()

	local menuScene = cc.Scene:create()

	-- 菜单背景层
	local BgLayer = createMenuBgLayer()
	menuScene:addChild(BgLayer,0)

	-- 菜单UI层
	local uiLayer = createUiLayer()
	menuScene:addChild(uiLayer,1)

	return menuScene
end

