local Player = require("src.app.views.Player")
local Enemy = require("src.app.views.Enemy")
local Bullet = require("src.app.views.Bullet")

-- 加载飞机plist
cc.SpriteFrameCache:getInstance():addSpriteFrames("Plane/Plane.plist")
-- 加载爆炸plist
cc.SpriteFrameCache:getInstance():addSpriteFrames("Bomb/Bomb.plist")

-- 获得窗口尺寸
local size = cc.Director:getInstance():getWinSize()

 -- 随机种子
 math.randomseed(os.time())
 math.random()

-- 创建游戏背景层
local function createBgLayer()

	local layer = cc.Layer:create()

	-- 背景图片
	local bg = cc.Sprite:create("Bg/caodi.jpg")
	bg:setPosition(size.width/2,size.height/2)
	layer:addChild(bg,0)
	local bg1 = cc.Sprite:create("Bg/caodi.jpg")
	bg1:setPosition(size.width/2,size.height + size.height/2)
	layer:addChild(bg1,0)

	-- 向下滚动
	local action = cc.MoveBy:create(2,cc.p(0,-size.height))
	bg:runAction(cc.RepeatForever:create(action))
	local action1 = cc.MoveBy:create(2,cc.p(0,-size.height))
	bg1:runAction(cc.RepeatForever:create(action1))

	-- 如果滚到了最下方 重置到最上方
	local function isTouchLow(dt)
		if bg:getPositionY() <= -size.height/2 then
			bg:setPosition(size.width/2,size.height + size.height/2)
		end

		if bg1:getPositionY() <= -size.height/2 then
			bg1:setPosition(size.width/2,size.height + size.height/2)
		end
	end

	-- 注册节点事件
    local schedulerEntry = nil
    local scheduler = cc.Director:getInstance():getScheduler()
    local function onNodeEvent(event)
        if event == "enter" then
            schedulerEntry = scheduler:scheduleScriptFunc(isTouchLow, 0, false)
        elseif event == "exit" then
            scheduler:unscheduleScriptEntry(schedulerEntry)
        end
    end
    layer:registerScriptHandler(onNodeEvent)

	return layer

end

-- 创建主游戏场景
function cc.exports.createGame()
	print("==================场景====================")
	local scene = cc.Scene:create()

	-- 背景层
	local bgLayer = createBgLayer()
	scene:addChild(bgLayer,0)

	-- 子弹组
	local bulletList = {}
	-- 敌机组
	local enemyList = {}

	-- 玩家对象
	local player = Player.new()
	scene:addChild(player,50)

	-- 玩家武器切换Button
	local weaponBtn = ccui.Button:create("UI/item_btn.png","UI/item_btn_d.png")
	weaponBtn:setPosition(cc.p(size.width - 100,150))
	scene:addChild(weaponBtn,20)
	-- 武器切换Button回调
	local function onItemTouch()
		print("**************武器变换*****************")
		if(player.bulletType == 1) then
			player.bulletType = 2
		else
			player.bulletType = 1
		end
    end
    weaponBtn:addClickEventListener(onItemTouch)	

	-- 定时创建敌机
	local function createEnemy()
		local type = math.random(1,4)	-- 随机敌机种类
		local name = string.format("Plane/enemy%d.png",type)
		local enemy = Enemy.new(name)
		scene:addChild(enemy)
		table.insert(enemyList,enemy)	-- 加入敌机组
	end

	-- 定时创建玩家子弹
	local function createPlayerBullet()
		-- 如果是玩家正常子弹
		if(player.bulletType == 1) then
			local bullet = Bullet.new(player.bulletType,player:getPositionX(),player:getPositionY() + 50,0,2000)
			scene:addChild(bullet)
			table.insert(bulletList,bullet)				-- 加入子弹组
			print("************玩家发射正常子弹*************")
		-- 如果是玩家跟踪子弹
		elseif(player.bulletType == 2) then
			for i,v in ipairs(enemyList) do
				if(v:getPositionY() > player:getPositionY() + 100) then
					local bullet = Bullet.new(player.bulletType,player:getPositionX(),player:getPositionY() + 50,v:getPositionX(),v:getPositionY())
					scene:addChild(bullet)
					table.insert(bulletList,bullet)		-- 加入子弹组
					print("************玩家发射跟踪子弹*************")
					break
				end
			end		
		end
	end
	-- 定时创建敌机子弹
	local function createEnemyBullet()
		for i,v in ipairs(enemyList) do
			local bullet = Bullet.new(3,v:getPositionX(),v:getPositionY() - 50,0,-2000)
			scene:addChild(bullet)
			table.insert(bulletList,bullet)				-- 加入子弹组
			print("************敌机发射子弹*************")
		end
	end

	-- 注册节点事件
    local schedulerEntry = nil
    local scheduler = cc.Director:getInstance():getScheduler()
    local function onNodeEvent(event)
        if event == "enter" then
            schedulerEntry = scheduler:scheduleScriptFunc(createEnemy, 1.5, false)			-- 创建敌机
            schedulerEntry = scheduler:scheduleScriptFunc(createPlayerBullet, 0.8, false)	-- 创建玩家子弹
            schedulerEntry = scheduler:scheduleScriptFunc(createEnemyBullet, 1.0, false)	-- 创建敌机子弹
        elseif event == "exit" then
            scheduler:unscheduleScriptEntry(schedulerEntry)
        end
    end
    scene:registerScriptHandler(onNodeEvent)

	-- 暂停Button
	local pauseBtn = ccui.Button:create("UI/hold.png","UI/hold_d.png")
	pauseBtn:setPosition(cc.p(size.width - 50,50))
	scene:addChild(pauseBtn,20)
	-- 暂停Button回调
	local function onPauseTouch()
    	print("==================Pause===================")

    end
    pauseBtn:addClickEventListener(onPauseTouch)

	-- 触摸监听回调
	local function onTouchBegan(touch, event)
    	return true
	end

	local function onTouchMoved(touch, event)
        -- 获得触摸位置
        local location = touch:getLocation()
        -- 获得玩家包围盒
        local playerBox = player:getBoundingBox()
        -- 如果点到了玩家飞机
        if(cc.rectContainsPoint(playerBox,location)) then
            player:setPosition(cc.p(location.x,location.y))
        end
        -- 坐标还原
        if(player:getPositionX() < player:getContentSize().width/2) then
        	player:setPosition(cc.p(player:getContentSize().width/2,player:getPositionY()))
        end
        if(player:getPositionX() > size.width - player:getContentSize().width/2) then
        	player:setPosition(cc.p(size.width - player:getContentSize().width/2,player:getPositionY()))
        end
        if(player:getPositionY() < player:getContentSize().height/2) then
        	player:setPosition(cc.p(player:getPositionX(),player:getContentSize().height/2))
        end
        if(player:getPositionY() > size.height - player:getContentSize().height/2) then
        	player:setPosition(cc.p(player:getPositionX(),size.height - player:getContentSize().height/2))
        end
	end

	local function onTouchEnded(touch, event)

	end

	-- 注册触摸监听
	local listener = cc.EventListenerTouchOneByOne:create()
	listener:registerScriptHandler(onTouchBegan,cc.Handler.EVENT_TOUCH_BEGAN )
	listener:registerScriptHandler(onTouchMoved,cc.Handler.EVENT_TOUCH_MOVED )
	listener:registerScriptHandler(onTouchEnded,cc.Handler.EVENT_TOUCH_ENDED )
	local eventDispatcher = scene:getEventDispatcher()
	eventDispatcher:addEventListenerWithSceneGraphPriority(listener, scene)

	-- 爆炸动画
	local function BombAnimation(x,y)
		-- 获得精灵框帧
		local pCache = cc.SpriteFrameCache:getInstance()
		-- 播放爆炸动画
        local animation =cc.Animation:create()    
        for i = 1,3 do  
            local name =string.format("bomb%d.png",i)
            local spriteFrame = pCache:getSpriteFrame(name)               
             animation:addSpriteFrame(spriteFrame)
         end
        animation:setDelayPerUnit(0.1)          	-- 设置两个帧播放时间   
        animation:setRestoreOriginalFrame(false)    -- 动画执行后不还原初始状态

        local animate = cc.Animate:create(animation)
        local sprite = cc.Sprite:create()
        sprite:setPosition(cc.p(x,y))
        scene:addChild(sprite,60)
        sprite:runAction(animate)

        -- 移除动画
        local function removeAni()
        	scene:removeChild(sprite)
        end

        local seq = cc.Sequence:create(cc.DelayTime:create(0.3),cc.CallFunc:create(removeAni))
        scene:runAction(seq)
        print("=============爆炸动画被移除==============")
	end

	-- update函数
	local function update(dt)
		-- 如果玩家没血了 游戏结束
		if(player.hp <= 0) then
			print("**************玩家没血了*************")
			-- 玩家隐藏
			player:setVisible(false)
			-- 清空敌人和子弹
			for i,v in ipairs(enemyList) do
				local temp = v
				table.remove(enemyList,i)
				temp:removeFromParent()
			end
			for i,v in ipairs(bulletList) do
				local temp = v
				table.remove(bulletList,i)
				temp:removeFromParent()
			end
			-- 创建一个重新开始游戏的Button
			local restartBtn = ccui.Button:create("UI/player_bloodbar.png","UI/enemy_bloodbar.png")
			restartBtn:setPosition(cc.p(size.width/2,size.height/2))
			scene:addChild(restartBtn,20)

			-- 重新开始Button回调
			local function onItemTouch()
				print("**************重新开始*****************")
				-- 玩家显示
				player:setVisible(true)
				scene:scheduleUpdateWithPriorityLua(update,0)
				-- 重置玩家
				player.hp = 3
				player:setPosition(cc.p(size.width/2,100))	
				player.bloodbar:setPercentage(100)
				cc.Director:getInstance():resume()	
				-- 移除Button
				restartBtn:removeFromParent()
    		end
    		restartBtn:addClickEventListener(onItemTouch)	

    		-- 停止更新
    		scene:unscheduleUpdate()
			-- 清空敌人和子弹
			for i,v in ipairs(enemyList) do
				local temp = v
				table.remove(enemyList,i)
				temp:removeFromParent()
			end
			for i,v in ipairs(bulletList) do
				local temp = v
				table.remove(bulletList,i)
				temp:removeFromParent()
			end

			local function pauseCallBack()
				-- 暂停
    			cc.Director:getInstance():pause()
			end
			local seq = cc.Sequence:create(BombAnimation(player:getPositionX(),player:getPositionY()),cc.DelayTime:create(0.3),cc.CallFunc:create(pauseCallBack))
			scene:runAction(seq)
    	end

		-- 临时表 用来移除对象
		local tempBullet = {}
		local tempEnemy = {}

		-- 遍历子弹列表
		for i,v in ipairs(bulletList) do
			-- 如果子弹出界或到达目标位置
			if(v:getPositionY() < 0 or v:getPositionY() > size.height or v:getPositionX() == v.posX or v:getPositionY() == v.posY) then 
				-- 加入临时表
				table.insert(tempBullet,i)
			end

			-- 如果敌机子弹打到玩家了
			if( v.type == 3 
				and math.abs(v:getPositionX() - player:getPositionX()) <= player:getContentSize().width/2
				and math.abs(v:getPositionY() - player:getPositionY()) <= 10) then
				-- 子弹加入临时表
				table.insert(tempBullet,i)
				-- 玩家扣血
				player:reduceBloodBar()
				break
			end

			-- 遍历敌机列表
			for m,n in ipairs(enemyList) do
				-- 如果玩家子弹打到敌机了
				if( v.type ~= 3 
					and math.abs(v:getPositionX() - n:getPositionX()) <= n:getContentSize().width/2
					and math.abs(v:getPositionY() - n:getPositionY()) <= 10) then
					-- 子弹加入临时表
					table.insert(tempBullet,i)
					-- 敌机扣血
					n:reduceBloodBar()
					-- 如果敌机没血了 
					if(n.hp <= 0) then
						-- 敌机加入临时表
						table.insert(tempEnemy,m)
					end
					break
				end
			end
		end

		-- 遍历敌机列表
		for i,v in ipairs(enemyList) do
			-- 如果敌机出界
			if(v:getPositionY() < 0) then 
				-- 加入临时表
				table.insert(tempEnemy,i)
			end
		end 

		-- 移除临时表中的子弹
		for i,v in ipairs(tempBullet) do
			local temp = bulletList[v]
			if(temp) then
				table.remove(bulletList,v)
				temp:removeFromParent()
				print("**************子弹被移除***************")
			end

		end
		-- 移除临时表中的敌机
		for i,v in ipairs(tempEnemy) do
			local temp = enemyList[v]
			if(temp) then
				-- 爆炸
				BombAnimation(temp:getPositionX(),temp:getPositionY())
				table.remove(enemyList,v)
				temp:removeFromParent()
				print("**************敌机被移除***************")		
			end

		end
	end

 	scene:scheduleUpdateWithPriorityLua(update,0)

	return scene
end